Cave Game Data

Unity用のCSV一括読込・検証・保管コードです。

配置

Assets/
├─ Resources/GameData/
│  ├─ Characters/characters.csv
│  ├─ Skills/skills.csv
│  └─ Buffs/
│     ├─ science_buffs.csv
│     ├─ math_buffs.csv
│     └─ history_buffs.csv
└─ Scripts/GameData/
   ├─ Models/GameDataModels.cs
   ├─ Models/RuntimeBuffState.cs
   ├─ Csv/CsvParser.cs
   ├─ Csv/CsvDataValidator.cs
   ├─ Csv/GameDataLoader.cs
   └─ GameDataRepository.cs

GameDataLoader を起動シーンのGameObjectへ追加してください。Awake で5ファイルを読み込み、検証に成功した場合だけ Repository を公開します。

CSVヘッダー

characters.csv

id,character_name,max_hp,attack,defense,speed,skill_1_id,skill_2_id,skill_3_id,description

skill_2_id と skill_3_id は空欄にできます。skill_1_id は必須です。

skills.csv

id,skill_name,target,n_val,s_val,r_val,hits,buff_group,effect_type,description

3教科のbuff CSV

id,buff_name,subject,grade,unit,reward_tier,n_val,s_val,r_val,multiplier,max_multiplier,trigger_type,effect_type,buff_group,hint,battle_hint,description

r_val

通常の継続効果: 残りターン数

EXTRA_TURN: 追加行動回数

即時効果: 0

RuntimeBuffState.TickTurnEnd() はターン終了時に一度だけ呼びます。r_val=3 は付与されたターンを含めて3ターン有効です。

CaveEventStateとの接続

既存の List<string> ScienceBuffs などは、実行時状態を扱う段階で次へ移行することを推奨します。

private List<RuntimeBuffState> activeScienceBuffs =
    new List<RuntimeBuffState>();

定義はRepositoryから取得します。

BuffData definition = repository.GetBuff(runtimeBuff.BuffId);

CSVを再読込するのは起動時または明示的なリロード時だけにし、各PhaseはRepositoryを参照してください。