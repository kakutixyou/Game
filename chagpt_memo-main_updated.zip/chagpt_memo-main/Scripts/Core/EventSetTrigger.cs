using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

/// <summary>
/// Unity UIのButtonとゲーム内イベントをeventIdで接続する共通クラス。
///
/// 設計ルール:
/// ・1つのButtonに割り当てられるeventIdは1つだけ
/// ・1つのeventIdには優先順位付きで複数Actionを登録可能
/// ・CaveExplorationHandlerなど寿命を持つ登録ではownerを必ず指定する
/// ・Phaseの実行可否はconditionで判定する
/// ・画面遷移や戦闘計算そのものは担当しない
/// </summary>
public sealed class EventSetTrigger : MonoBehaviour
{
    [Header("Event Trigger Settings")]
    [SerializeField] private bool enableDebugLog = true;
    [SerializeField] private bool rejectReentrantTrigger = true;
    [SerializeField] private bool unregisterAllOnDestroy = true;

    private readonly Dictionary<string, List<RegisteredEvent>> eventTable =
        new Dictionary<string, List<RegisteredEvent>>(StringComparer.Ordinal);

    private readonly Dictionary<Button, ButtonBinding> buttonBindings =
        new Dictionary<Button, ButtonBinding>();

    private readonly HashSet<string> triggeringEventIds =
        new HashSet<string>(StringComparer.Ordinal);

    /// <summary>
    /// ownerを持たない常駐イベント向け。
    /// 洞窟HandlerやPhaseではowner付きオーバーロードを使用すること。
    /// </summary>
    public bool Register(
        string eventId,
        Button button,
        UnityAction action)
    {
        return Register(
            eventId,
            button,
            action,
            null,
            0,
            false,
            null,
            true);
    }

    public bool Register(
        string eventId,
        Button button,
        UnityAction action,
        UnityEngine.Object owner)
    {
        return Register(
            eventId,
            button,
            action,
            owner,
            0,
            false,
            null,
            true);
    }

    /// <summary>
    /// イベントを完全指定で登録する。
    /// priorityは数値が大きいActionから実行する。
    /// oneShotはconditionを通過して実行を試みた後に解除する。
    /// </summary>
    public bool Register(
        string eventId,
        Button button,
        UnityAction action,
        UnityEngine.Object owner,
        int priority,
        bool oneShot,
        Func<bool> condition,
        bool enabled)
    {
        string normalizedId;
        if (!TryValidateRegistration(eventId, button, action, out normalizedId))
        {
            return false;
        }

        ButtonBinding existingBinding;
        if (buttonBindings.TryGetValue(button, out existingBinding) &&
            !string.Equals(existingBinding.EventId, normalizedId, StringComparison.Ordinal))
        {
            Debug.LogError(
                $"[EventSetTrigger] 同じButtonへ異なるeventIdは登録できません。" +
                $" existing='{existingBinding.EventId}', requested='{normalizedId}', button='{button.name}'");
            return false;
        }

        List<RegisteredEvent> events;
        if (!eventTable.TryGetValue(normalizedId, out events))
        {
            events = new List<RegisteredEvent>();
            eventTable.Add(normalizedId, events);
        }

        bool hasOwner = owner != null;
        RegisteredEvent duplicate = events.FirstOrDefault(item =>
            item != null &&
            item.Button == button &&
            item.Action == action &&
            item.HasOwner == hasOwner &&
            item.Owner == owner);

        if (duplicate != null)
        {
            DebugLog($"二重登録をスキップ: {normalizedId} / Button={button.name}");
            return false;
        }

        RegisteredEvent registeredEvent = new RegisteredEvent(
            normalizedId,
            button,
            action,
            owner,
            hasOwner,
            priority,
            oneShot,
            condition,
            enabled);

        events.Add(registeredEvent);
        events.Sort((left, right) => right.Priority.CompareTo(left.Priority));
        EnsureButtonBinding(normalizedId, button);

        DebugLog(
            $"登録: {normalizedId} / Button={button.name} / " +
            $"Owner={GetOwnerName(owner, hasOwner)} / Priority={priority} / OneShot={oneShot}");
        return true;
    }

    /// <summary>
    /// Button以外の処理からeventIdを直接発火できる。
    /// </summary>
    public bool Trigger(string eventId)
    {
        string normalizedId = NormalizeEventId(eventId);
        if (normalizedId.Length == 0)
        {
            Debug.LogWarning("[EventSetTrigger] 空のeventIdは発火できません。");
            return false;
        }

        List<RegisteredEvent> events;
        if (!eventTable.TryGetValue(normalizedId, out events) || events.Count == 0)
        {
            DebugLog($"未登録イベント: {normalizedId}");
            return false;
        }

        if (rejectReentrantTrigger && triggeringEventIds.Contains(normalizedId))
        {
            Debug.LogWarning($"[EventSetTrigger] 同一イベントの再入発火を拒否しました: {normalizedId}");
            return false;
        }

        triggeringEventIds.Add(normalizedId);
        bool executedAny = false;
        List<RegisteredEvent> removeList = new List<RegisteredEvent>();

        try
        {
            List<RegisteredEvent> snapshot = new List<RegisteredEvent>(events);
            for (int i = 0; i < snapshot.Count; i++)
            {
                RegisteredEvent registeredEvent = snapshot[i];
                if (registeredEvent == null)
                {
                    continue;
                }

                if (registeredEvent.HasOwner && registeredEvent.Owner == null)
                {
                    removeList.Add(registeredEvent);
                    continue;
                }

                if (!registeredEvent.Enabled)
                {
                    continue;
                }

                if (!EvaluateCondition(registeredEvent))
                {
                    continue;
                }

                try
                {
                    registeredEvent.Action.Invoke();
                    registeredEvent.ExecutionCount++;
                    executedAny = true;
                }
                catch (Exception ex)
                {
                    Debug.LogError(
                        $"[EventSetTrigger] Action実行エラー: {normalizedId}\n{ex}");
                }

                if (registeredEvent.OneShot)
                {
                    removeList.Add(registeredEvent);
                }
            }
        }
        finally
        {
            triggeringEventIds.Remove(normalizedId);

            for (int i = 0; i < removeList.Count; i++)
            {
                RemoveRegisteredEvent(removeList[i]);
            }

            CleanupEmptyEventIds();
        }

        DebugLog($"発火: {normalizedId} / Executed={executedAny}");
        return executedAny;
    }

    public void EnableEvent(string eventId)
    {
        SetEventEnabled(eventId, true);
    }

    public void DisableEvent(string eventId)
    {
        SetEventEnabled(eventId, false);
    }

    public bool SetEventEnabled(string eventId, bool enabled)
    {
        List<RegisteredEvent> events;
        if (!TryGetEvents(eventId, out events))
        {
            return false;
        }

        for (int i = 0; i < events.Count; i++)
        {
            events[i].Enabled = enabled;
        }

        DebugLog($"Event Enabled: {NormalizeEventId(eventId)} = {enabled}");
        return true;
    }

    public void EnableOwner(UnityEngine.Object owner)
    {
        SetOwnerEnabled(owner, true);
    }

    public void DisableOwner(UnityEngine.Object owner)
    {
        SetOwnerEnabled(owner, false);
    }

    public int SetOwnerEnabled(UnityEngine.Object owner, bool enabled)
    {
        if (owner == null)
        {
            return 0;
        }

        int changedCount = 0;
        foreach (List<RegisteredEvent> events in eventTable.Values)
        {
            for (int i = 0; i < events.Count; i++)
            {
                RegisteredEvent registeredEvent = events[i];
                if (registeredEvent.HasOwner && registeredEvent.Owner == owner)
                {
                    registeredEvent.Enabled = enabled;
                    changedCount++;
                }
            }
        }

        DebugLog($"Owner Enabled: {owner.name} = {enabled} / Count={changedCount}");
        return changedCount;
    }

    public bool SetButtonInteractable(string eventId, bool interactable)
    {
        List<RegisteredEvent> events;
        if (!TryGetEvents(eventId, out events))
        {
            return false;
        }

        HashSet<Button> changedButtons = new HashSet<Button>();
        for (int i = 0; i < events.Count; i++)
        {
            Button button = events[i].Button;
            if (button != null && changedButtons.Add(button))
            {
                button.interactable = interactable;
            }
        }

        return changedButtons.Count > 0;
    }

    public bool Unregister(string eventId)
    {
        List<RegisteredEvent> events;
        if (!TryGetEvents(eventId, out events))
        {
            return false;
        }

        List<RegisteredEvent> snapshot = new List<RegisteredEvent>(events);
        for (int i = 0; i < snapshot.Count; i++)
        {
            RemoveRegisteredEvent(snapshot[i]);
        }

        CleanupEmptyEventIds();
        DebugLog($"イベント解除: {NormalizeEventId(eventId)}");
        return true;
    }

    public int UnregisterOwner(UnityEngine.Object owner)
    {
        if (owner == null)
        {
            return 0;
        }

        List<RegisteredEvent> removeList = new List<RegisteredEvent>();
        foreach (List<RegisteredEvent> events in eventTable.Values)
        {
            for (int i = 0; i < events.Count; i++)
            {
                RegisteredEvent registeredEvent = events[i];
                if (registeredEvent.HasOwner && registeredEvent.Owner == owner)
                {
                    removeList.Add(registeredEvent);
                }
            }
        }

        for (int i = 0; i < removeList.Count; i++)
        {
            RemoveRegisteredEvent(removeList[i]);
        }

        CleanupEmptyEventIds();
        DebugLog($"Owner解除: {owner.name} / Count={removeList.Count}");
        return removeList.Count;
    }

    public void UnregisterAll()
    {
        List<ButtonBinding> bindings = new List<ButtonBinding>(buttonBindings.Values);
        for (int i = 0; i < bindings.Count; i++)
        {
            ButtonBinding binding = bindings[i];
            if (binding.Button != null)
            {
                binding.Button.onClick.RemoveListener(binding.Listener);
            }
        }

        buttonBindings.Clear();
        eventTable.Clear();
        triggeringEventIds.Clear();
        DebugLog("全イベント解除");
    }

    public bool HasEvent(string eventId)
    {
        List<RegisteredEvent> events;
        return TryGetEvents(eventId, out events) && events.Count > 0;
    }

    public int GetEventCount(string eventId)
    {
        List<RegisteredEvent> events;
        return TryGetEvents(eventId, out events) ? events.Count : 0;
    }

    public int GetOwnerEventCount(UnityEngine.Object owner)
    {
        if (owner == null)
        {
            return 0;
        }

        int count = 0;
        foreach (List<RegisteredEvent> events in eventTable.Values)
        {
            for (int i = 0; i < events.Count; i++)
            {
                if (events[i].HasOwner && events[i].Owner == owner)
                {
                    count++;
                }
            }
        }

        return count;
    }

    public IReadOnlyList<string> GetRegisteredEventIds()
    {
        List<string> ids = eventTable.Keys.ToList();
        ids.Sort(StringComparer.Ordinal);
        return ids.AsReadOnly();
    }

    public void PrintRegisteredEvents()
    {
        Debug.Log("========== EventSetTrigger ==========");

        List<string> eventIds = eventTable.Keys.ToList();
        eventIds.Sort(StringComparer.Ordinal);

        for (int idIndex = 0; idIndex < eventIds.Count; idIndex++)
        {
            string eventId = eventIds[idIndex];
            List<RegisteredEvent> events = eventTable[eventId];
            Debug.Log($"EventId={eventId} / Count={events.Count}");

            for (int eventIndex = 0; eventIndex < events.Count; eventIndex++)
            {
                RegisteredEvent item = events[eventIndex];
                Debug.Log(
                    $"  Button={GetButtonName(item.Button)}, " +
                    $"Owner={GetOwnerName(item.Owner, item.HasOwner)}, " +
                    $"Priority={item.Priority}, Enabled={item.Enabled}, " +
                    $"OneShot={item.OneShot}, Executions={item.ExecutionCount}");
            }
        }

        Debug.Log("=====================================");
    }

    private bool TryValidateRegistration(
        string eventId,
        Button button,
        UnityAction action,
        out string normalizedId)
    {
        normalizedId = NormalizeEventId(eventId);
        if (normalizedId.Length == 0)
        {
            Debug.LogError("[EventSetTrigger] eventIdが空です。");
            return false;
        }

        if (button == null)
        {
            Debug.LogError($"[EventSetTrigger] Buttonがnullです: {normalizedId}");
            return false;
        }

        if (action == null)
        {
            Debug.LogError($"[EventSetTrigger] Actionがnullです: {normalizedId}");
            return false;
        }

        return true;
    }

    private void EnsureButtonBinding(string eventId, Button button)
    {
        if (buttonBindings.ContainsKey(button))
        {
            return;
        }

        UnityAction listener = () => Trigger(eventId);
        button.onClick.AddListener(listener);
        buttonBindings.Add(button, new ButtonBinding(eventId, button, listener));
    }

    private bool EvaluateCondition(RegisteredEvent registeredEvent)
    {
        if (registeredEvent.Condition == null)
        {
            return true;
        }

        try
        {
            bool result = registeredEvent.Condition.Invoke();
            if (!result)
            {
                DebugLog($"Condition false: {registeredEvent.EventId}");
            }

            return result;
        }
        catch (Exception ex)
        {
            Debug.LogError(
                $"[EventSetTrigger] Condition実行エラー: {registeredEvent.EventId}\n{ex}");
            return false;
        }
    }

    private void RemoveRegisteredEvent(RegisteredEvent registeredEvent)
    {
        if (registeredEvent == null)
        {
            return;
        }

        List<RegisteredEvent> events;
        if (eventTable.TryGetValue(registeredEvent.EventId, out events))
        {
            events.Remove(registeredEvent);
        }

        CleanupButtonIfUnused(registeredEvent.Button);
    }

    private void CleanupButtonIfUnused(Button button)
    {
        if (button == null)
        {
            return;
        }

        bool stillUsed = eventTable.Values.Any(events =>
            events.Any(item => item != null && item.Button == button));

        if (stillUsed)
        {
            return;
        }

        ButtonBinding binding;
        if (buttonBindings.TryGetValue(button, out binding))
        {
            button.onClick.RemoveListener(binding.Listener);
            buttonBindings.Remove(button);
        }
    }

    private void CleanupEmptyEventIds()
    {
        List<string> emptyIds = eventTable
            .Where(pair => pair.Value == null || pair.Value.Count == 0)
            .Select(pair => pair.Key)
            .ToList();

        for (int i = 0; i < emptyIds.Count; i++)
        {
            eventTable.Remove(emptyIds[i]);
        }
    }

    private bool TryGetEvents(string eventId, out List<RegisteredEvent> events)
    {
        string normalizedId = NormalizeEventId(eventId);
        if (normalizedId.Length == 0)
        {
            events = null;
            return false;
        }

        return eventTable.TryGetValue(normalizedId, out events) && events != null;
    }

    private static string NormalizeEventId(string eventId)
    {
        return string.IsNullOrWhiteSpace(eventId)
            ? string.Empty
            : eventId.Trim();
    }

    private static string GetButtonName(Button button)
    {
        return button == null ? "Destroyed" : button.name;
    }

    private static string GetOwnerName(UnityEngine.Object owner, bool hasOwner)
    {
        if (!hasOwner)
        {
            return "None";
        }

        return owner == null ? "Destroyed" : owner.name;
    }

    private void DebugLog(string message)
    {
        if (enableDebugLog)
        {
            Debug.Log($"[EventSetTrigger] {message}");
        }
    }

    private void OnDestroy()
    {
        if (unregisterAllOnDestroy)
        {
            UnregisterAll();
        }
    }

    private sealed class ButtonBinding
    {
        public string EventId { get; private set; }
        public Button Button { get; private set; }
        public UnityAction Listener { get; private set; }

        public ButtonBinding(string eventId, Button button, UnityAction listener)
        {
            EventId = eventId;
            Button = button;
            Listener = listener;
        }
    }

    private sealed class RegisteredEvent
    {
        public string EventId { get; private set; }
        public Button Button { get; private set; }
        public UnityAction Action { get; private set; }
        public UnityEngine.Object Owner { get; private set; }
        public bool HasOwner { get; private set; }
        public int Priority { get; private set; }
        public bool OneShot { get; private set; }
        public Func<bool> Condition { get; private set; }
        public bool Enabled { get; set; }
        public int ExecutionCount { get; set; }

        public RegisteredEvent(
            string eventId,
            Button button,
            UnityAction action,
            UnityEngine.Object owner,
            bool hasOwner,
            int priority,
            bool oneShot,
            Func<bool> condition,
            bool enabled)
        {
            EventId = eventId;
            Button = button;
            Action = action;
            Owner = owner;
            HasOwner = hasOwner;
            Priority = priority;
            OneShot = oneShot;
            Condition = condition;
            Enabled = enabled;
            ExecutionCount = 0;
        }
    }
}
