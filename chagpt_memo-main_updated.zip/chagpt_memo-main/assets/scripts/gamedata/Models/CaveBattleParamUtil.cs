using System;
using System.Globalization;
using System.Text.RegularExpressions;

namespace CaveGame.CaveBattle
{
    /// <summary>
    /// skills CSV の params 列は
    /// "{""damage"":815,""condition"":{""targetHp_gte"":594}}" のような
    /// 単純なフラット、または1階層ネストのJSONのみを想定した軽量パーサー。
    ///
    /// 完全なJSONパーサーではなく、"key":value という並びを正規表現で探すだけなので、
    /// ネストの深さに関係なくキー名で値を拾える一方、同名キーが複数箇所にある場合などは
    /// 想定通りに動かない。今回のCSVの範囲（各キーは1箇所のみ）であれば十分。
    /// </summary>
    public static class CaveBattleParamUtil
    {
        public static bool TryGetInt(string json, string key, out int value)
        {
            value = 0;
            if (string.IsNullOrEmpty(json))
            {
                return false;
            }

            Match match = Regex.Match(json, "\"" + Regex.Escape(key) + "\"\\s*:\\s*(-?\\d+)");
            if (!match.Success)
            {
                return false;
            }

            return int.TryParse(
                match.Groups[1].Value,
                NumberStyles.Integer,
                CultureInfo.InvariantCulture,
                out value);
        }

        public static bool TryGetString(string json, string key, out string value)
        {
            value = null;
            if (string.IsNullOrEmpty(json))
            {
                return false;
            }

            Match match = Regex.Match(json, "\"" + Regex.Escape(key) + "\"\\s*:\\s*\"([^\"]*)\"");
            if (!match.Success)
            {
                return false;
            }

            value = match.Groups[1].Value;
            return true;
        }

        public static bool IsStringValue(string json, string key, string expected)
        {
            return TryGetString(json, key, out string actual) &&
                string.Equals(actual, expected, StringComparison.OrdinalIgnoreCase);
        }
    }
}
