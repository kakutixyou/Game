using UnityEngine;

namespace CaveGame.CaveBattle
{
    /// <summary>
    /// ダンジョン内の各イベント／エンカウントに割り当てる「戦闘ルールの差分」。
    /// TwoTurnBattlePhase.Executeへ渡すと、そのバトルだけこのルールで解決される。
    ///
    /// 用意する想定イベント例:
    /// ・通常ルール          → CreateNormal() 相当（何も反転・固定しない）
    /// ・負けたら勝ちイベント → InvertFinalResult = true
    /// ・運が絡む効果が90%になるイベント → UseFixedLuckPercent = true, FixedLuckPercent = 90
    /// ・日本史/理科/数学バフダンジョン → BuffSubject を設定し、CaveBattleBuffDataRepositoryから
    ///   対応するバフ候補を引く（バフの個別効果自体はまだ未実装、CaveBattleBuffDataLoaderのメモ参照）
    /// </summary>
    [CreateAssetMenu(
        fileName = "CaveBattleRuleset",
        menuName = "CaveGame/Cave Battle/Ruleset")]
    public sealed class CaveBattleRuleset : ScriptableObject
    {
        [Header("表示用")]
        [SerializeField] private string rulesetName = "通常ルール";
        [TextArea(1, 3)]
        [SerializeField] private string description = "HPが高い方が勝利する通常のルール。";

        [Header("勝敗反転（負けたら勝ちイベント）")]
        [Tooltip("trueの場合、通常なら負け/勝ちになる結果を反転させる（引き分けはそのまま）。")]
        [SerializeField] private bool invertFinalResult = false;

        [Header("確率固定（運が絡む効果が90%になるイベント等）")]
        [Tooltip("trueの場合、SPECIAL_ATTACK等の成功率計算を無視し、下のFixedLuckPercentで固定する。")]
        [SerializeField] private bool useFixedLuckPercent = false;
        [SerializeField, Range(0, 100)] private int fixedLuckPercent = 90;

        [Header("バフダンジョン（このイベントで得られるバフの科目）")]
        [SerializeField] private CaveBuffSubject buffSubject = CaveBuffSubject.None;

        [Header("仲間勧誘（会話イベント）")]
        [Tooltip(
            "trueの場合、この戦闘の前に会話イベント（強さを調べる／仲間にする／断る）を挟むことができる。" +
            "falseの場合は「仲間にできない戦闘」として扱い、会話を挟まず直接戦闘へ進む。" +
            "開発中はこのフラグだけで、どのイベント／エンカウントが仲間集め対象かを一覧管理できる。")]
        [SerializeField] private bool allowsRecruitment = true;

        public string RulesetName => rulesetName;
        public string Description => description;
        public bool InvertFinalResult => invertFinalResult;
        public bool UseFixedLuckPercent => useFixedLuckPercent;
        public int FixedLuckPercent => fixedLuckPercent;
        public CaveBuffSubject BuffSubject => buffSubject;

        /// <summary>
        /// この戦闘が「仲間にできる戦闘」かどうか。
        /// falseのルールセット（負けたら勝ちイベント、運が絡む効果が90%固定のイベント等）は
        /// 会話イベントを挟まず、CaveBattleEncounterServiceが自動的に直接戦闘へ進める。
        /// </summary>
        public bool AllowsRecruitment => allowsRecruitment;

        /// <summary>Executeにrulesetを渡さなかった場合に使う、何も変更しないルール。</summary>
        public static CaveBattleRuleset Normal { get; } =
            CreateRuntime("通常ルール", "HPが高い方が勝利する通常のルール。", allowsRecruitment: true);

        /// <summary>コード上で一時的なルールを作りたい場合用（Inspectorのアセットを使わない簡易生成）。</summary>
        public static CaveBattleRuleset CreateRuntime(
            string name,
            string description,
            bool invertFinalResult = false,
            bool useFixedLuckPercent = false,
            int fixedLuckPercent = 90,
            CaveBuffSubject buffSubject = CaveBuffSubject.None,
            bool allowsRecruitment = true)
        {
            CaveBattleRuleset ruleset = CreateInstance<CaveBattleRuleset>();
            ruleset.rulesetName = name;
            ruleset.description = description;
            ruleset.invertFinalResult = invertFinalResult;
            ruleset.useFixedLuckPercent = useFixedLuckPercent;
            ruleset.fixedLuckPercent = fixedLuckPercent;
            ruleset.buffSubject = buffSubject;
            ruleset.allowsRecruitment = allowsRecruitment;
            return ruleset;
        }
    }

    /// <summary>ダンジョンで得られるバフの科目。イベントごとにどのCSVプールから引くかを表す。</summary>
    public enum CaveBuffSubject
    {
        None = 0,
        Math,
        Science,
        History
    }
}
