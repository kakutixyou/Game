using System;

namespace CaveGame.CaveBattle
{
    /// <summary>
    /// Resources/characters/japanese_history_chars_expanded.csv の1行に対応するキャラクターデータ。
    /// 列: id,char_name,rank,hp,base_attack,base_speed,skill_turn_1,skill_turn_2,passive_skill,description
    ///
    /// skill_turn_1 / skill_turn_2 が「CSVに書いてある行動」そのもの。
    /// 1ターン目は skill_turn_1、2ターン目は skill_turn_2 を必ず使用する。
    /// </summary>
    [Serializable]
    public sealed class CaveBattleCharacter
    {
        public int Id { get; }
        public string CharacterName { get; }
        public int Rank { get; }
        public int MaxHp { get; }
        public int BaseAttack { get; }
        public int BaseSpeed { get; }
        public int SkillTurn1Id { get; }
        public int SkillTurn2Id { get; }
        public int? PassiveSkillId { get; }
        public string Description { get; }

        public CaveBattleCharacter(
            int id,
            string characterName,
            int rank,
            int maxHp,
            int baseAttack,
            int baseSpeed,
            int skillTurn1Id,
            int skillTurn2Id,
            int? passiveSkillId,
            string description)
        {
            Id = id;
            CharacterName = characterName ?? string.Empty;
            Rank = rank;
            MaxHp = maxHp;
            BaseAttack = baseAttack;
            BaseSpeed = baseSpeed;
            SkillTurn1Id = skillTurn1Id;
            SkillTurn2Id = skillTurn2Id;
            PassiveSkillId = passiveSkillId;
            Description = description ?? string.Empty;
        }

        /// <summary>
        /// 戦闘は必ず2ターンで、そのターンに使う技はCSVで固定されている。
        /// turnNumberは1または2のみを受け付ける。
        /// </summary>
        public int GetSkillIdForTurn(int turnNumber)
        {
            switch (turnNumber)
            {
                case 1:
                    return SkillTurn1Id;
                case 2:
                    return SkillTurn2Id;
                default:
                    throw new ArgumentOutOfRangeException(
                        nameof(turnNumber),
                        "このキャラクターは2ターン分の行動（skill_turn_1 / skill_turn_2）しか定義されていません。");
            }
        }
    }

    /// <summary>
    /// Resources/skills/japanese_history_skills_expanded.csv の1行に対応する技データ。
    /// 列: id,skill_name,target,n_val,s_val,r_val,hits,effect_type,params,description
    ///
    /// n_val = 攻撃力。そのままダメージ量（× hits）として扱う。
    /// s_val = 行動が発生するタイミング。値が小さいほど先に発生する。
    ///         -999 は「このターンは何もできない」ことを表す特別な値。
    /// r_val = バフの持続ターン数。戦闘は基本2ターンしかないため、
    ///         999のような極端に大きな値が入っていても実質問題にならないことが多い。
    /// </summary>
    [Serializable]
    public sealed class CaveBattleSkill
    {
        /// <summary>この値がs_valに入っている場合、そのターンは何もできない。</summary>
        public const int CannotActSVal = -999;

        public int Id { get; }
        public string SkillName { get; }
        public string TargetRaw { get; }
        public int NVal { get; }
        public int SVal { get; }
        public int RVal { get; }
        public int Hits { get; }
        public string EffectTypeRaw { get; }
        public string ParamsJson { get; }
        public string Description { get; }

        public bool CannotAct => SVal == CannotActSVal;

        public bool TargetsSelf =>
            string.Equals(TargetRaw, "self", StringComparison.OrdinalIgnoreCase);

        public bool TargetsEnemy =>
            string.Equals(TargetRaw, "enemy", StringComparison.OrdinalIgnoreCase);

        public bool TargetsAll =>
            string.Equals(TargetRaw, "all", StringComparison.OrdinalIgnoreCase);

        public CaveBattleSkill(
            int id,
            string skillName,
            string targetRaw,
            int nVal,
            int sVal,
            int rVal,
            int hits,
            string effectTypeRaw,
            string paramsJson,
            string description)
        {
            Id = id;
            SkillName = skillName ?? string.Empty;
            TargetRaw = (targetRaw ?? string.Empty).Trim();
            NVal = nVal;
            SVal = sVal;
            RVal = rVal;
            Hits = hits;
            EffectTypeRaw = (effectTypeRaw ?? string.Empty).Trim();
            ParamsJson = paramsJson ?? string.Empty;
            Description = description ?? string.Empty;
        }
    }
}
