[Serializable]
public sealed class CharacterData
{
    public int Id { get; }
    public string CharacterName { get; }
    public int MaxHp { get; }
    public int Attack { get; }
    public int Defense { get; }
    public int Speed { get; }

    public int Skill1Id { get; }
    public int Skill2Id { get; }
    public int Skill3Id { get; }

    public CharacterData(
        int id,
        string characterName,
        int maxHp,
        int attack,
        int defense,
        int speed,
        int skill1Id,
        int skill2Id,
        int skill3Id
    )
    {
        Id = id;
        CharacterName = characterName;
        MaxHp = maxHp;
        Attack = attack;
        Defense = defense;
        Speed = speed;
        Skill1Id = skill1Id;
        Skill2Id = skill2Id;
        Skill3Id = skill3Id;
    }
}
