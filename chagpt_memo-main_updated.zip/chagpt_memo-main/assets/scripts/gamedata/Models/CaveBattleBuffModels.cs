using System;

namespace CaveGame.CaveBattle
{
    /// <summary>
    /// Mathbahu.csv / Siencebahu.csv 共通のスキーマ。
    /// 列: id,buff_name,subject,grade,unit,reward_tier,n_val,s_val,r_val,multiplier,
    ///     max_multiplier,trigger_type,effect_type,buff_group,hint,battle_hint,description
    ///
    /// 注意: effect_typeの種類が非常に多く（ATTACK_ADD, DAMAGE_DIVIDE, PAIR_COMBO等）、
    /// それぞれ固有の計算式を持つ。現時点ではこのクラスはデータの保持のみを行い、
    /// 戦闘エンジン側で個々のeffect_typeを解釈する実装はまだ無い（CaveBattleBuffDataLoaderの
    /// クラスコメント参照）。
    /// </summary>
    [Serializable]
    public sealed class CaveSubjectBuffData
    {
        public int Id { get; }
        public string BuffName { get; }
        public string Subject { get; }
        public string Grade { get; }
        public string Unit { get; }
        public string RewardTier { get; }
        public int NVal { get; }
        public int SVal { get; }
        public int RVal { get; }
        public float Multiplier { get; }
        public float MaxMultiplier { get; }
        public string TriggerType { get; }
        public string EffectType { get; }
        public string BuffGroup { get; }
        public string Hint { get; }
        public string BattleHint { get; }
        public string Description { get; }

        public CaveSubjectBuffData(
            int id, string buffName, string subject, string grade, string unit, string rewardTier,
            int nVal, int sVal, int rVal, float multiplier, float maxMultiplier,
            string triggerType, string effectType, string buffGroup,
            string hint, string battleHint, string description)
        {
            Id = id;
            BuffName = buffName ?? string.Empty;
            Subject = subject ?? string.Empty;
            Grade = grade ?? string.Empty;
            Unit = unit ?? string.Empty;
            RewardTier = rewardTier ?? string.Empty;
            NVal = nVal;
            SVal = sVal;
            RVal = rVal;
            Multiplier = multiplier;
            MaxMultiplier = maxMultiplier;
            TriggerType = triggerType ?? string.Empty;
            EffectType = effectType ?? string.Empty;
            BuffGroup = buffGroup ?? string.Empty;
            Hint = hint ?? string.Empty;
            BattleHint = battleHint ?? string.Empty;
            Description = description ?? string.Empty;
        }
    }

    /// <summary>
    /// nihonsi_bahu.csv のスキーマ（数学・理科とは列構成が異なる）。
    /// 列: id,buff_name,era,rank,target,n_val,s_val,r_val,activation_turn,effect_type,
    ///     global_effect,replace_on_new_history_buff,risk_level,hint,description
    /// </summary>
    [Serializable]
    public sealed class CaveHistoryBuffData
    {
        public int Id { get; }
        public string BuffName { get; }
        public string Era { get; }
        public string Rank { get; }
        public string TargetRaw { get; }
        public int NVal { get; }
        public int SVal { get; }
        public int RVal { get; }
        public float ActivationTurn { get; }
        public string EffectType { get; }
        public bool GlobalEffect { get; }
        public bool ReplaceOnNewHistoryBuff { get; }
        public string RiskLevel { get; }
        public string Hint { get; }
        public string Description { get; }

        public CaveHistoryBuffData(
            int id, string buffName, string era, string rank, string targetRaw,
            int nVal, int sVal, int rVal, float activationTurn, string effectType,
            bool globalEffect, bool replaceOnNewHistoryBuff, string riskLevel,
            string hint, string description)
        {
            Id = id;
            BuffName = buffName ?? string.Empty;
            Era = era ?? string.Empty;
            Rank = rank ?? string.Empty;
            TargetRaw = targetRaw ?? string.Empty;
            NVal = nVal;
            SVal = sVal;
            RVal = rVal;
            ActivationTurn = activationTurn;
            EffectType = effectType ?? string.Empty;
            GlobalEffect = globalEffect;
            ReplaceOnNewHistoryBuff = replaceOnNewHistoryBuff;
            RiskLevel = riskLevel ?? string.Empty;
            Hint = hint ?? string.Empty;
            Description = description ?? string.Empty;
        }
    }
}
