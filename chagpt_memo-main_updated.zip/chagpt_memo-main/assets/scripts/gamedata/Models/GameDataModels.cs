using System;
using System.Collections.Generic;

namespace CaveGame.GameData
{
    public enum SkillTarget
    {
        None = 0,
        Self,
        Enemy,
        Ally,
        AllAllies,
        AllEnemies,
        All,
        Everyone
    }

    public enum GameEffectType
    {
        None = 0,
        Damage,
        Heal,
        Buff,
        Debuff,
        ExtraTurn,
        PreventDefeat,
        Joke,
        DamageReduce,
        BuffReuse,
        Cleanse,
        Regen,
        LayerShield,
        DamageMultiply
    }

    public enum BuffTriggerType
    {
        None = 0,
        BattleStart,
        TurnStart,
        TurnEnd,
        DamageReceived,
        DebuffReceived,
        BuffUsed,
        EnemyAction
    }

    public enum RewardTier
    {
        None = 0,
        Stable,
        Strong,
        Perfect,
        Special
    }

    public enum SchoolSubject
    {
        None = 0,
        Science,
        Math,
        JapaneseHistory
    }

    [Serializable]
    public sealed class CharacterData
    {
        public int Id { get; private set; }
        public string CharacterName { get; private set; }
        public int MaxHp { get; private set; }
        public int Attack { get; private set; }
        public int Defense { get; private set; }
        public int Speed { get; private set; }
        public IReadOnlyList<int> SkillIds { get; private set; }
        public string Description { get; private set; }

        public CharacterData(
            int id,
            string characterName,
            int maxHp,
            int attack,
            int defense,
            int speed,
            IEnumerable<int> skillIds,
            string description)
        {
            Id = id;
            CharacterName = characterName ?? string.Empty;
            MaxHp = maxHp;
            Attack = attack;
            Defense = defense;
            Speed = speed;
            SkillIds = new List<int>(skillIds ?? Array.Empty<int>()).AsReadOnly();
            Description = description ?? string.Empty;
        }
    }

    [Serializable]
    public sealed class SkillData
    {
        public int Id { get; private set; }
        public string SkillName { get; private set; }
        public SkillTarget Target { get; private set; }
        public int NVal { get; private set; }
        public int SVal { get; private set; }
        public int RVal { get; private set; }
        public int Hits { get; private set; }
        public string BuffGroup { get; private set; }
        public GameEffectType EffectType { get; private set; }
        public string Description { get; private set; }

        public SkillData(
            int id,
            string skillName,
            SkillTarget target,
            int nVal,
            int sVal,
            int rVal,
            int hits,
            string buffGroup,
            GameEffectType effectType,
            string description)
        {
            Id = id;
            SkillName = skillName ?? string.Empty;
            Target = target;
            NVal = nVal;
            SVal = sVal;
            RVal = rVal;
            Hits = hits;
            BuffGroup = buffGroup ?? string.Empty;
            EffectType = effectType;
            Description = description ?? string.Empty;
        }
    }

    [Serializable]
    public abstract class BuffData
    {
        public int Id { get; private set; }
        public string BuffName { get; private set; }
        public SchoolSubject Subject { get; private set; }
        public string Grade { get; private set; }
        public string Unit { get; private set; }
        public RewardTier RewardTier { get; private set; }
        public int NVal { get; private set; }
        public int SVal { get; private set; }
        public int RVal { get; private set; }
        public float Multiplier { get; private set; }
        public float MaxMultiplier { get; private set; }
        public BuffTriggerType TriggerType { get; private set; }
        public GameEffectType EffectType { get; private set; }
        public string BuffGroup { get; private set; }
        public string Hint { get; private set; }
        public string BattleHint { get; private set; }
        public string Description { get; private set; }

        protected BuffData(
            int id,
            string buffName,
            SchoolSubject subject,
            string grade,
            string unit,
            RewardTier rewardTier,
            int nVal,
            int sVal,
            int rVal,
            float multiplier,
            float maxMultiplier,
            BuffTriggerType triggerType,
            GameEffectType effectType,
            string buffGroup,
            string hint,
            string battleHint,
            string description)
        {
            Id = id;
            BuffName = buffName ?? string.Empty;
            Subject = subject;
            Grade = grade ?? string.Empty;
            Unit = unit ?? string.Empty;
            RewardTier = rewardTier;
            NVal = nVal;
            SVal = sVal;
            RVal = rVal;
            Multiplier = multiplier;
            MaxMultiplier = maxMultiplier;
            TriggerType = triggerType;
            EffectType = effectType;
            BuffGroup = buffGroup ?? string.Empty;
            Hint = hint ?? string.Empty;
            BattleHint = battleHint ?? string.Empty;
            Description = description ?? string.Empty;
        }
    }

    [Serializable]
    public sealed class ScienceBuffData : BuffData
    {
        public ScienceBuffData(
            int id, string buffName, string grade, string unit, RewardTier rewardTier,
            int nVal, int sVal, int rVal, float multiplier, float maxMultiplier,
            BuffTriggerType triggerType, GameEffectType effectType, string buffGroup,
            string hint, string battleHint, string description)
            : base(id, buffName, SchoolSubject.Science, grade, unit, rewardTier,
                nVal, sVal, rVal, multiplier, maxMultiplier, triggerType, effectType,
                buffGroup, hint, battleHint, description)
        {
        }
    }

    [Serializable]
    public sealed class MathBuffData : BuffData
    {
        public MathBuffData(
            int id, string buffName, string grade, string unit, RewardTier rewardTier,
            int nVal, int sVal, int rVal, float multiplier, float maxMultiplier,
            BuffTriggerType triggerType, GameEffectType effectType, string buffGroup,
            string hint, string battleHint, string description)
            : base(id, buffName, SchoolSubject.Math, grade, unit, rewardTier,
                nVal, sVal, rVal, multiplier, maxMultiplier, triggerType, effectType,
                buffGroup, hint, battleHint, description)
        {
        }
    }

    [Serializable]
    public sealed class HistoryBuffData : BuffData
    {
        public HistoryBuffData(
            int id, string buffName, string grade, string unit, RewardTier rewardTier,
            int nVal, int sVal, int rVal, float multiplier, float maxMultiplier,
            BuffTriggerType triggerType, GameEffectType effectType, string buffGroup,
            string hint, string battleHint, string description)
            : base(id, buffName, SchoolSubject.JapaneseHistory, grade, unit, rewardTier,
                nVal, sVal, rVal, multiplier, maxMultiplier, triggerType, effectType,
                buffGroup, hint, battleHint, description)
        {
        }
    }
}
