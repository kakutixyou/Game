public enum SkillTarget
{
    Self,
    Enemy,
    All
}

public enum SkillEffectType
{
    Damage,
    Heal,
    Buff,
    Debuff,
    ExtraTurn,
    PreventDefeat,
    Joke
}

[Serializable]
public sealed class SkillData
{
    public int Id { get; }
    public string SkillName { get; }
    public SkillTarget Target { get; }

    public int NVal { get; }
    public int SVal { get; }
    public int RVal { get; }
    public int Hits { get; }

    public string BuffGroup { get; }
    public SkillEffectType EffectType { get; }
    public string Description { get; }

    public SkillData(
        int id,
        string skillName,
        SkillTarget target,
        int nVal,
        int sVal,
        int rVal,
        int hits,
        string buffGroup,
        SkillEffectType effectType,
        string description
    )
    {
        Id = id;
        SkillName = skillName;
        Target = target;
        NVal = nVal;
        SVal = sVal;
        RVal = rVal;
        Hits = hits;
        BuffGroup = buffGroup;
        EffectType = effectType;
        Description = description;
    }
}
