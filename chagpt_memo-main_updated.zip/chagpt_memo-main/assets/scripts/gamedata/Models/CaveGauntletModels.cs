using System;
using System.Collections.Generic;

namespace CaveGame.CaveBattle
{
    /// <summary>
    /// 負けた原因の大分類。
    /// 現状バフは戦闘計算に一切影響しないため（CaveBattleBuffDataLoaderの説明を参照）、
    /// Buffが選ばれることは実質無く、常にCharacterになる。バフの実効果を実装した後、
    /// 「バフ無しでも同じ結果だったか」等の判定を追加して使い分ける想定の置き場所。
    /// </summary>
    public enum CaveGauntletDefeatCause
    {
        Character,
        Buff
    }

    /// <summary>1勝するごとの抽選で実際に獲得したバフ。</summary>
    [Serializable]
    public sealed class CaveAcquiredBuff
    {
        public CaveBuffSubject Subject { get; }
        public int BuffId { get; }
        public string BuffName { get; }
        public string Description { get; }

        /// <summary>何勝した直後に獲得したか（1勝目終了後に獲得なら1）。</summary>
        public int AcquiredAfterWinNumber { get; }

        public CaveAcquiredBuff(
            CaveBuffSubject subject, int buffId, string buffName, string description, int acquiredAfterWinNumber)
        {
            Subject = subject;
            BuffId = buffId;
            BuffName = buffName ?? string.Empty;
            Description = description ?? string.Empty;
            AcquiredAfterWinNumber = acquiredAfterWinNumber;
        }
    }

    /// <summary>ガントレット1戦分の記録（ログ表示用）。</summary>
    [Serializable]
    public sealed class CaveGauntletRoundLog
    {
        public int RoundNumber { get; }
        public int EnemyCharacterId { get; }
        public string EnemyCharacterName { get; }
        public BattleResultType Result { get; }
        public int PlayerRemainingHp { get; }
        public int EnemyRemainingHp { get; }

        public CaveGauntletRoundLog(
            int roundNumber, int enemyCharacterId, string enemyCharacterName,
            BattleResultType result, int playerRemainingHp, int enemyRemainingHp)
        {
            RoundNumber = roundNumber;
            EnemyCharacterId = enemyCharacterId;
            EnemyCharacterName = enemyCharacterName ?? string.Empty;
            Result = result;
            PlayerRemainingHp = playerRemainingHp;
            EnemyRemainingHp = enemyRemainingHp;
        }
    }

    /// <summary>ガントレット終了時にリザルト画面へ渡す最終結果。</summary>
    [Serializable]
    public sealed class CaveGauntletResult
    {
        public bool Succeeded { get; private set; }
        public string ErrorMessage { get; private set; }

        /// <summary>何人抜きできたか。</summary>
        public int WinCount { get; private set; }
        public IReadOnlyList<CaveGauntletRoundLog> Rounds { get; private set; }
        public IReadOnlyList<CaveAcquiredBuff> AcquiredBuffs { get; private set; }
        public CaveGauntletDefeatCause DefeatCause { get; private set; }
        public string DefeatCauseNote { get; private set; }
        public int LosingEnemyCharacterId { get; private set; }
        public string LosingEnemyCharacterName { get; private set; }

        private CaveGauntletResult()
        {
            ErrorMessage = string.Empty;
            Rounds = new List<CaveGauntletRoundLog>().AsReadOnly();
            AcquiredBuffs = new List<CaveAcquiredBuff>().AsReadOnly();
            DefeatCauseNote = string.Empty;
            LosingEnemyCharacterName = string.Empty;
        }

        public static CaveGauntletResult CreateFinished(
            int winCount,
            IList<CaveGauntletRoundLog> rounds,
            IList<CaveAcquiredBuff> acquiredBuffs,
            CaveGauntletDefeatCause defeatCause,
            string defeatCauseNote,
            int losingEnemyCharacterId,
            string losingEnemyCharacterName)
        {
            return new CaveGauntletResult
            {
                Succeeded = true,
                WinCount = winCount,
                Rounds = new List<CaveGauntletRoundLog>(rounds ?? new List<CaveGauntletRoundLog>()).AsReadOnly(),
                AcquiredBuffs = new List<CaveAcquiredBuff>(acquiredBuffs ?? new List<CaveAcquiredBuff>()).AsReadOnly(),
                DefeatCause = defeatCause,
                DefeatCauseNote = defeatCauseNote ?? string.Empty,
                LosingEnemyCharacterId = losingEnemyCharacterId,
                LosingEnemyCharacterName = losingEnemyCharacterName ?? string.Empty
            };
        }

        public static CaveGauntletResult CreateAborted(string errorMessage)
        {
            return new CaveGauntletResult
            {
                Succeeded = false,
                ErrorMessage = errorMessage ?? "不明なエラーでガントレットが中断されました。"
            };
        }
    }
}
