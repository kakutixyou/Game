public enum BuffTriggerType
{
    BattleStart,
    TurnStart,
    TurnEnd,
    DamageReceived,
    DebuffReceived,
    BuffUsed,
    EnemyAction
}

public enum BuffEffectType
{
    DamageReduce,
    BuffReuse,
    Cleanse,
    Regen,
    LayerShield,
    DamageMultiply,
    ExtraTurn,
    PreventDefeat
}

public abstract class BuffData
{
    public int Id { get; protected set; }
    public string BuffName { get; protected set; }
    public string Subject { get; protected set; }
    public string Grade { get; protected set; }
    public string Unit { get; protected set; }
    public string RewardTier { get; protected set; }

    public int NVal { get; protected set; }
    public int SVal { get; protected set; }
    public int RVal { get; protected set; }

    public float Multiplier { get; protected set; }
    public float MaxMultiplier { get; protected set; }

    public BuffTriggerType TriggerType { get; protected set; }
    public BuffEffectType EffectType { get; protected set; }

    public string BuffGroup { get; protected set; }
    public string Hint { get; protected set; }
    public string BattleHint { get; protected set; }
    public string Description { get; protected set; }
}
