using System;
using UnityEngine;

namespace CaveGame.GameData
{
    public enum RuntimeBuffDurationKind
    {
        Instant = 0,
        Turns,
        Uses,
        Battle,
        Run
    }

    /// <summary>
    /// CSVのBuffDataは変更しない定義、RuntimeBuffStateは戦闘中に変化する状態。
    /// Turnsの場合、RemainingTurnsはターン終了時に1減る。
    /// 例: r_val=3なら付与ターンを含めて3ターン有効。
    /// </summary>
    [Serializable]
    public sealed class RuntimeBuffState
    {
        [SerializeField] private int buffId;
        [SerializeField] private string sourceActorId;
        [SerializeField] private RuntimeBuffDurationKind durationKind;
        [SerializeField] private int remainingTurns;
        [SerializeField] private int remainingUses;
        [SerializeField] private int currentStacks;
        [SerializeField] private int maxStacks;
        [SerializeField] private int appliedTurn;
        [SerializeField] private int triggerCount;
        [SerializeField] private bool isEnabled;
        [SerializeField] private bool isConsumed;

        public int BuffId => buffId;
        public string SourceActorId => sourceActorId;
        public RuntimeBuffDurationKind DurationKind => durationKind;
        public int RemainingTurns => remainingTurns;
        public int RemainingUses => remainingUses;
        public int CurrentStacks => currentStacks;
        public int MaxStacks => maxStacks;
        public int AppliedTurn => appliedTurn;
        public int TriggerCount => triggerCount;
        public bool IsEnabled => isEnabled;
        public bool IsConsumed => isConsumed;

        public bool IsActive
        {
            get
            {
                if (!isEnabled || isConsumed)
                {
                    return false;
                }

                switch (durationKind)
                {
                    case RuntimeBuffDurationKind.Instant:
                        return triggerCount == 0;
                    case RuntimeBuffDurationKind.Turns:
                        return remainingTurns > 0;
                    case RuntimeBuffDurationKind.Uses:
                        return remainingUses > 0;
                    case RuntimeBuffDurationKind.Battle:
                    case RuntimeBuffDurationKind.Run:
                        return true;
                    default:
                        return false;
                }
            }
        }

        public RuntimeBuffState(
            int buffId,
            string sourceActorId,
            RuntimeBuffDurationKind durationKind,
            int durationValue,
            int appliedTurn,
            int initialStacks = 1,
            int maxStacks = 1)
        {
            if (buffId <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(buffId));
            }

            this.buffId = buffId;
            this.sourceActorId = sourceActorId ?? string.Empty;
            this.durationKind = durationKind;
            this.appliedTurn = Math.Max(0, appliedTurn);
            this.maxStacks = Math.Max(1, maxStacks);
            currentStacks = Math.Max(0, Math.Min(initialStacks, this.maxStacks));
            remainingTurns = durationKind == RuntimeBuffDurationKind.Turns
                ? Math.Max(0, durationValue)
                : 0;
            remainingUses = durationKind == RuntimeBuffDurationKind.Uses
                ? Math.Max(0, durationValue)
                : 0;
            triggerCount = 0;
            isEnabled = true;
            isConsumed = false;
        }

        public static RuntimeBuffState FromDefinition(
            BuffData definition,
            string sourceActorId,
            RuntimeBuffDurationKind durationKind,
            int appliedTurn,
            int maxStacks = 1)
        {
            if (definition == null)
            {
                throw new ArgumentNullException(nameof(definition));
            }

            return new RuntimeBuffState(
                definition.Id,
                sourceActorId,
                durationKind,
                definition.RVal,
                appliedTurn,
                1,
                maxStacks);
        }

        public bool TryTrigger()
        {
            if (!IsActive)
            {
                return false;
            }

            triggerCount++;

            if (durationKind == RuntimeBuffDurationKind.Instant)
            {
                isConsumed = true;
            }
            else if (durationKind == RuntimeBuffDurationKind.Uses)
            {
                remainingUses = Math.Max(0, remainingUses - 1);
                isConsumed = remainingUses == 0;
            }

            return true;
        }

        public void TickTurnEnd()
        {
            if (!isEnabled || isConsumed || durationKind != RuntimeBuffDurationKind.Turns)
            {
                return;
            }

            remainingTurns = Math.Max(0, remainingTurns - 1);
            isConsumed = remainingTurns == 0;
        }

        public int AddStacks(int amount = 1)
        {
            if (amount <= 0 || isConsumed)
            {
                return currentStacks;
            }

            currentStacks = Math.Min(maxStacks, currentStacks + amount);
            return currentStacks;
        }

        public int RemoveStacks(int amount = 1)
        {
            if (amount <= 0)
            {
                return currentStacks;
            }

            currentStacks = Math.Max(0, currentStacks - amount);
            if (currentStacks == 0)
            {
                isConsumed = true;
            }

            return currentStacks;
        }

        public void Disable()
        {
            isEnabled = false;
        }

        public void Enable()
        {
            if (!isConsumed)
            {
                isEnabled = true;
            }
        }

        public void Consume()
        {
            isConsumed = true;
            remainingTurns = 0;
            remainingUses = 0;
        }

        public void Refresh(int durationValue)
        {
            isConsumed = false;
            isEnabled = true;
            triggerCount = 0;

            if (durationKind == RuntimeBuffDurationKind.Turns)
            {
                remainingTurns = Math.Max(0, durationValue);
            }
            else if (durationKind == RuntimeBuffDurationKind.Uses)
            {
                remainingUses = Math.Max(0, durationValue);
            }
        }

        public void OnBattleEnd()
        {
            if (durationKind == RuntimeBuffDurationKind.Battle)
            {
                Consume();
            }
        }

        public void OnRunEnd()
        {
            if (durationKind == RuntimeBuffDurationKind.Battle ||
                durationKind == RuntimeBuffDurationKind.Run)
            {
                Consume();
            }
        }
    }
}
