using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using CaveGame.GameData;

namespace CaveGame.GameData.Csv
{
    public enum CsvIssueSeverity
    {
        Warning,
        Error
    }

    public sealed class CsvValidationIssue
    {
        public CsvIssueSeverity Severity { get; private set; }
        public string FileName { get; private set; }
        public int LineNumber { get; private set; }
        public string ColumnName { get; private set; }
        public string Message { get; private set; }

        public CsvValidationIssue(
            CsvIssueSeverity severity,
            string fileName,
            int lineNumber,
            string columnName,
            string message)
        {
            Severity = severity;
            FileName = fileName ?? string.Empty;
            LineNumber = lineNumber;
            ColumnName = columnName ?? string.Empty;
            Message = message ?? string.Empty;
        }

        public override string ToString()
        {
            return $"[{Severity}] {FileName}:{LineNumber} column={ColumnName} - {Message}";
        }
    }

    public sealed class CsvValidationResult
    {
        private readonly List<CsvValidationIssue> issues = new List<CsvValidationIssue>();

        public IReadOnlyList<CsvValidationIssue> Issues => issues.AsReadOnly();

        public bool HasErrors
        {
            get
            {
                for (int i = 0; i < issues.Count; i++)
                {
                    if (issues[i].Severity == CsvIssueSeverity.Error)
                    {
                        return true;
                    }
                }

                return false;
            }
        }

        public void AddError(string fileName, int lineNumber, string columnName, string message)
        {
            issues.Add(new CsvValidationIssue(
                CsvIssueSeverity.Error, fileName, lineNumber, columnName, message));
        }

        public void AddWarning(string fileName, int lineNumber, string columnName, string message)
        {
            issues.Add(new CsvValidationIssue(
                CsvIssueSeverity.Warning, fileName, lineNumber, columnName, message));
        }

        public void Merge(CsvValidationResult other)
        {
            if (other == null)
            {
                return;
            }

            issues.AddRange(other.issues);
        }

        public string BuildMessage()
        {
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < issues.Count; i++)
            {
                builder.AppendLine(issues[i].ToString());
            }

            return builder.ToString();
        }
    }

    public static class CsvValueConverter
    {
        public static bool TryInt(string value, out int result)
        {
            return int.TryParse(
                value,
                NumberStyles.Integer,
                CultureInfo.InvariantCulture,
                out result);
        }

        public static bool TryFloat(string value, out float result)
        {
            return float.TryParse(
                value,
                NumberStyles.Float,
                CultureInfo.InvariantCulture,
                out result);
        }

        public static bool TryEnumNormalized<TEnum>(string value, out TEnum result)
            where TEnum : struct
        {
            string expected = NormalizeToken(value);
            Array enumValues = Enum.GetValues(typeof(TEnum));

            foreach (object enumValue in enumValues)
            {
                string name = Enum.GetName(typeof(TEnum), enumValue);
                if (NormalizeToken(name) == expected)
                {
                    result = (TEnum)enumValue;
                    return true;
                }
            }

            result = default(TEnum);
            return false;
        }

        public static bool TrySubject(string value, out SchoolSubject subject)
        {
            string token = (value ?? string.Empty).Trim();
            switch (token)
            {
                case "理科":
                    subject = SchoolSubject.Science;
                    return true;
                case "数学":
                    subject = SchoolSubject.Math;
                    return true;
                case "日本史":
                    subject = SchoolSubject.JapaneseHistory;
                    return true;
                default:
                    return TryEnumNormalized(token, out subject);
            }
        }

        private static string NormalizeToken(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return string.Empty;
            }

            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < value.Length; i++)
            {
                char c = value[i];
                if (c != '_' && c != '-' && !char.IsWhiteSpace(c))
                {
                    builder.Append(char.ToUpperInvariant(c));
                }
            }

            return builder.ToString();
        }
    }

    public static class CsvDataValidator
    {
        private static readonly string[] CharacterRequiredColumns =
        {
            "id", "character_name", "max_hp", "attack", "defense", "speed",
            "skill_1_id", "description"
        };

        private static readonly string[] SkillRequiredColumns =
        {
            "id", "skill_name", "target", "n_val", "s_val", "r_val", "hits",
            "buff_group", "effect_type", "description"
        };

        private static readonly string[] BuffRequiredColumns =
        {
            "id", "buff_name", "subject", "grade", "unit", "reward_tier",
            "n_val", "s_val", "r_val", "multiplier", "max_multiplier",
            "trigger_type", "effect_type", "buff_group", "hint", "battle_hint",
            "description"
        };

        public static CsvValidationResult ValidateCharacters(CsvDocument document, string fileName)
        {
            CsvValidationResult result = ValidateDocument(document, fileName, CharacterRequiredColumns);
            if (document == null)
            {
                return result;
            }

            HashSet<int> ids = new HashSet<int>();
            foreach (CsvRow row in document.Rows)
            {
                ValidatePositiveId(row, fileName, ids, result);
                ValidateNonNegativeInt(row, fileName, "max_hp", result, false);
                ValidateNonNegativeInt(row, fileName, "attack", result, true);
                ValidateNonNegativeInt(row, fileName, "defense", result, true);
                ValidateInt(row, fileName, "speed", result);
                ValidatePositiveInt(row, fileName, "skill_1_id", result);
                ValidateOptionalPositiveInt(row, fileName, "skill_2_id", result);
                ValidateOptionalPositiveInt(row, fileName, "skill_3_id", result);
                ValidateNotBlank(row, fileName, "character_name", result);
            }

            return result;
        }

        public static CsvValidationResult ValidateSkills(CsvDocument document, string fileName)
        {
            CsvValidationResult result = ValidateDocument(document, fileName, SkillRequiredColumns);
            if (document == null)
            {
                return result;
            }

            HashSet<int> ids = new HashSet<int>();
            foreach (CsvRow row in document.Rows)
            {
                ValidatePositiveId(row, fileName, ids, result);
                ValidateNotBlank(row, fileName, "skill_name", result);
                ValidateInt(row, fileName, "n_val", result);
                ValidateInt(row, fileName, "s_val", result);
                ValidateNonNegativeInt(row, fileName, "r_val", result, true);
                ValidateNonNegativeInt(row, fileName, "hits", result, false);
                ValidateEnum<SkillTarget>(row, fileName, "target", result);
                ValidateEnum<GameEffectType>(row, fileName, "effect_type", result);
            }

            return result;
        }

        public static CsvValidationResult ValidateBuffs(
            CsvDocument document,
            string fileName,
            SchoolSubject expectedSubject)
        {
            CsvValidationResult result = ValidateDocument(document, fileName, BuffRequiredColumns);
            if (document == null)
            {
                return result;
            }

            HashSet<int> ids = new HashSet<int>();
            foreach (CsvRow row in document.Rows)
            {
                ValidatePositiveId(row, fileName, ids, result);
                ValidateNotBlank(row, fileName, "buff_name", result);
                ValidateInt(row, fileName, "n_val", result);
                ValidateInt(row, fileName, "s_val", result);
                ValidateNonNegativeInt(row, fileName, "r_val", result, true);
                ValidateFloat(row, fileName, "multiplier", result);
                ValidateFloat(row, fileName, "max_multiplier", result);
                ValidateEnum<RewardTier>(row, fileName, "reward_tier", result);
                ValidateEnum<BuffTriggerType>(row, fileName, "trigger_type", result);
                ValidateEnum<GameEffectType>(row, fileName, "effect_type", result);

                SchoolSubject actualSubject;
                if (!CsvValueConverter.TrySubject(row.Get("subject"), out actualSubject))
                {
                    result.AddError(fileName, row.LineNumber, "subject", "認識できない教科です。");
                }
                else if (actualSubject != expectedSubject)
                {
                    result.AddError(
                        fileName,
                        row.LineNumber,
                        "subject",
                        $"ファイルの教科と一致しません。期待値={expectedSubject}, 実際={actualSubject}");
                }

                float multiplier;
                float maxMultiplier;
                if (CsvValueConverter.TryFloat(row.Get("multiplier"), out multiplier) &&
                    CsvValueConverter.TryFloat(row.Get("max_multiplier"), out maxMultiplier) &&
                    maxMultiplier < multiplier)
                {
                    result.AddError(
                        fileName,
                        row.LineNumber,
                        "max_multiplier",
                        "max_multiplierはmultiplier以上である必要があります。");
                }
            }

            return result;
        }

        private static CsvValidationResult ValidateDocument(
            CsvDocument document,
            string fileName,
            IEnumerable<string> requiredColumns)
        {
            CsvValidationResult result = new CsvValidationResult();
            if (document == null)
            {
                result.AddError(fileName, 0, string.Empty, "CSVドキュメントがnullです。");
                return result;
            }

            foreach (string column in requiredColumns)
            {
                if (!document.HasColumn(column))
                {
                    result.AddError(fileName, 1, column, "必須列がありません。");
                }
            }

            if (document.Rows.Count == 0)
            {
                result.AddWarning(fileName, 1, string.Empty, "データ行がありません。");
            }

            return result;
        }

        private static void ValidatePositiveId(
            CsvRow row,
            string fileName,
            ISet<int> ids,
            CsvValidationResult result)
        {
            int id;
            if (!CsvValueConverter.TryInt(row.Get("id"), out id) || id <= 0)
            {
                result.AddError(fileName, row.LineNumber, "id", "1以上の整数が必要です。");
                return;
            }

            if (!ids.Add(id))
            {
                result.AddError(fileName, row.LineNumber, "id", $"ID {id} が重複しています。");
            }
        }

        private static void ValidateNotBlank(
            CsvRow row,
            string fileName,
            string column,
            CsvValidationResult result)
        {
            if (string.IsNullOrWhiteSpace(row.Get(column)))
            {
                result.AddError(fileName, row.LineNumber, column, "値が空です。");
            }
        }

        private static void ValidateInt(
            CsvRow row,
            string fileName,
            string column,
            CsvValidationResult result)
        {
            int ignored;
            if (!CsvValueConverter.TryInt(row.Get(column), out ignored))
            {
                result.AddError(fileName, row.LineNumber, column, "整数へ変換できません。");
            }
        }

        private static void ValidatePositiveInt(
            CsvRow row,
            string fileName,
            string column,
            CsvValidationResult result)
        {
            int value;
            if (!CsvValueConverter.TryInt(row.Get(column), out value) || value <= 0)
            {
                result.AddError(fileName, row.LineNumber, column, "1以上の整数が必要です。");
            }
        }

        private static void ValidateOptionalPositiveInt(
            CsvRow row,
            string fileName,
            string column,
            CsvValidationResult result)
        {
            string raw = row.Get(column);
            if (string.IsNullOrWhiteSpace(raw))
            {
                return;
            }

            int value;
            if (!CsvValueConverter.TryInt(raw, out value) || value <= 0)
            {
                result.AddError(fileName, row.LineNumber, column, "空欄または1以上の整数が必要です。");
            }
        }

        private static void ValidateNonNegativeInt(
            CsvRow row,
            string fileName,
            string column,
            CsvValidationResult result,
            bool allowZero)
        {
            int value;
            int minimum = allowZero ? 0 : 1;
            if (!CsvValueConverter.TryInt(row.Get(column), out value) || value < minimum)
            {
                result.AddError(fileName, row.LineNumber, column, $"{minimum}以上の整数が必要です。");
            }
        }

        private static void ValidateFloat(
            CsvRow row,
            string fileName,
            string column,
            CsvValidationResult result)
        {
            float ignored;
            if (!CsvValueConverter.TryFloat(row.Get(column), out ignored))
            {
                result.AddError(fileName, row.LineNumber, column, "小数へ変換できません。小数点にはピリオドを使用してください。");
            }
        }

        private static void ValidateEnum<TEnum>(
            CsvRow row,
            string fileName,
            string column,
            CsvValidationResult result)
            where TEnum : struct
        {
            TEnum ignored;
            if (!CsvValueConverter.TryEnumNormalized(row.Get(column), out ignored))
            {
                result.AddError(
                    fileName,
                    row.LineNumber,
                    column,
                    $"{typeof(TEnum).Name}として認識できない値です: '{row.Get(column)}'");
            }
        }
    }
}
