using System;
using System.Collections.Generic;
using System.Globalization;
using CaveGame.GameData.Csv;
using UnityEngine;

namespace CaveGame.CaveBattle
{
    public sealed class CaveBattleDataLoadException : Exception
    {
        public CaveBattleDataLoadException(string message)
            : base(message)
        {
        }

        public CaveBattleDataLoadException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }

    /// <summary>
    /// 読込済みのキャラクター・技データをIDで提供する。
    /// Phase/Controllerはこのリポジトリだけを参照し、CSVを直接読まない。
    /// </summary>
    public sealed class CaveBattleDataRepository
    {
        private readonly Dictionary<int, CaveBattleCharacter> characters =
            new Dictionary<int, CaveBattleCharacter>();
        private readonly Dictionary<int, CaveBattleSkill> skills =
            new Dictionary<int, CaveBattleSkill>();

        public IReadOnlyDictionary<int, CaveBattleCharacter> Characters => characters;
        public IReadOnlyDictionary<int, CaveBattleSkill> Skills => skills;

        public CaveBattleCharacter GetCharacter(int id)
        {
            if (!characters.TryGetValue(id, out CaveBattleCharacter data))
            {
                throw new KeyNotFoundException($"Character IDが存在しません: {id}");
            }

            return data;
        }

        public bool TryGetCharacter(int id, out CaveBattleCharacter data)
        {
            return characters.TryGetValue(id, out data);
        }

        public CaveBattleSkill GetSkill(int id)
        {
            if (!skills.TryGetValue(id, out CaveBattleSkill data))
            {
                throw new KeyNotFoundException($"Skill IDが存在しません: {id}");
            }

            return data;
        }

        public bool TryGetSkill(int id, out CaveBattleSkill data)
        {
            return skills.TryGetValue(id, out data);
        }

        /// <summary>
        /// 各キャラクターのskill_turn_1 / skill_turn_2がskills.csvに実在するかを検証する。
        /// </summary>
        public IReadOnlyList<string> ValidateReferences()
        {
            List<string> errors = new List<string>();

            foreach (KeyValuePair<int, CaveBattleCharacter> pair in characters)
            {
                CaveBattleCharacter character = pair.Value;

                if (!skills.ContainsKey(character.SkillTurn1Id))
                {
                    errors.Add(
                        $"Character ID {character.Id} ({character.CharacterName}) の" +
                        $"skill_turn_1 ({character.SkillTurn1Id}) がskillsに存在しません。");
                }

                if (!skills.ContainsKey(character.SkillTurn2Id))
                {
                    errors.Add(
                        $"Character ID {character.Id} ({character.CharacterName}) の" +
                        $"skill_turn_2 ({character.SkillTurn2Id}) がskillsに存在しません。");
                }
            }

            return errors.AsReadOnly();
        }

        internal void AddCharacter(CaveBattleCharacter data)
        {
            if (characters.ContainsKey(data.Id))
            {
                throw new CaveBattleDataLoadException($"Character ID {data.Id} が重複しています。");
            }

            characters.Add(data.Id, data);
        }

        internal void AddSkill(CaveBattleSkill data)
        {
            if (skills.ContainsKey(data.Id))
            {
                throw new CaveBattleDataLoadException($"Skill ID {data.Id} が重複しています。");
            }

            skills.Add(data.Id, data);
        }
    }

    /// <summary>
    /// Assets/Resources配下の戦闘用CSV（キャラクター・技）を起動時に読み込む。
    /// Resourcesパスには拡張子を付けない。
    /// </summary>
    [DefaultExecutionOrder(-1000)]
    public sealed class CaveBattleDataLoader : MonoBehaviour
    {
        [Header("Load Settings")]
        [SerializeField] private bool loadOnAwake = true;

        [Header("Resources Paths (拡張子なし)")]
        [SerializeField] private string charactersPath = "characters/japanese_history_chars_expanded";
        [SerializeField] private string skillsPath = "skills/japanese_history_skills_expanded";

        public CaveBattleDataRepository Repository { get; private set; }
        public bool IsLoaded => Repository != null;

        private void Awake()
        {
            if (loadOnAwake)
            {
                LoadAll();
            }
        }

        public CaveBattleDataRepository LoadAll()
        {
            try
            {
                CsvDocument charactersDoc = LoadCsv(charactersPath);
                CsvDocument skillsDoc = LoadCsv(skillsPath);

                CaveBattleDataRepository repository = new CaveBattleDataRepository();

                foreach (CsvRow row in charactersDoc.Rows)
                {
                    repository.AddCharacter(ParseCharacter(row));
                }

                foreach (CsvRow row in skillsDoc.Rows)
                {
                    repository.AddSkill(ParseSkill(row));
                }

                IReadOnlyList<string> referenceErrors = repository.ValidateReferences();
                if (referenceErrors.Count > 0)
                {
                    throw new CaveBattleDataLoadException(string.Join("\n", referenceErrors));
                }

                Repository = repository;
                Debug.Log(
                    $"[CaveBattleDataLoader] 読込完了: " +
                    $"Characters={repository.Characters.Count}, Skills={repository.Skills.Count}");

                return repository;
            }
            catch (CaveBattleDataLoadException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw new CaveBattleDataLoadException("戦闘用CSVの読込中にエラーが発生しました。", ex);
            }
        }

        private static CsvDocument LoadCsv(string resourcesPath)
        {
            if (string.IsNullOrWhiteSpace(resourcesPath))
            {
                throw new CaveBattleDataLoadException("Resourcesパスが空です。");
            }

            TextAsset asset = Resources.Load<TextAsset>(resourcesPath);
            if (asset == null)
            {
                throw new CaveBattleDataLoadException(
                    $"CSVが見つかりません: Assets/Resources/{resourcesPath}.csv");
            }

            try
            {
                return CsvParser.Parse(asset.text);
            }
            catch (Exception ex)
            {
                throw new CaveBattleDataLoadException($"CSVを解析できません: {asset.name}.csv", ex);
            }
        }

        private static CaveBattleCharacter ParseCharacter(CsvRow row)
        {
            int? passiveSkillId = ParseOptionalId(row.Get("passive_skill"));

            return new CaveBattleCharacter(
                RequiredInt(row, "id"),
                row.GetRequired("char_name"),
                RequiredInt(row, "rank"),
                RequiredInt(row, "hp"),
                RequiredInt(row, "base_attack"),
                RequiredInt(row, "base_speed"),
                RequiredInt(row, "skill_turn_1"),
                RequiredInt(row, "skill_turn_2"),
                passiveSkillId,
                row.Get("description"));
        }

        private static CaveBattleSkill ParseSkill(CsvRow row)
        {
            return new CaveBattleSkill(
                RequiredInt(row, "id"),
                row.GetRequired("skill_name"),
                row.Get("target"),
                RequiredInt(row, "n_val"),
                RequiredInt(row, "s_val"),
                RequiredInt(row, "r_val"),
                RequiredInt(row, "hits"),
                row.Get("effect_type"),
                row.Get("params"),
                row.Get("description"));
        }

        private static int RequiredInt(CsvRow row, string column)
        {
            string raw = row.GetRequired(column);
            if (!int.TryParse(raw, NumberStyles.Integer, CultureInfo.InvariantCulture, out int value))
            {
                throw new CaveBattleDataLoadException($"'{column}' を整数へ変換できません (値: '{raw}')。");
            }

            return value;
        }

        /// <summary>
        /// passive_skill列は "6060.0" のように小数表記で保存されている場合があるため、
        /// 小数として読み取ってから四捨五入して整数化する。空欄はnullを返す。
        /// </summary>
        private static int? ParseOptionalId(string raw)
        {
            if (string.IsNullOrWhiteSpace(raw))
            {
                return null;
            }

            if (double.TryParse(raw, NumberStyles.Float, CultureInfo.InvariantCulture, out double value))
            {
                return (int)Math.Round(value, MidpointRounding.AwayFromZero);
            }

            return null;
        }
    }
}
