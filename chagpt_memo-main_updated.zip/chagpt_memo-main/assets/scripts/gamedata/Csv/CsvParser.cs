using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace CaveGame.GameData.Csv
{
    public sealed class CsvParseException : Exception
    {
        public int LineNumber { get; private set; }

        public CsvParseException(string message, int lineNumber)
            : base($"CSV解析エラー (line {lineNumber}): {message}")
        {
            LineNumber = lineNumber;
        }
    }

    public sealed class CsvRow
    {
        private readonly IReadOnlyDictionary<string, string> values;

        public int LineNumber { get; private set; }
        public IReadOnlyDictionary<string, string> Values => values;

        internal CsvRow(int lineNumber, IDictionary<string, string> values)
        {
            LineNumber = lineNumber;
            this.values = new ReadOnlyDictionary<string, string>(
                new Dictionary<string, string>(values, StringComparer.OrdinalIgnoreCase));
        }

        public string Get(string columnName)
        {
            string value;
            return values.TryGetValue(columnName, out value)
                ? value
                : string.Empty;
        }

        public string GetRequired(string columnName)
        {
            string value;
            if (!values.TryGetValue(columnName, out value))
            {
                throw new CsvParseException(
                    $"必須列 '{columnName}' が存在しません。",
                    LineNumber);
            }

            if (string.IsNullOrWhiteSpace(value))
            {
                throw new CsvParseException(
                    $"必須列 '{columnName}' の値が空です。",
                    LineNumber);
            }

            return value;
        }
    }

    public sealed class CsvDocument
    {
        public IReadOnlyList<string> Headers { get; private set; }
        public IReadOnlyList<CsvRow> Rows { get; private set; }

        internal CsvDocument(IList<string> headers, IList<CsvRow> rows)
        {
            Headers = new ReadOnlyCollection<string>(headers);
            Rows = new ReadOnlyCollection<CsvRow>(rows);
        }

        public bool HasColumn(string columnName)
        {
            for (int i = 0; i < Headers.Count; i++)
            {
                if (string.Equals(Headers[i], columnName, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }
    }

    /// <summary>
    /// カンマ、CRLF/LF、引用符、引用符内改行、二重引用符エスケープに対応するCSV解析器。
    /// string.Split(',')を使用しないため、説明文にカンマが入っても列が崩れない。
    /// </summary>
    public static class CsvParser
    {
        public static CsvDocument Parse(string csvText)
        {
            if (csvText == null)
            {
                throw new ArgumentNullException(nameof(csvText));
            }

            if (csvText.Length > 0 && csvText[0] == '\uFEFF')
            {
                csvText = csvText.Substring(1);
            }

            List<RawRow> rawRows = ReadRawRows(csvText);
            if (rawRows.Count == 0)
            {
                throw new CsvParseException("ヘッダー行がありません。", 1);
            }

            RawRow headerRow = rawRows[0];
            List<string> headers = new List<string>();
            HashSet<string> headerSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            for (int i = 0; i < headerRow.Fields.Count; i++)
            {
                string header = (headerRow.Fields[i] ?? string.Empty).Trim();
                if (header.Length == 0)
                {
                    throw new CsvParseException($"{i + 1}列目のヘッダーが空です。", headerRow.LineNumber);
                }

                if (!headerSet.Add(header))
                {
                    throw new CsvParseException($"ヘッダー '{header}' が重複しています。", headerRow.LineNumber);
                }

                headers.Add(header);
            }

            List<CsvRow> rows = new List<CsvRow>();
            for (int rowIndex = 1; rowIndex < rawRows.Count; rowIndex++)
            {
                RawRow rawRow = rawRows[rowIndex];
                if (rawRow.Fields.Count > headers.Count)
                {
                    throw new CsvParseException(
                        $"列数が多すぎます。期待値={headers.Count}, 実際={rawRow.Fields.Count}",
                        rawRow.LineNumber);
                }

                Dictionary<string, string> values =
                    new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

                for (int columnIndex = 0; columnIndex < headers.Count; columnIndex++)
                {
                    string value = columnIndex < rawRow.Fields.Count
                        ? rawRow.Fields[columnIndex]
                        : string.Empty;
                    values[headers[columnIndex]] = value;
                }

                rows.Add(new CsvRow(rawRow.LineNumber, values));
            }

            return new CsvDocument(headers, rows);
        }

        private static List<RawRow> ReadRawRows(string text)
        {
            List<RawRow> rows = new List<RawRow>();
            List<string> fields = new List<string>();
            StringBuilder field = new StringBuilder();
            bool inQuotes = false;
            bool quoteClosed = false;
            int line = 1;
            int rowStartLine = 1;

            for (int i = 0; i < text.Length; i++)
            {
                char current = text[i];

                if (inQuotes)
                {
                    if (current == '"')
                    {
                        if (i + 1 < text.Length && text[i + 1] == '"')
                        {
                            field.Append('"');
                            i++;
                        }
                        else
                        {
                            inQuotes = false;
                            quoteClosed = true;
                        }
                    }
                    else
                    {
                        field.Append(current);
                        if (current == '\n')
                        {
                            line++;
                        }
                    }

                    continue;
                }

                if (quoteClosed && current != ',' && current != '\r' && current != '\n')
                {
                    if (!char.IsWhiteSpace(current))
                    {
                        throw new CsvParseException("閉じ引用符の後に不正な文字があります。", line);
                    }

                    continue;
                }

                if (current == '"')
                {
                    if (field.Length != 0)
                    {
                        throw new CsvParseException("フィールド途中の引用符は使用できません。", line);
                    }

                    inQuotes = true;
                    quoteClosed = false;
                }
                else if (current == ',')
                {
                    fields.Add(field.ToString());
                    field.Clear();
                    quoteClosed = false;
                }
                else if (current == '\r' || current == '\n')
                {
                    if (current == '\r' && i + 1 < text.Length && text[i + 1] == '\n')
                    {
                        i++;
                    }

                    fields.Add(field.ToString());
                    AddRowIfNotBlank(rows, fields, rowStartLine);
                    fields = new List<string>();
                    field.Clear();
                    quoteClosed = false;
                    line++;
                    rowStartLine = line;
                }
                else
                {
                    field.Append(current);
                }
            }

            if (inQuotes)
            {
                throw new CsvParseException("引用符が閉じられていません。", rowStartLine);
            }

            if (field.Length > 0 || fields.Count > 0 || quoteClosed)
            {
                fields.Add(field.ToString());
                AddRowIfNotBlank(rows, fields, rowStartLine);
            }

            return rows;
        }

        private static void AddRowIfNotBlank(List<RawRow> rows, List<string> fields, int lineNumber)
        {
            bool hasValue = false;
            for (int i = 0; i < fields.Count; i++)
            {
                if (!string.IsNullOrWhiteSpace(fields[i]))
                {
                    hasValue = true;
                    break;
                }
            }

            if (hasValue)
            {
                rows.Add(new RawRow(lineNumber, new List<string>(fields)));
            }
        }

        private sealed class RawRow
        {
            public int LineNumber { get; private set; }
            public List<string> Fields { get; private set; }

            public RawRow(int lineNumber, List<string> fields)
            {
                LineNumber = lineNumber;
                Fields = fields;
            }
        }
    }
}
