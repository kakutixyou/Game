using System;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;
using CaveGame.GameData;

namespace CaveGame.GameData.Csv
{
    public sealed class GameDataLoadException : Exception
    {
        public GameDataLoadException(string message)
            : base(message)
        {
        }

        public GameDataLoadException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }

    /// <summary>
    /// Assets/Resources配下の5種類のCSVを起動時に型付きデータへ変換する。
    /// Resourcesパスには拡張子を付けない。
    /// </summary>
    [DefaultExecutionOrder(-1000)]
    public sealed class GameDataLoader : MonoBehaviour
    {
        [Header("Load Settings")]
        [SerializeField] private bool loadOnAwake = true;
        [SerializeField] private bool throwOnValidationError = true;

        [Header("Resources Paths (without extension)")]
        [SerializeField] private string charactersPath = "GameData/Characters/characters";
        [SerializeField] private string skillsPath = "GameData/Skills/skills";
        [SerializeField] private string scienceBuffsPath = "GameData/Buffs/science_buffs";
        [SerializeField] private string mathBuffsPath = "GameData/Buffs/math_buffs";
        [SerializeField] private string historyBuffsPath = "GameData/Buffs/history_buffs";

        public GameDataRepository Repository { get; private set; }
        public CsvValidationResult LastValidationResult { get; private set; }
        public bool IsLoaded => Repository != null && Repository.IsLoaded;

        private void Awake()
        {
            if (loadOnAwake)
            {
                LoadAll();
            }
        }

        public GameDataRepository LoadAll()
        {
            try
            {
                LoadedCsv characters = LoadCsv(charactersPath);
                LoadedCsv skills = LoadCsv(skillsPath);
                LoadedCsv science = LoadCsv(scienceBuffsPath);
                LoadedCsv math = LoadCsv(mathBuffsPath);
                LoadedCsv history = LoadCsv(historyBuffsPath);

                CsvValidationResult validation = new CsvValidationResult();
                validation.Merge(CsvDataValidator.ValidateCharacters(characters.Document, characters.FileName));
                validation.Merge(CsvDataValidator.ValidateSkills(skills.Document, skills.FileName));
                validation.Merge(CsvDataValidator.ValidateBuffs(
                    science.Document, science.FileName, SchoolSubject.Science));
                validation.Merge(CsvDataValidator.ValidateBuffs(
                    math.Document, math.FileName, SchoolSubject.Math));
                validation.Merge(CsvDataValidator.ValidateBuffs(
                    history.Document, history.FileName, SchoolSubject.JapaneseHistory));
                LastValidationResult = validation;

                LogValidation(validation);
                if (validation.HasErrors)
                {
                    string message = "ゲームデータCSVの検証に失敗しました。\n" + validation.BuildMessage();
                    if (throwOnValidationError)
                    {
                        throw new GameDataLoadException(message);
                    }

                    Debug.LogError(message);
                    Repository = null;
                    return null;
                }

                GameDataRepository temporaryRepository = new GameDataRepository();
                AddCharacters(temporaryRepository, characters.Document);
                AddSkills(temporaryRepository, skills.Document);
                AddBuffs(temporaryRepository, science.Document, SchoolSubject.Science);
                AddBuffs(temporaryRepository, math.Document, SchoolSubject.Math);
                AddBuffs(temporaryRepository, history.Document, SchoolSubject.JapaneseHistory);
                temporaryRepository.MarkLoaded();

                Repository = temporaryRepository;
                Debug.Log(
                    $"[GameDataLoader] 読込完了: " +
                    $"Characters={Repository.Characters.Count}, " +
                    $"Skills={Repository.Skills.Count}, " +
                    $"ScienceBuffs={Repository.ScienceBuffs.Count}, " +
                    $"MathBuffs={Repository.MathBuffs.Count}, " +
                    $"HistoryBuffs={Repository.HistoryBuffs.Count}");

                return Repository;
            }
            catch (GameDataLoadException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw new GameDataLoadException("ゲームデータの一括読込中にエラーが発生しました。", ex);
            }
        }

        private static LoadedCsv LoadCsv(string resourcesPath)
        {
            if (string.IsNullOrWhiteSpace(resourcesPath))
            {
                throw new GameDataLoadException("Resourcesパスが空です。");
            }

            TextAsset asset = Resources.Load<TextAsset>(resourcesPath);
            if (asset == null)
            {
                throw new GameDataLoadException(
                    $"CSVが見つかりません: Assets/Resources/{resourcesPath}.csv");
            }

            try
            {
                return new LoadedCsv(asset.name + ".csv", CsvParser.Parse(asset.text));
            }
            catch (Exception ex)
            {
                throw new GameDataLoadException($"CSVを解析できません: {asset.name}.csv", ex);
            }
        }

        private static void AddCharacters(GameDataRepository repository, CsvDocument document)
        {
            foreach (CsvRow row in document.Rows)
            {
                List<int> skillIds = new List<int>();
                AddOptionalPositiveInt(skillIds, row.Get("skill_1_id"));
                AddOptionalPositiveInt(skillIds, row.Get("skill_2_id"));
                AddOptionalPositiveInt(skillIds, row.Get("skill_3_id"));

                repository.Add(new CharacterData(
                    RequiredInt(row, "id"),
                    row.GetRequired("character_name"),
                    RequiredInt(row, "max_hp"),
                    RequiredInt(row, "attack"),
                    RequiredInt(row, "defense"),
                    RequiredInt(row, "speed"),
                    skillIds,
                    row.Get("description")));
            }
        }

        private static void AddSkills(GameDataRepository repository, CsvDocument document)
        {
            foreach (CsvRow row in document.Rows)
            {
                SkillTarget target = RequiredEnum<SkillTarget>(row, "target");
                GameEffectType effectType = RequiredEnum<GameEffectType>(row, "effect_type");

                repository.Add(new SkillData(
                    RequiredInt(row, "id"),
                    row.GetRequired("skill_name"),
                    target,
                    RequiredInt(row, "n_val"),
                    RequiredInt(row, "s_val"),
                    RequiredInt(row, "r_val"),
                    RequiredInt(row, "hits"),
                    row.Get("buff_group"),
                    effectType,
                    row.Get("description")));
            }
        }

        private static void AddBuffs(
            GameDataRepository repository,
            CsvDocument document,
            SchoolSubject subject)
        {
            foreach (CsvRow row in document.Rows)
            {
                int id = RequiredInt(row, "id");
                string name = row.GetRequired("buff_name");
                string grade = row.Get("grade");
                string unit = row.Get("unit");
                RewardTier rewardTier = RequiredEnum<RewardTier>(row, "reward_tier");
                int nVal = RequiredInt(row, "n_val");
                int sVal = RequiredInt(row, "s_val");
                int rVal = RequiredInt(row, "r_val");
                float multiplier = RequiredFloat(row, "multiplier");
                float maxMultiplier = RequiredFloat(row, "max_multiplier");
                BuffTriggerType triggerType = RequiredEnum<BuffTriggerType>(row, "trigger_type");
                GameEffectType effectType = RequiredEnum<GameEffectType>(row, "effect_type");
                string buffGroup = row.Get("buff_group");
                string hint = row.Get("hint");
                string battleHint = row.Get("battle_hint");
                string description = row.Get("description");

                switch (subject)
                {
                    case SchoolSubject.Science:
                        repository.Add(new ScienceBuffData(
                            id, name, grade, unit, rewardTier, nVal, sVal, rVal,
                            multiplier, maxMultiplier, triggerType, effectType,
                            buffGroup, hint, battleHint, description));
                        break;

                    case SchoolSubject.Math:
                        repository.Add(new MathBuffData(
                            id, name, grade, unit, rewardTier, nVal, sVal, rVal,
                            multiplier, maxMultiplier, triggerType, effectType,
                            buffGroup, hint, battleHint, description));
                        break;

                    case SchoolSubject.JapaneseHistory:
                        repository.Add(new HistoryBuffData(
                            id, name, grade, unit, rewardTier, nVal, sVal, rVal,
                            multiplier, maxMultiplier, triggerType, effectType,
                            buffGroup, hint, battleHint, description));
                        break;

                    default:
                        throw new GameDataLoadException($"未対応の教科です: {subject}");
                }
            }
        }

        private static int RequiredInt(CsvRow row, string column)
        {
            int value;
            if (!CsvValueConverter.TryInt(row.GetRequired(column), out value))
            {
                throw new CsvParseException($"'{column}' を整数へ変換できません。", row.LineNumber);
            }

            return value;
        }

        private static float RequiredFloat(CsvRow row, string column)
        {
            float value;
            if (!float.TryParse(
                row.GetRequired(column),
                NumberStyles.Float,
                CultureInfo.InvariantCulture,
                out value))
            {
                throw new CsvParseException($"'{column}' を小数へ変換できません。", row.LineNumber);
            }

            return value;
        }

        private static TEnum RequiredEnum<TEnum>(CsvRow row, string column)
            where TEnum : struct
        {
            TEnum value;
            if (!CsvValueConverter.TryEnumNormalized(row.GetRequired(column), out value))
            {
                throw new CsvParseException(
                    $"'{column}' を{typeof(TEnum).Name}へ変換できません。",
                    row.LineNumber);
            }

            return value;
        }

        private static void AddOptionalPositiveInt(ICollection<int> destination, string rawValue)
        {
            if (string.IsNullOrWhiteSpace(rawValue))
            {
                return;
            }

            int value;
            if (CsvValueConverter.TryInt(rawValue, out value) && value > 0)
            {
                destination.Add(value);
            }
        }

        private static void LogValidation(CsvValidationResult result)
        {
            foreach (CsvValidationIssue issue in result.Issues)
            {
                if (issue.Severity == CsvIssueSeverity.Error)
                {
                    Debug.LogError(issue.ToString());
                }
                else
                {
                    Debug.LogWarning(issue.ToString());
                }
            }
        }

        private sealed class LoadedCsv
        {
            public string FileName { get; private set; }
            public CsvDocument Document { get; private set; }

            public LoadedCsv(string fileName, CsvDocument document)
            {
                FileName = fileName;
                Document = document;
            }
        }
    }
}
