using System;
using System.Collections.Generic;
using System.Globalization;
using CaveGame.GameData.Csv;
using UnityEngine;

namespace CaveGame.CaveBattle
{
    /// <summary>
    /// 科目別バフの読込結果。
    ///
    /// 重要: ここに入っているのは「どんなバフが存在するか」というデータのみ。
    /// Mathbahu/Siencebahu合わせて約50種、nihonsi_bahuに25種、
    /// それぞれeffect_typeごとに全く異なる計算式を持つため、
    /// TwoTurnBattlePhase側の戦闘計算に個別のロジックとしてはまだ接続していない。
    /// 現状「ダンジョンで何のバフを何個持っているか」を保持・表示するところまでが対応範囲。
    /// 優先して実装したい効果があれば、そこから1つずつ実装していく想定。
    /// </summary>
    public sealed class CaveBattleBuffRepository
    {
        private readonly Dictionary<int, CaveSubjectBuffData> mathBuffs =
            new Dictionary<int, CaveSubjectBuffData>();
        private readonly Dictionary<int, CaveSubjectBuffData> scienceBuffs =
            new Dictionary<int, CaveSubjectBuffData>();
        private readonly Dictionary<int, CaveHistoryBuffData> historyBuffs =
            new Dictionary<int, CaveHistoryBuffData>();

        public IReadOnlyDictionary<int, CaveSubjectBuffData> MathBuffs => mathBuffs;
        public IReadOnlyDictionary<int, CaveSubjectBuffData> ScienceBuffs => scienceBuffs;
        public IReadOnlyDictionary<int, CaveHistoryBuffData> HistoryBuffs => historyBuffs;

        /// <summary>
        /// 指定した科目のバフ一覧を取得する（History以外はCaveSubjectBuffData、Historyは別型のためHistoryBuffsを直接見る）。
        /// </summary>
        public IReadOnlyDictionary<int, CaveSubjectBuffData> GetSubjectBuffs(CaveBuffSubject subject)
        {
            switch (subject)
            {
                case CaveBuffSubject.Math:
                    return mathBuffs;
                case CaveBuffSubject.Science:
                    return scienceBuffs;
                default:
                    return new Dictionary<int, CaveSubjectBuffData>();
            }
        }

        /// <summary>
        /// このイベントで次に引くバフを1つ選ぶ（現状は単純な重み無し抽選のプレースホルダー）。
        /// 数学バフCSVの2307「確率の偏り」のような「上位候補の重みを上げる」効果は未反映。
        /// </summary>
        public CaveSubjectBuffData DrawRandomSubjectBuff(CaveBuffSubject subject)
        {
            IReadOnlyDictionary<int, CaveSubjectBuffData> pool = GetSubjectBuffs(subject);
            if (pool.Count == 0)
            {
                return null;
            }

            List<CaveSubjectBuffData> values = new List<CaveSubjectBuffData>(pool.Values);
            return values[UnityEngine.Random.Range(0, values.Count)];
        }

        public CaveHistoryBuffData DrawRandomHistoryBuff()
        {
            if (historyBuffs.Count == 0)
            {
                return null;
            }

            List<CaveHistoryBuffData> values = new List<CaveHistoryBuffData>(historyBuffs.Values);
            return values[UnityEngine.Random.Range(0, values.Count)];
        }

        internal void AddMathBuff(CaveSubjectBuffData data) => AddUnique(mathBuffs, data.Id, data, "Math");
        internal void AddScienceBuff(CaveSubjectBuffData data) => AddUnique(scienceBuffs, data.Id, data, "Science");
        internal void AddHistoryBuff(CaveHistoryBuffData data) => AddUnique(historyBuffs, data.Id, data, "History");

        private static void AddUnique<T>(Dictionary<int, T> dict, int id, T value, string poolName)
        {
            if (dict.ContainsKey(id))
            {
                throw new CaveBattleDataLoadException($"{poolName} Buff ID {id} が重複しています。");
            }

            dict.Add(id, value);
        }
    }

    /// <summary>
    /// Assets/Resources配下のバフCSV3種（数学/理科/日本史）を読み込む。
    /// </summary>
    [DefaultExecutionOrder(-1000)]
    public sealed class CaveBattleBuffDataLoader : MonoBehaviour
    {
        [Header("Load Settings")]
        [SerializeField] private bool loadOnAwake = true;

        [Header("Resources Paths (拡張子なし)")]
        [SerializeField] private string mathPath = "buffs/Mathbahu";
        [SerializeField] private string sciencePath = "buffs/Siencebahu";
        [SerializeField] private string historyPath = "buffs/nihonsi_bahu";

        public CaveBattleBuffRepository Repository { get; private set; }
        public bool IsLoaded => Repository != null;

        private void Awake()
        {
            if (loadOnAwake)
            {
                LoadAll();
            }
        }

        public CaveBattleBuffRepository LoadAll()
        {
            try
            {
                CaveBattleBuffRepository repository = new CaveBattleBuffRepository();

                foreach (CsvRow row in LoadCsv(mathPath).Rows)
                {
                    repository.AddMathBuff(ParseSubjectBuff(row));
                }

                foreach (CsvRow row in LoadCsv(sciencePath).Rows)
                {
                    repository.AddScienceBuff(ParseSubjectBuff(row));
                }

                foreach (CsvRow row in LoadCsv(historyPath).Rows)
                {
                    repository.AddHistoryBuff(ParseHistoryBuff(row));
                }

                Repository = repository;
                Debug.Log(
                    "[CaveBattleBuffDataLoader] 読込完了: " +
                    $"Math={repository.MathBuffs.Count}, Science={repository.ScienceBuffs.Count}, " +
                    $"History={repository.HistoryBuffs.Count}");

                return repository;
            }
            catch (CaveBattleDataLoadException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw new CaveBattleDataLoadException("バフ用CSVの読込中にエラーが発生しました。", ex);
            }
        }

        private static CsvDocument LoadCsv(string resourcesPath)
        {
            TextAsset asset = Resources.Load<TextAsset>(resourcesPath);
            if (asset == null)
            {
                throw new CaveBattleDataLoadException(
                    $"CSVが見つかりません: Assets/Resources/{resourcesPath}.csv");
            }

            try
            {
                return CsvParser.Parse(asset.text);
            }
            catch (Exception ex)
            {
                throw new CaveBattleDataLoadException($"CSVを解析できません: {asset.name}.csv", ex);
            }
        }

        private static CaveSubjectBuffData ParseSubjectBuff(CsvRow row)
        {
            return new CaveSubjectBuffData(
                RequiredInt(row, "id"),
                row.GetRequired("buff_name"),
                row.Get("subject"),
                row.Get("grade"),
                row.Get("unit"),
                row.Get("reward_tier"),
                RequiredInt(row, "n_val"),
                RequiredInt(row, "s_val"),
                RequiredInt(row, "r_val"),
                RequiredFloat(row, "multiplier"),
                RequiredFloat(row, "max_multiplier"),
                row.Get("trigger_type"),
                row.Get("effect_type"),
                row.Get("buff_group"),
                row.Get("hint"),
                row.Get("battle_hint"),
                row.Get("description"));
        }

        private static CaveHistoryBuffData ParseHistoryBuff(CsvRow row)
        {
            return new CaveHistoryBuffData(
                RequiredInt(row, "id"),
                row.GetRequired("buff_name"),
                row.Get("era"),
                row.Get("rank"),
                row.Get("target"),
                RequiredInt(row, "n_val"),
                RequiredInt(row, "s_val"),
                RequiredInt(row, "r_val"),
                RequiredFloat(row, "activation_turn"),
                row.Get("effect_type"),
                ParseBool(row.Get("global_effect")),
                ParseBool(row.Get("replace_on_new_history_buff")),
                row.Get("risk_level"),
                row.Get("hint"),
                row.Get("description"));
        }

        private static int RequiredInt(CsvRow row, string column)
        {
            string raw = row.GetRequired(column);
            if (!int.TryParse(raw, NumberStyles.Integer, CultureInfo.InvariantCulture, out int value))
            {
                throw new CaveBattleDataLoadException($"'{column}' を整数へ変換できません (値: '{raw}')。");
            }

            return value;
        }

        private static float RequiredFloat(CsvRow row, string column)
        {
            string raw = row.GetRequired(column);
            if (!float.TryParse(raw, NumberStyles.Float, CultureInfo.InvariantCulture, out float value))
            {
                throw new CaveBattleDataLoadException($"'{column}' を数値へ変換できません (値: '{raw}')。");
            }

            return value;
        }

        private static bool ParseBool(string raw)
        {
            return bool.TryParse(raw, out bool value) && value;
        }
    }
}
