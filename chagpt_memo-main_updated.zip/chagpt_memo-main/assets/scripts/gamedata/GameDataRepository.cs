using System;
using System.Collections.Generic;

namespace CaveGame.GameData
{
    /// <summary>
    /// 読み込み済みの固定ゲームデータをIDで提供する。
    /// PhaseはCSVを直接読まず、このRepositoryだけを参照する。
    /// </summary>
    public sealed class GameDataRepository
    {
        private readonly Dictionary<int, CharacterData> characters =
            new Dictionary<int, CharacterData>();
        private readonly Dictionary<int, SkillData> skills =
            new Dictionary<int, SkillData>();
        private readonly Dictionary<int, ScienceBuffData> scienceBuffs =
            new Dictionary<int, ScienceBuffData>();
        private readonly Dictionary<int, MathBuffData> mathBuffs =
            new Dictionary<int, MathBuffData>();
        private readonly Dictionary<int, HistoryBuffData> historyBuffs =
            new Dictionary<int, HistoryBuffData>();
        private readonly HashSet<int> allBuffIds = new HashSet<int>();

        public IReadOnlyDictionary<int, CharacterData> Characters => characters;
        public IReadOnlyDictionary<int, SkillData> Skills => skills;
        public IReadOnlyDictionary<int, ScienceBuffData> ScienceBuffs => scienceBuffs;
        public IReadOnlyDictionary<int, MathBuffData> MathBuffs => mathBuffs;
        public IReadOnlyDictionary<int, HistoryBuffData> HistoryBuffs => historyBuffs;

        public bool IsLoaded { get; private set; }

        public void Add(CharacterData data)
        {
            AddUnique(characters, data?.Id ?? 0, data, "Character");
        }

        public void Add(SkillData data)
        {
            AddUnique(skills, data?.Id ?? 0, data, "Skill");
        }

        public void Add(ScienceBuffData data)
        {
            EnsureValidBuff(data, "ScienceBuff");
            EnsureUniqueBuffId(data.Id);
            AddUnique(scienceBuffs, data.Id, data, "ScienceBuff");
        }

        public void Add(MathBuffData data)
        {
            EnsureValidBuff(data, "MathBuff");
            EnsureUniqueBuffId(data.Id);
            AddUnique(mathBuffs, data.Id, data, "MathBuff");
        }

        public void Add(HistoryBuffData data)
        {
            EnsureValidBuff(data, "HistoryBuff");
            EnsureUniqueBuffId(data.Id);
            AddUnique(historyBuffs, data.Id, data, "HistoryBuff");
        }

        public CharacterData GetCharacter(int id)
        {
            CharacterData data;
            if (!characters.TryGetValue(id, out data))
            {
                throw new KeyNotFoundException($"Character IDが存在しません: {id}");
            }

            return data;
        }

        public CharacterData GetCharacter(string id)
        {
            int numericId;
            if (!int.TryParse(id, out numericId))
            {
                throw new ArgumentException($"Character IDを整数へ変換できません: {id}", nameof(id));
            }

            return GetCharacter(numericId);
        }

        public SkillData GetSkill(int id)
        {
            SkillData data;
            if (!skills.TryGetValue(id, out data))
            {
                throw new KeyNotFoundException($"Skill IDが存在しません: {id}");
            }

            return data;
        }

        public BuffData GetBuff(int id)
        {
            ScienceBuffData science;
            if (scienceBuffs.TryGetValue(id, out science))
            {
                return science;
            }

            MathBuffData math;
            if (mathBuffs.TryGetValue(id, out math))
            {
                return math;
            }

            HistoryBuffData history;
            if (historyBuffs.TryGetValue(id, out history))
            {
                return history;
            }

            throw new KeyNotFoundException($"Buff IDが存在しません: {id}");
        }

        public BuffData GetBuff(string id)
        {
            int numericId;
            if (!int.TryParse(id, out numericId))
            {
                throw new ArgumentException($"Buff IDを整数へ変換できません: {id}", nameof(id));
            }

            return GetBuff(numericId);
        }

        public bool TryGetCharacter(int id, out CharacterData data)
        {
            return characters.TryGetValue(id, out data);
        }

        public bool TryGetSkill(int id, out SkillData data)
        {
            return skills.TryGetValue(id, out data);
        }

        public bool TryGetBuff(int id, out BuffData data)
        {
            ScienceBuffData science;
            if (scienceBuffs.TryGetValue(id, out science))
            {
                data = science;
                return true;
            }

            MathBuffData math;
            if (mathBuffs.TryGetValue(id, out math))
            {
                data = math;
                return true;
            }

            HistoryBuffData history;
            if (historyBuffs.TryGetValue(id, out history))
            {
                data = history;
                return true;
            }

            data = null;
            return false;
        }

        public IReadOnlyList<string> ValidateReferences()
        {
            List<string> errors = new List<string>();

            foreach (KeyValuePair<int, CharacterData> pair in characters)
            {
                CharacterData character = pair.Value;
                for (int i = 0; i < character.SkillIds.Count; i++)
                {
                    int skillId = character.SkillIds[i];
                    if (!skills.ContainsKey(skillId))
                    {
                        errors.Add(
                            $"Character ID {character.Id} ({character.CharacterName}) の技ID {skillId} がskills.csvに存在しません。");
                    }
                }
            }

            return errors.AsReadOnly();
        }

        public void MarkLoaded()
        {
            IReadOnlyList<string> referenceErrors = ValidateReferences();
            if (referenceErrors.Count > 0)
            {
                throw new InvalidOperationException(string.Join("\n", referenceErrors));
            }

            IsLoaded = true;
        }

        public void Clear()
        {
            characters.Clear();
            skills.Clear();
            scienceBuffs.Clear();
            mathBuffs.Clear();
            historyBuffs.Clear();
            allBuffIds.Clear();
            IsLoaded = false;
        }

        private void EnsureUniqueBuffId(int id)
        {
            if (!allBuffIds.Add(id))
            {
                throw new InvalidOperationException(
                    $"Buff ID {id} が理科・数学・日本史CSV間で重複しています。");
            }
        }

        private static void EnsureValidBuff(BuffData data, string dataType)
        {
            if (data == null)
            {
                throw new ArgumentNullException(nameof(data));
            }

            if (data.Id <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(data), $"{dataType} IDは1以上が必要です。");
            }
        }

        private static void AddUnique<T>(
            IDictionary<int, T> dictionary,
            int id,
            T data,
            string dataType)
            where T : class
        {
            if (data == null)
            {
                throw new ArgumentNullException(nameof(data));
            }

            if (id <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(id), $"{dataType} IDは1以上が必要です。");
            }

            if (dictionary.ContainsKey(id))
            {
                throw new InvalidOperationException($"{dataType} ID {id} が重複しています。");
            }

            dictionary.Add(id, data);
        }
    }
}
