using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

/// <summary>
/// 空港で、プレイヤーの名前が書かれたホワイトボードを持った運転手に会い、
/// タクシーに乗って街まで移動する一連の演出。
///
/// 流れ:
/// 1. Open()でホワイトボード画面を表示する。ホワイトボードにはGameStartState.PlayerNameを表示する
///    （＝「これが自分を迎えに来た人だ」とプレイヤーが分かるようにする）。
/// 2. BoardButtonを押すとタクシーに乗る。
/// 3. GameStartConfig.TaxiRideDurationSeconds秒だけ移動演出（待機）する。
/// 4. 終了後、街に到着したことをコールバックで返す。
/// </summary>
public sealed class AirportTaxiController : MonoBehaviour
{
    [Header("Whiteboard / Driver Screen")]
    [SerializeField] private GameObject driverScreen;
    [SerializeField] private Text whiteboardNameText;
    [SerializeField] private Text driverGuideText;
    [SerializeField] private Button boardTaxiButton;

    [Header("Taxi Ride Screen")]
    [SerializeField] private GameObject taxiRideScreen;
    [SerializeField] private Text taxiRideText;

    [Header("Dependencies")]
    [SerializeField] private GameStartConfig config;

    [Header("Debug")]
    [SerializeField] private bool enableDebugLog = true;

    private UnityAction boardListener;
    private Action onBoarded;
    private Action onArrived;
    private Coroutine rideCoroutine;

    /// <summary>
    /// ホワイトボード画面を開く。playerNameはそのままホワイトボードの文字として表示する。
    /// onBoardedは「乗る」ボタンを押した瞬間（演出開始前）、onArrivedInTownは演出終了後に呼ばれる。
    /// </summary>
    public void Open(string playerName, Action onBoardedTaxi, Action onArrivedInTown)
    {
        onBoarded = onBoardedTaxi;
        onArrived = onArrivedInTown;

        SetText(whiteboardNameText, playerName);
        SetText(driverGuideText, $"「{playerName}様」と書かれたホワイトボードを持った人がいる。");

        BindBoardButton();
        SetActive(driverScreen, true);
        SetActive(taxiRideScreen, false);
    }

    private void OnBoardClicked()
    {
        if (boardTaxiButton != null)
        {
            boardTaxiButton.interactable = false;
        }

        SetActive(driverScreen, false);
        SetActive(taxiRideScreen, true);
        SetText(taxiRideText, "タクシーで街へ向かっている…");

        Action boardedCallback = onBoarded;
        onBoarded = null;
        boardedCallback?.Invoke();

        float duration = config != null ? config.TaxiRideDurationSeconds : 0f;

        if (rideCoroutine != null)
        {
            StopCoroutine(rideCoroutine);
        }

        rideCoroutine = StartCoroutine(PlayRide(duration));
    }

    private IEnumerator PlayRide(float duration)
    {
        if (duration > 0f)
        {
            yield return new WaitForSeconds(duration);
        }

        rideCoroutine = null;
        SetActive(taxiRideScreen, false);

        if (boardTaxiButton != null)
        {
            boardTaxiButton.interactable = true;
        }

        if (enableDebugLog)
        {
            Debug.Log("[AirportTaxiController] 街に到着した。");
        }

        Action callback = onArrived;
        onArrived = null;
        callback?.Invoke();
    }

    private void BindBoardButton()
    {
        if (boardTaxiButton == null)
        {
            return;
        }

        if (boardListener != null)
        {
            boardTaxiButton.onClick.RemoveListener(boardListener);
        }

        boardListener = OnBoardClicked;
        boardTaxiButton.onClick.AddListener(boardListener);
        boardTaxiButton.interactable = true;
    }

    private void OnDestroy()
    {
        if (boardTaxiButton != null && boardListener != null)
        {
            boardTaxiButton.onClick.RemoveListener(boardListener);
        }

        if (rideCoroutine != null)
        {
            StopCoroutine(rideCoroutine);
        }
    }

    private static void SetText(Text target, string value)
    {
        if (target != null)
        {
            target.text = value ?? string.Empty;
        }
    }

    private static void SetActive(GameObject target, bool active)
    {
        if (target != null)
        {
            target.SetActive(active);
        }
    }
}
