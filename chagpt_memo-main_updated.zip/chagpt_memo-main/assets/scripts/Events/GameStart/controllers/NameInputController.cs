using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

/// <summary>
/// ゲーム開始直後の「あなたの名前は？」入力画面。
/// GameStartConfigの文字数制限に違反する場合は確定させず、エラー文言を表示する。
/// StateやPhase遷移の直接操作はしない。GameStartHandlerへ確定結果を返すだけ。
/// </summary>
public sealed class NameInputController : MonoBehaviour
{
    [Header("Screen")]
    [SerializeField] private GameObject nameInputScreen;
    [SerializeField] private Text promptText;
    [SerializeField] private InputField nameField;
    [SerializeField] private Text errorText;

    [Header("Confirm")]
    [SerializeField] private Button confirmButton;

    [Header("Dependencies")]
    [SerializeField] private GameStartConfig config;

    private UnityAction confirmListener;
    private Action<string> completedCallback;

    public void Open(Action<string> onNameConfirmed)
    {
        completedCallback = onNameConfirmed;

        SetText(promptText, "あなたの名前は？");
        SetText(errorText, string.Empty);

        if (nameField != null)
        {
            nameField.text = string.Empty;
        }

        BindConfirmButton();
        SetActive(nameInputScreen, true);
    }

    private void OnConfirmClicked()
    {
        string rawInput = nameField != null ? nameField.text : string.Empty;
        string trimmed = (rawInput ?? string.Empty).Trim();

        if (config != null && !config.IsNameLengthValid(trimmed))
        {
            SetText(
                errorText,
                $"名前は{config.MinNameLength}〜{config.MaxNameLength}文字で入力してください。");
            return;
        }

        if (string.IsNullOrEmpty(trimmed))
        {
            SetText(errorText, "名前を入力してください。");
            return;
        }

        Action<string> callback = completedCallback;
        completedCallback = null;

        SetActive(nameInputScreen, false);
        callback?.Invoke(trimmed);
    }

    private void BindConfirmButton()
    {
        if (confirmButton == null)
        {
            return;
        }

        if (confirmListener != null)
        {
            confirmButton.onClick.RemoveListener(confirmListener);
        }

        confirmListener = OnConfirmClicked;
        confirmButton.onClick.AddListener(confirmListener);
    }

    private void OnDestroy()
    {
        if (confirmButton != null && confirmListener != null)
        {
            confirmButton.onClick.RemoveListener(confirmListener);
        }
    }

    private static void SetText(Text target, string value)
    {
        if (target != null)
        {
            target.text = value ?? string.Empty;
        }
    }

    private static void SetActive(GameObject target, bool active)
    {
        if (target != null)
        {
            target.SetActive(active);
        }
    }
}
