using System.Text;
using CaveGame.GameStart;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

/// <summary>
/// パンフレットの開閉を担当する。街到着後、プレイヤーはいつでもこれを開ける。
///
/// 開いた瞬間にGameStartWorldRevealService.RevealFromPamphlet()を呼び、
/// 地形（家・店の配置）をセットする。配置データ自体はTownLayoutDataに固定で
/// 書かれているため、ここでは内容をそのままテキストとして一覧表示するだけ。
/// </summary>
public sealed class PamphletController : MonoBehaviour
{
    [Header("Screen")]
    [SerializeField] private GameObject pamphletScreen;
    [SerializeField] private Text titleText;
    [SerializeField] private Text bodyText;

    [Header("Buttons")]
    [SerializeField] private Button openButton;
    [SerializeField] private Button closeButton;

    [Header("Dependencies")]
    [SerializeField] private GameStartWorldRevealService revealService;

    private UnityAction openListener;
    private UnityAction closeListener;

    private void Awake()
    {
        BindButtons();
        SetActive(pamphletScreen, false);
    }

    public void Open()
    {
        if (revealService != null)
        {
            revealService.RevealFromPamphlet();
        }

        TownLayoutData layout = revealService != null ? revealService.TownLayout : null;
        SetText(titleText, layout != null ? layout.DisplayName : "パンフレット");
        SetText(bodyText, BuildBodyText(layout));

        SetActive(pamphletScreen, true);
    }

    public void Close()
    {
        SetActive(pamphletScreen, false);
    }

    private static string BuildBodyText(TownLayoutData layout)
    {
        if (layout == null || layout.Buildings.Count == 0)
        {
            return "まだ詳しい地図はないようだ。";
        }

        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < layout.Buildings.Count; i++)
        {
            TownBuildingEntry building = layout.Buildings[i];
            builder.AppendLine($"・{building.DisplayName}（{building.BuildingType}）");

            if (!string.IsNullOrEmpty(building.Description))
            {
                builder.AppendLine($"  {building.Description}");
            }
        }

        return builder.ToString();
    }

    private void BindButtons()
    {
        if (openButton != null)
        {
            openListener = Open;
            openButton.onClick.AddListener(openListener);
        }

        if (closeButton != null)
        {
            closeListener = Close;
            closeButton.onClick.AddListener(closeListener);
        }
    }

    private void OnDestroy()
    {
        if (openButton != null && openListener != null)
        {
            openButton.onClick.RemoveListener(openListener);
        }

        if (closeButton != null && closeListener != null)
        {
            closeButton.onClick.RemoveListener(closeListener);
        }
    }

    private static void SetText(Text target, string value)
    {
        if (target != null)
        {
            target.text = value ?? string.Empty;
        }
    }

    private static void SetActive(GameObject target, bool active)
    {
        if (target != null)
        {
            target.SetActive(active);
        }
    }
}
