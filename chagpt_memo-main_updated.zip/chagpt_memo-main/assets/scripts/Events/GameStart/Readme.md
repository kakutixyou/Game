GameStart（ゲーム開始シーケンス）メモ

最終更新: 2026-09-26

## 30秒で思い出す要約

名前入力 → 空港でホワイトボードの運転手に会う → タクシーで街へ移動 →
街に到着（以後いつでもパンフレット／看板が読める）→ パンフレット or 看板を読むと
地形（家・店の配置）がセットされる、という流れ。

CaveExplorationと同じ設計方針を踏襲している。
- Handler（GameStartHandler）は進行管理だけ。UI表示や判定は各Controller/Serviceへ委譲。
- Phase（GameStartPhase）は「今どこにいるか」を表すだけで処理はしない。
- State（GameStartState）はデータ保持専用。UIや遷移はしない。

## ファイル一覧

| ファイル | 役割 |
| --- | --- |
| `GameStartPhase.cs` | 現在の進行段階（NameInput/AirportPickup/TaxiRide/TownArrival/WorldLayoutRevealed/Completed）。 |
| `GameStartEventIds.cs` | EventSetTrigger等から参照するイベントIDの一元管理。 |
| `GameStartState.cs` | プレイヤー名、タクシー搭乗／街到着フラグ、地形公開フラグ、ログを保持。 |
| `GameStartConfig.cs` | 名前の文字数制限、タクシー演出秒数、街レイアウト（TownLayoutData）参照、完了条件の設定。 |
| `Models/TownLayoutModels.cs` | `TownLayoutData`（街の固定レイアウト）と`TownBuildingEntry`（家・店1件分）。 |
| `GameStartWorldRevealService.cs` | パンフレット／看板のどちらから呼ばれても同じ結果になる「地形セット」の一元窓口。 |
| `controllers/NameInputController.cs` | 「あなたの名前は？」入力画面。 |
| `controllers/AirportTaxiController.cs` | ホワイトボードを持った運転手→タクシー搭乗→移動演出→到着。 |
| `controllers/PamphletController.cs` | パンフレットの開閉と内容表示。開いた瞬間に地形を公開する。 |
| `SignReadTrigger.cs` | 街中の看板prefabへ付ける物理トリガー。接触すると地形を公開する。 |
| `GameStartHandler.cs` | 上記すべてを順番に呼び出す進行役。完了時に`Completed`イベントを発火する。 |

## 地形（家・店の配置）の考え方

「パターンは大体同じで、家、店の位置は変わらない」という仕様どおり、
`TownLayoutData`はランダム生成しない固定アセットとして扱う。
パンフレット／看板を読む操作は、この固定データを

1. `GameStartState.IsWorldLayoutRevealed` フラグとして記録し、
2. `GameStartWorldRevealService.WorldLayoutRevealed` イベントでマップUI等の購読者へ通知する

だけで、建物配置自体を書き換えることはしない。
将来、街ごとに複数パターンを用意したくなった場合は、
`GameStartConfig.TownLayout` を街ごとの`TownLayoutData`に差し替えるだけで対応できる
（＝レイアウトの切り替え単位をアセット1本に閉じ込めてある）。

## 完了条件

`GameStartConfig.RequireWorldLayoutRevealBeforeCompletion` で、
「街に着いただけで自由行動に入ってよいか」「パンフレットか看板を最低1回読むまで
自由行動にしないか」を切り替えられる。既定はfalse（着いた時点で完了）。

## Unityでの最小配線

1. `Create > Game > Game Start Config` で `GameStartConfig` を作成し、
   `Create > Game > Game Start > Town Layout` で作成した `TownLayoutData`
   （固定の家・店リスト）を割り当てる。
2. シーンへ `GameStartHandler` を追加し、`NameInputController` /
   `AirportTaxiController` / `PamphletController` / `GameStartWorldRevealService` を
   それぞれ用意してInspectorで割り当てる。
3. `PamphletController` と `SignReadTrigger` の `revealService` には、
   同じ `GameStartWorldRevealService` を割り当てる（1つで両方を受け止める）。
4. 街中の看板オブジェクトへ `SignReadTrigger` を付け、Player判定用のColliderと
   `playerTag`（既定"Player"）を確認する。
5. Playすると名前入力 → 運転手 → タクシー → 街到着まで自動で進み、
   その後パンフレットや看板を読むと地形が公開され、`GameStartHandler.Completed` が発火する。

## 今後の拡張ポイント

- 名前入力のNGワード検閲など、`NameInputController`側にバリデーションを足せる。
- タクシー移動中の簡易ミニゲームや会話を挟みたい場合は、
  `AirportTaxiController.PlayRide`のコルーチンを差し替える。
- 街を複数用意する場合、`GameStartConfig.TownLayout`をエリアごとに切り替える
  仕組み（CaveBattleEncounterServiceのSetActiveRulesetに相当するもの）を追加する。
