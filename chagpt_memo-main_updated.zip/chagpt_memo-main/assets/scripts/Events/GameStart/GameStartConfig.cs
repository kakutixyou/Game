using System.Collections.Generic;
using CaveGame.GameStart;
using UnityEngine;

/// <summary>
/// ゲーム開始シーケンス（名前入力〜タクシー移動〜街到着）全体で変更可能な設定。
/// Projectビューから Create > Game > Game Start Config で作成する。
/// </summary>
[CreateAssetMenu(
    fileName = "GameStartConfig",
    menuName = "Game/Game Start Config",
    order = 101)]
public sealed class GameStartConfig : ScriptableObject
{
    [Header("Name Input")]
    [Min(1)]
    [SerializeField] private int minNameLength = 1;
    [Min(1)]
    [SerializeField] private int maxNameLength = 12;
    [SerializeField] private string fallbackName = "旅人";

    [Header("Taxi Ride")]
    [Tooltip("タクシー移動演出（会話・BGM等）にかける秒数。0なら即座に到着扱いにする。")]
    [Min(0f)]
    [SerializeField] private float taxiRideDurationSeconds = 2.5f;

    [Header("Town / World Layout")]
    [Tooltip(" 家・店の位置が決まった、街の固定テンプレート。パンフレット／看板を読むとこれが公開される。")]
    [SerializeField] private TownLayoutData townLayout;
    [Tooltip(
        "trueの場合、パンフレットか看板を最低1回読むまでゲーム開始シーケンスを完了（自由行動化）できない。" +
        "falseの場合は読まなくても街到着だけで完了扱いにできる。")]
    [SerializeField] private bool requireWorldLayoutRevealBeforeCompletion = false;

    [Header("Debug")]
    [SerializeField] private bool enableDebugLog = true;

    public int MinNameLength => minNameLength;
    public int MaxNameLength => maxNameLength;
    public string FallbackName => fallbackName;
    public float TaxiRideDurationSeconds => taxiRideDurationSeconds;
    public TownLayoutData TownLayout => townLayout;
    public bool RequireWorldLayoutRevealBeforeCompletion => requireWorldLayoutRevealBeforeCompletion;
    public bool EnableDebugLog => enableDebugLog;

    /// <summary>入力された名前が長さ制限を満たしているか。</summary>
    public bool IsNameLengthValid(string trimmedName)
    {
        int length = trimmedName?.Length ?? 0;
        return length >= minNameLength && length <= maxNameLength;
    }

    /// <summary>
    /// Inspector値の不整合を一覧で返す。空なら設定は有効。
    /// </summary>
    public IReadOnlyList<string> ValidateSettings()
    {
        List<string> errors = new List<string>();

        if (minNameLength < 1)
            errors.Add("Min Name Lengthは1以上にしてください。");
        if (maxNameLength < minNameLength)
            errors.Add("Max Name LengthがMin Name Lengthより小さくなっています。");
        if (taxiRideDurationSeconds < 0f)
            errors.Add("Taxi Ride Duration Secondsは0以上にしてください。");
        if (townLayout == null)
            errors.Add("Town Layoutが未設定です。パンフレット／看板で公開する街のデータを割り当ててください。");

        return errors;
    }

    public bool IsValid(out string message)
    {
        IReadOnlyList<string> errors = ValidateSettings();
        message = errors.Count == 0 ? string.Empty : string.Join("\n", errors);
        return errors.Count == 0;
    }

    private void OnValidate()
    {
        minNameLength = Mathf.Max(1, minNameLength);
        maxNameLength = Mathf.Max(minNameLength, maxNameLength);
        taxiRideDurationSeconds = Mathf.Max(0f, taxiRideDurationSeconds);
    }
}
