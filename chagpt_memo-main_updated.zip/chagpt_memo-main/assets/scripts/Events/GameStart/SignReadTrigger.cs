using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 街中に配置する看板prefabへ付ける。プレイヤーと接触すると看板を読んだ扱いになり、
/// GameStartWorldRevealService経由で地形（家・店の配置）をセットする。
///
/// CaveBattleEncounterTriggerと同じ方針で、2D/3Dどちらの物理も想定し、
/// Trigger系のCollider/Collider2Dどちらでも動く。
/// </summary>
public sealed class SignReadTrigger : MonoBehaviour
{
    [Header("Dependencies")]
    [SerializeField] private GameStartWorldRevealService revealService;

    [Header("この看板の識別子")]
    [Tooltip("同じ看板を何度も読んだ扱いにしないための任意ID。空でも動作する（毎回同じ看板として記録されるだけ）。")]
    [SerializeField] private string signId;

    [Header("表示（任意）")]
    [SerializeField] private GameObject signMessageScreen;
    [SerializeField] private Text signMessageText;
    [TextArea(1, 4)]
    [SerializeField] private string signMessage = "この先に街が広がっている。";

    [Header("接触判定")]
    [SerializeField] private string playerTag = "Player";
    [Tooltip("一度読んだら、このprefabは再度反応しないようにする。")]
    [SerializeField] private bool disableAfterRead = false;

    private bool hasBeenRead;

    private void OnTriggerEnter2D(Collider2D other)
    {
        TryHandleContact(other.gameObject);
    }

    private void OnTriggerEnter(Collider other)
    {
        TryHandleContact(other.gameObject);
    }

    private void TryHandleContact(GameObject other)
    {
        if (hasBeenRead && disableAfterRead)
        {
            return;
        }

        if (other == null || !other.CompareTag(playerTag))
        {
            return;
        }

        if (revealService == null)
        {
            Debug.LogError("[SignReadTrigger] GameStartWorldRevealServiceが未設定です。");
            return;
        }

        hasBeenRead = true;
        revealService.RevealFromSign(signId);

        if (signMessageScreen != null)
        {
            SetText(signMessageText, signMessage);
            signMessageScreen.SetActive(true);
        }
    }

    private static void SetText(Text target, string value)
    {
        if (target != null)
        {
            target.text = value ?? string.Empty;
        }
    }
}
