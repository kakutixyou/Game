/// <summary>
/// ゲーム開始シーケンスで使用するイベントIDを一元管理する。
///
/// CaveEventIdsと同じ方針で、EventSetTriggerへの登録・解除・デバッグ表示では
/// 文字列を直接記述せず、このクラスの定数を使用する。
///
/// 注意:
/// IDの文字列はセーブデータ、ログ、外部設定から参照される可能性があるため、
/// 公開後は定数名を変更しても文字列値は不用意に変更しないこと。
/// </summary>
public static class GameStartEventIds
{
    private const string Prefix = "gamestart.";

    // =========================================================
    // Name Input
    // =========================================================

    /// <summary>名前入力を確定する。</summary>
    public const string ConfirmName = Prefix + "confirm_name";

    // =========================================================
    // Airport / Taxi
    // =========================================================

    /// <summary>ホワイトボードを持った人（運転手）に話しかけ、タクシーに乗る。</summary>
    public const string BoardTaxi = Prefix + "board_taxi";

    /// <summary>タクシー移動演出が終わり、街に到着した。</summary>
    public const string TaxiArrived = Prefix + "taxi_arrived";

    // =========================================================
    // Pamphlet / Signs
    // =========================================================

    /// <summary>パンフレットを開く。</summary>
    public const string OpenPamphlet = Prefix + "open_pamphlet";

    /// <summary>パンフレットを閉じる。</summary>
    public const string ClosePamphlet = Prefix + "close_pamphlet";

    /// <summary>街中の看板を読む（SignReadTrigger経由でも発火しうる）。</summary>
    public const string ReadSign = Prefix + "read_sign";

    // =========================================================
    // Completion
    // =========================================================

    /// <summary>ゲーム開始シーケンスを終了し、自由行動へ切り替える。</summary>
    public const string FinishGameStart = Prefix + "finish";
}
