/// <summary>
/// ゲーム開始シーケンス（名前入力〜タクシー移動〜街到着）の現在位置を表す。
///
/// CavePhaseと同じ方針で、このenum自体は処理を行わない。
/// GameStartHandlerが現在のPhaseを保持し、対応するControllerへ処理を委譲する。
///
/// 数値はセーブデータやログで値が変化しにくいよう明示している。
/// 新しいPhaseを途中へ追加する場合は、既存値を変更せず空いている番号を使う。
/// </summary>
public enum GameStartPhase
{
    /// <summary>ゲーム開始シーケンスを開始していない状態。</summary>
    None = 0,

    /// <summary>
    /// プレイヤーへ「あなたの名前は？」と尋ね、名前を入力させる。
    /// </summary>
    NameInput = 10,

    /// <summary>
    /// 空港で、自分の名前が書かれたホワイトボードを持った人（タクシー運転手）を探す。
    /// </summary>
    AirportPickup = 20,

    /// <summary>
    /// タクシーに乗って空港から街へ移動する（演出）。
    /// </summary>
    TaxiRide = 30,

    /// <summary>
    /// 街に到着した状態。ここからパンフレットを読んだり、看板を読んだりできるようになる。
    /// 地形（家・店の配置）はこの時点ではまだ「セット」されていない。
    /// </summary>
    TownArrival = 40,

    /// <summary>
    /// パンフレットまたは看板を1回でも読み、地形（家・店の配置）がセットされた状態。
    /// パンフレットは以後もいつでも読み返せる（このPhaseへ戻るだけで再訪扱い）。
    /// </summary>
    WorldLayoutRevealed = 50,

    /// <summary>
    /// ゲーム開始シーケンスが完了し、自由行動（通常の探索）に切り替わった状態。
    /// </summary>
    Completed = 100
}
