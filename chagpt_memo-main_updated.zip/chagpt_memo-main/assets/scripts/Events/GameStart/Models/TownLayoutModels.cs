using System;
using System.Collections.Generic;
using UnityEngine;

namespace CaveGame.GameStart
{
    /// <summary>建物の種類。表示アイコンや並び順の出し分けに使う。</summary>
    public enum TownBuildingType
    {
        House = 0,
        Shop = 1,
        Landmark = 2
    }

    /// <summary>
    /// 街に配置される建物1件分の情報。
    /// positionはワールド座標そのものではなく、パンフレット上のマップ表示用の相対座標として扱う想定。
    /// 実際のシーン上のオブジェクト配置とは別に、この値を「マップに載せる情報」として使う。
    /// </summary>
    [Serializable]
    public sealed class TownBuildingEntry
    {
        [SerializeField] private string buildingId;
        [SerializeField] private TownBuildingType buildingType;
        [SerializeField] private string displayName;
        [SerializeField] private Vector2 mapPosition;
        [TextArea(1, 3)]
        [SerializeField] private string description;

        public string BuildingId => buildingId;
        public TownBuildingType BuildingType => buildingType;
        public string DisplayName => displayName;
        public Vector2 MapPosition => mapPosition;
        public string Description => description;
    }

    /// <summary>
    /// 街1つ分の固定レイアウト。
    ///
    /// 「パターンは大体同じで、家、店の位置は変わらない」という仕様どおり、
    /// このアセット自体はプレイのたびに内容を変えない（ランダム生成しない）。
    /// パンフレットや看板を読むタイミングで、このデータをプレイヤーへ「公開」するだけ
    /// （＝GameStartWorldRevealServiceがGameStartStateの公開フラグを立てるだけ）で、
    /// 実際の建物の配置自体はここに書かれた内容が常に使われる。
    ///
    /// Projectビューから Create > Game > Game Start > Town Layout で作成する。
    /// </summary>
    [CreateAssetMenu(
        fileName = "TownLayoutData",
        menuName = "Game/Game Start/Town Layout",
        order = 102)]
    public sealed class TownLayoutData : ScriptableObject
    {
        [SerializeField] private string layoutId = "town_default";
        [SerializeField] private string displayName = "街";
        [SerializeField] private List<TownBuildingEntry> buildings = new List<TownBuildingEntry>();

        public string LayoutId => layoutId;
        public string DisplayName => displayName;
        public IReadOnlyList<TownBuildingEntry> Buildings => buildings;

        public TownBuildingEntry FindBuilding(string buildingId)
        {
            if (string.IsNullOrEmpty(buildingId))
            {
                return null;
            }

            for (int i = 0; i < buildings.Count; i++)
            {
                if (buildings[i].BuildingId == buildingId)
                {
                    return buildings[i];
                }
            }

            return null;
        }
    }
}
