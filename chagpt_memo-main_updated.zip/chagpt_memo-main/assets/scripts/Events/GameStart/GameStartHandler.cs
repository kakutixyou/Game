using System;
using UnityEngine;

/// <summary>
/// ゲーム開始シーケンス（名前入力〜空港タクシー〜街到着）の司令塔。
///
/// CaveExplorationHandlerと同じ方針:
/// ・画面遷移、Phase変更、Controller呼び出し、完了通知だけを担当する。
/// ・名前の妥当性チェックはNameInputController（+ GameStartConfig）、
///   タクシー演出はAirportTaxiController、パンフレット表示はPamphletController、
///   地形セットの一元化はGameStartWorldRevealServiceがそれぞれ担当する。
/// ・Handler自身はGameStartStateを直接書き換えず、各Controller/Serviceの結果を
///   受け取ってPhaseを進めるだけ。
/// </summary>
public sealed class GameStartHandler : MonoBehaviour
{
    [Header("Config")]
    [SerializeField] private GameStartConfig config;
    [SerializeField] private bool autoBeginOnStart = true;

    [Header("Controllers")]
    [SerializeField] private NameInputController nameInputController;
    [SerializeField] private AirportTaxiController airportTaxiController;
    [SerializeField] private PamphletController pamphletController;
    [SerializeField] private GameStartWorldRevealService worldRevealService;

    [Header("Debug")]
    [SerializeField] private bool enableDebugLog = true;

    private readonly GameStartState state = new GameStartState();

    public GameStartPhase CurrentPhase { get; private set; } = GameStartPhase.None;
    public GameStartState State => state;

    /// <summary>ゲーム開始シーケンス完了時（自由行動へ切り替わる時）に発火する。</summary>
    public event Action<GameStartState> Completed;

    private void Start()
    {
        if (worldRevealService != null)
        {
            worldRevealService.Bind(state);
        }

        if (autoBeginOnStart)
        {
            Begin();
        }
    }

    /// <summary>ゲーム開始シーケンスを開始する（村からの遷移等で呼びたい場合はautoBeginOnStartをOFFにして手動で呼ぶ）。</summary>
    public void Begin()
    {
        if (config != null && !config.IsValid(out string configError))
        {
            Debug.LogError($"[GameStartHandler] GameStartConfigが不正です。\n{configError}");
            return;
        }

        if (nameInputController == null)
        {
            Debug.LogError("[GameStartHandler] NameInputControllerが未設定です。");
            return;
        }

        SetPhase(GameStartPhase.NameInput);
        nameInputController.Open(OnNameConfirmed);
    }

    private void OnNameConfirmed(string playerName)
    {
        state.SetPlayerName(playerName);

        SetPhase(GameStartPhase.AirportPickup);
        state.MarkMetDriver();

        if (airportTaxiController == null)
        {
            Debug.LogError("[GameStartHandler] AirportTaxiControllerが未設定です。街到着扱いにして先へ進みます。");
            OnArrivedInTown();
            return;
        }

        airportTaxiController.Open(state.PlayerName, OnBoardedTaxi, OnArrivedInTown);
    }

    private void OnBoardedTaxi()
    {
        state.BoardTaxi();
        SetPhase(GameStartPhase.TaxiRide);
    }

    private void OnArrivedInTown()
    {
        state.ArriveInTown();
        SetPhase(GameStartPhase.TownArrival);

        if (worldRevealService != null)
        {
            worldRevealService.WorldLayoutRevealed -= OnWorldLayoutRevealed;
            worldRevealService.WorldLayoutRevealed += OnWorldLayoutRevealed;
        }

        // パンフレット／看板は「読めるようになる」だけで、ここで強制的には開かない。
        // プレイヤーが自発的に読むまで待ち、TryCompleteでゲート判定する。
        TryComplete();
    }

    private void OnWorldLayoutRevealed(CaveGame.GameStart.TownLayoutData layout)
    {
        SetPhase(GameStartPhase.WorldLayoutRevealed);
        TryComplete();
    }

    /// <summary>
    /// 街到着済み、かつ（設定次第で）地形公開済みならシーケンスを完了する。
    /// パンフレット／看板を読むたびにも呼ばれるが、条件を満たすまでは何もしない。
    /// </summary>
    private void TryComplete()
    {
        if (state.IsCompleted || !state.HasArrivedInTown)
        {
            return;
        }

        bool requiresReveal = config == null || config.RequireWorldLayoutRevealBeforeCompletion;
        if (requiresReveal && !state.IsWorldLayoutRevealed)
        {
            return;
        }

        state.CompleteSequence();
        SetPhase(GameStartPhase.Completed);

        if (worldRevealService != null)
        {
            worldRevealService.WorldLayoutRevealed -= OnWorldLayoutRevealed;
        }

        Completed?.Invoke(state);
    }

    private void SetPhase(GameStartPhase phase)
    {
        CurrentPhase = phase;

        if (enableDebugLog)
        {
            Debug.Log($"[GameStartHandler] Phase -> {phase}");
        }
    }

    private void OnDestroy()
    {
        if (worldRevealService != null)
        {
            worldRevealService.WorldLayoutRevealed -= OnWorldLayoutRevealed;
        }
    }
}
