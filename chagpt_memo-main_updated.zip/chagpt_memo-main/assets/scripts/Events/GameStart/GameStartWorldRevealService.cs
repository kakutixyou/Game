using System;
using CaveGame.GameStart;
using UnityEngine;

/// <summary>
/// 「地形（家・店の配置）をセットする」処理の一元窓口。
///
/// PamphletController（パンフレットを読む）とSignReadTrigger（看板を読む）は、
/// どちらもこのServiceのRevealFromPamphlet() / RevealFromSign()を呼ぶだけでよい。
/// 実際の建物配置データ自体はTownLayoutData（GameStartConfig.TownLayout）に
/// 固定で定義されているため、ここでは「まだ見せていなければGameStartStateへ反映し、
/// 購読者（マップUI等）へ通知する」ことだけを行う。
///
/// 冪等: 既に公開済みの状態で何度呼んでも、WorldLayoutRevealedイベントは1回しか発火しない。
/// </summary>
public sealed class GameStartWorldRevealService : MonoBehaviour
{
    [Header("Dependencies")]
    [SerializeField] private GameStartConfig config;

    [Header("Debug")]
    [SerializeField] private bool enableDebugLog = true;

    private GameStartState state;

    /// <summary>地形が実際に公開された瞬間に1回だけ発火する（マップUIの更新等に使う）。</summary>
    public event Action<TownLayoutData> WorldLayoutRevealed;

    public TownLayoutData TownLayout => config != null ? config.TownLayout : null;

    /// <summary>GameStartHandler等、GameStartStateを持つ側から呼んで紐付ける。</summary>
    public void Bind(GameStartState gameStartState)
    {
        state = gameStartState;
    }

    /// <summary>パンフレットを開いた時に呼ぶ。</summary>
    public void RevealFromPamphlet()
    {
        if (state == null)
        {
            Debug.LogError("[GameStartWorldRevealService] Bind(GameStartState)が呼ばれていません。");
            return;
        }

        bool wasAlreadyRevealed = state.IsWorldLayoutRevealed;
        state.RecordPamphletOpened();
        NotifyIfNewlyRevealed(wasAlreadyRevealed);
    }

    /// <summary>街中の看板を読んだ時に呼ぶ。signIdは同じ看板の重複読みを記録するための任意のID。</summary>
    public void RevealFromSign(string signId)
    {
        if (state == null)
        {
            Debug.LogError("[GameStartWorldRevealService] Bind(GameStartState)が呼ばれていません。");
            return;
        }

        bool wasAlreadyRevealed = state.IsWorldLayoutRevealed;
        state.RecordSignRead(signId);
        NotifyIfNewlyRevealed(wasAlreadyRevealed);
    }

    private void NotifyIfNewlyRevealed(bool wasAlreadyRevealed)
    {
        if (wasAlreadyRevealed || !state.IsWorldLayoutRevealed)
        {
            return;
        }

        if (config == null || config.TownLayout == null)
        {
            Debug.LogWarning(
                "[GameStartWorldRevealService] GameStartConfigまたはTownLayoutが未設定のため、" +
                "地形フラグは立ちましたがマップ用データを通知できません。");
            return;
        }

        if (enableDebugLog)
        {
            Debug.Log($"[GameStartWorldRevealService] 地形を公開: {config.TownLayout.DisplayName}");
        }

        WorldLayoutRevealed?.Invoke(config.TownLayout);
    }
}
