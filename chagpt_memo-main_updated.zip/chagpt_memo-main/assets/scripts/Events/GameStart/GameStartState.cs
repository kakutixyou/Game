using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// ゲーム開始シーケンス専用の状態管理クラス。
///
/// 役割:
/// ・プレイヤーが入力した名前
/// ・タクシー搭乗／街到着の進行フラグ
/// ・パンフレット／看板を読んで地形がセットされたかどうか
/// ・イベントログ
///
/// 注意:
/// CaveEventStateと同じく、このクラス自身はUIや画面遷移を行わない。
/// あくまで「現在のゲーム開始シーケンスの状態」を保持するだけ。
/// </summary>
[Serializable]
public class GameStartState
{
    // =========================================================
    // Player Name
    // =========================================================

    [Header("Player Name")]

    [SerializeField]
    private string playerName = string.Empty;

    public string PlayerName => playerName;

    public bool HasPlayerName()
    {
        return !string.IsNullOrWhiteSpace(playerName);
    }

    /// <summary>
    /// 名前を確定する。前後の空白は取り除く。空文字や空白のみは受け付けない。
    /// </summary>
    public bool SetPlayerName(string value)
    {
        string trimmed = (value ?? string.Empty).Trim();

        if (string.IsNullOrEmpty(trimmed))
        {
            AddLog("名前が空だったため確定しませんでした。");
            return false;
        }

        playerName = trimmed;
        AddLog($"名前を確定しました: {playerName}");
        return true;
    }


    // =========================================================
    // Airport / Taxi
    // =========================================================

    [Header("Airport / Taxi")]

    [SerializeField]
    private bool hasMetDriver;

    [SerializeField]
    private bool hasBoardedTaxi;

    [SerializeField]
    private bool hasArrivedInTown;

    public bool HasMetDriver => hasMetDriver;
    public bool HasBoardedTaxi => hasBoardedTaxi;
    public bool HasArrivedInTown => hasArrivedInTown;

    /// <summary>ホワイトボードを持った運転手を見つけた（会話開始前）。</summary>
    public void MarkMetDriver()
    {
        if (hasMetDriver)
        {
            return;
        }

        hasMetDriver = true;
        AddLog("ホワイトボードを持った運転手を見つけた。");
    }

    public void BoardTaxi()
    {
        hasBoardedTaxi = true;
        AddLog("タクシーに乗った。");
    }

    public void ArriveInTown()
    {
        hasArrivedInTown = true;
        AddLog("街に到着した。");
    }


    // =========================================================
    // Pamphlet / Signs (World Layout)
    // =========================================================

    [Header("World Layout")]

    [SerializeField]
    private bool isWorldLayoutRevealed;

    [SerializeField]
    private int pamphletOpenCount;

    [SerializeField]
    private List<string> readSignIds = new List<string>();

    /// <summary>パンフレットまたは看板を1回でも読み、地形（家・店の配置）がセットされたか。</summary>
    public bool IsWorldLayoutRevealed => isWorldLayoutRevealed;

    public int PamphletOpenCount => pamphletOpenCount;

    public IReadOnlyList<string> ReadSignIds => readSignIds;

    public void RecordPamphletOpened()
    {
        pamphletOpenCount++;
        MarkWorldLayoutRevealed("パンフレット");
    }

    public bool HasReadSign(string signId)
    {
        return !string.IsNullOrEmpty(signId) && readSignIds.Contains(signId);
    }

    public void RecordSignRead(string signId)
    {
        if (!string.IsNullOrEmpty(signId) && !readSignIds.Contains(signId))
        {
            readSignIds.Add(signId);
        }

        MarkWorldLayoutRevealed(string.IsNullOrEmpty(signId) ? "看板" : $"看板({signId})");
    }

    /// <summary>
    /// 地形セット済みフラグを立てる。パンフレット・看板どちらから呼ばれても同じ結果になる（冪等）。
    /// GameStartWorldRevealServiceから呼ばれるのが基本だが、テスト等で直接呼んでもよい。
    /// </summary>
    public void MarkWorldLayoutRevealed(string source)
    {
        if (isWorldLayoutRevealed)
        {
            return;
        }

        isWorldLayoutRevealed = true;
        AddLog($"地形がセットされた（きっかけ: {source}）。");
    }


    // =========================================================
    // Sequence Completion
    // =========================================================

    [Header("Sequence")]

    [SerializeField]
    private bool isCompleted;

    public bool IsCompleted => isCompleted;

    public void CompleteSequence()
    {
        isCompleted = true;
        AddLog("ゲーム開始シーケンスが完了した。");
    }

    /// <summary>
    /// 次のPhaseへ進めるための最低条件が揃っているかの簡易チェック。
    /// 詳細な可否判定はGameStartInspectorが担当する。
    /// </summary>
    public bool CanCompleteSequence()
    {
        return HasPlayerName() && hasArrivedInTown;
    }


    // =========================================================
    // Logs
    // =========================================================

    [Header("Logs")]

    [SerializeField]
    private List<string> logs = new List<string>();

    public IReadOnlyList<string> Logs => logs;

    public void AddLog(string message)
    {
        if (string.IsNullOrWhiteSpace(message))
        {
            return;
        }

        string log = $"[{DateTime.Now:HH:mm:ss}] {message}";
        logs.Add(log);
        Debug.Log($"[GameStartState] {message}");
    }

    public void ClearLogs()
    {
        logs.Clear();
    }

    public string GetLogText()
    {
        return string.Join("\n", logs);
    }
}
