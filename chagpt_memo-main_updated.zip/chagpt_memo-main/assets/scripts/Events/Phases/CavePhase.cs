/// <summary>
/// 洞窟探索イベントの現在位置を表す。
///
/// このenumは処理を実行しない。
/// CaveExplorationHandlerが現在のPhaseを保持し、
/// 対応するControllerまたはPhaseクラスへ処理を委譲するために使用する。
///
/// 数値はセーブデータやログで値が変化しにくいよう明示している。
/// 新しいPhaseを途中へ追加する場合は、既存値を変更せず空いている番号を使う。
/// </summary>
public enum CavePhase
{
    /// <summary>
    /// 洞窟探索を開始していない状態。
    /// 洞窟ホームやショップ画面で使用する。
    /// </summary>
    None = 0,

    /// <summary>
    /// スタミナ、参加資格、持ち込みアイテムなどの入場条件を確認する。
    /// </summary>
    Entry = 10,

    /// <summary>
    /// 理科問題へ回答する。
    /// </summary>
    ScienceQuiz = 20,

    /// <summary>
    /// 理科問題の結果を基に、理科バフを決定または選択する。
    /// </summary>
    ScienceBuff = 30,

    /// <summary>
    /// 数学問題へ回答する。
    /// </summary>
    MathQuiz = 40,

    /// <summary>
    /// 数学問題の結果を基に、数学バフを決定または選択する。
    /// </summary>
    MathBuff = 50,

    /// <summary>
    /// 日本史バフを選択する。
    /// </summary>
    HistoryBuff = 60,

    /// <summary>
    /// 戦闘へ参加させるキャラクターを選択する。
    /// </summary>
    CharacterSelect = 70,

    /// <summary>
    /// 戦闘の前に挟む会話イベント（強さを調べる／仲間にする／断ってそのまま戦う）。
    /// CaveBattleRuleset.AllowsRecruitmentがfalseの戦闘（仲間にできない戦闘）では発生しない。
    /// どの選択をしてもBattleへ進む。
    /// </summary>
    Conversation = 75,

    /// <summary>
    /// 選択キャラクター、技、所持バフを使って戦闘を実行する。
    /// </summary>
    Battle = 80,

    /// <summary>
    /// 戦闘結果を基に通常報酬や連勝ボーナスを計算・付与する。
    /// </summary>
    Reward = 90,

    /// <summary>
    /// 勝敗、ダメージ、連勝数、獲得報酬、ログを表示する。
    /// </summary>
    Result = 100,

    /// <summary>
    /// 敗北または規定連勝数への到達により、今回の洞窟探索が終了した状態。
    /// </summary>
    Finished = 110
}
