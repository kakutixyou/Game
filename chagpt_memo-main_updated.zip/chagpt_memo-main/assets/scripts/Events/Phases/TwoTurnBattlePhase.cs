using System;
using System.Collections;
using System.Collections.Generic;
using CaveGame.CaveBattle;
using UnityEngine;

/// <summary>
/// 洞窟戦闘（2ターン固定）の計算と、計算済み行動列のアニメーション再生を統括するPhase。
///
/// ルール（仕様どおり）:
/// ・戦闘は必ず2ターン。各キャラクターはCSVで指定された行動（skill_turn_1 / skill_turn_2）を
///   そのターンに必ず使用する。選択の余地はない。
/// ・n_val = 攻撃力。ダメージ量として使用する（× hits）。
/// ・s_val = 行動が発生するタイミング。値が小さいほど先に発生する。
///           -999 の場合はそのターン何もできない。
/// ・r_val = バフの持続ターン数。戦闘は基本2ターンで終わるため、
///           999のような極端な値が入っていても実害がないことが多い。
/// ・2ターンとも終了した後、両者の残りHPを比較し、高い方が勝利。同じ場合は引き分け。
///   ただし RULE_CHANGE 系の効果でルールが「HPが低い方が勝つ」に反転している場合はそれに従う。
///
/// アニメーション方針（ユーザー指示ベース）:
/// ・攻撃側自身のアニメーションは「相手にダメージを与える行動か、与えない行動か」という
///   2系統だけをキャラクター単位（CharacterAnimationController）で設定できればよい。
///   技ごとに個別の再生クリップを大量に登録する必要はない。
/// ・「攻撃を受けた」ことを見せるのは受け手側の役目。実際にダメージが入った時だけ
///   被弾リアクションを再生し、その結果HPが0になった場合は撃破モーションに差し替える。
///   自傷・自滅技（SELF_DAMAGE等）で自分のHPが0になった場合は、自分自身が撃破モーションを再生する。
/// ・即死技やルール反転など「既存の技にバフ等で追加された特殊効果」は、
///   上記の基本アクション/リアクションに重ねて再生する「特殊効果演出」として扱う
///   （発動させた側のキャラクターに紐付ける）。
///
/// 責務:
/// 1. CaveBattleDataRepositoryからキャラクター・技を取得して2ターン分の行動を計算
/// 2. 計算済みCaveBattleActionRecordを順番にアニメーション再生
/// 3. 演出終了後にCaveEventStateへ最終結果を反映
///
/// 非責務:
/// ・リザルト画面への遷移 / 連勝報酬の付与 / CSVの直接読込
/// </summary>
public sealed class TwoTurnBattlePhase : MonoBehaviour
{
    [Header("Data")]
    [SerializeField] private CaveBattleDataLoader dataLoader;

    [Header("Character Animation")]
    [SerializeField] private CharacterAnimationController playerAnimationController;
    [SerializeField] private CharacterAnimationController enemyAnimationController;

    [Header("Animation Timing")]
    [SerializeField, Min(0.1f)] private float animationTimeoutSeconds = 4f;
    [SerializeField, Min(0f)] private float missingControllerDelaySeconds = 0.08f;

    [Header("Debug")]
    [SerializeField] private bool enableDebugLog = true;

    private const int TotalTurns = 2;

    private bool isRunning;
    private Coroutine runningCoroutine;
    private Action<TwoTurnBattlePhaseResult> activeCallback;

    public bool IsRunning => isRunning;

    /// <summary>
    /// 戦闘を開始する。playerCharacterId/enemyCharacterIdはjapanese_history_chars_expanded.csvのid。
    /// </summary>
    public bool Execute(
        CaveEventState state,
        int playerCharacterId,
        int enemyCharacterId,
        Action<TwoTurnBattlePhaseResult> onCompleted)
    {
        return Execute(state, playerCharacterId, enemyCharacterId, null, onCompleted);
    }

    /// <summary>
    /// rulesetを指定した戦闘を開始する。nullを渡すと通常ルール（CaveBattleRuleset.Normal）で解決する。
    /// 「負けたら勝ち」イベントや「運が絡む効果が90%になる」イベントなどはここでrulesetを切り替える。
    /// </summary>
    public bool Execute(
        CaveEventState state,
        int playerCharacterId,
        int enemyCharacterId,
        CaveBattleRuleset ruleset,
        Action<TwoTurnBattlePhaseResult> onCompleted)
    {
        if (isRunning)
        {
            Debug.LogWarning("[TwoTurnBattlePhase] 戦闘中のため二重実行を拒否しました。");
            return false;
        }

        TwoTurnBattlePhaseResult validationFailure = ValidateStart(state);
        if (validationFailure != null)
        {
            onCompleted?.Invoke(validationFailure);
            return false;
        }

        CaveBattleRuleset effectiveRuleset = ruleset != null ? ruleset : CaveBattleRuleset.Normal;

        isRunning = true;
        activeCallback = onCompleted;
        runningCoroutine = StartCoroutine(
            BattleSequence(state, playerCharacterId, enemyCharacterId, effectiveRuleset));
        return true;
    }

    public void Cancel()
    {
        if (!isRunning)
        {
            return;
        }

        if (runningCoroutine != null)
        {
            StopCoroutine(runningCoroutine);
        }

        FinishExecution(TwoTurnBattlePhaseResult.CreateFailure("戦闘がキャンセルされました。"));
    }

    private TwoTurnBattlePhaseResult ValidateStart(CaveEventState state)
    {
        if (state == null)
        {
            return TwoTurnBattlePhaseResult.CreateFailure("CaveEventStateがnullです。");
        }

        if (!state.IsRunActive || state.IsRunFinished)
        {
            return TwoTurnBattlePhaseResult.CreateFailure("洞窟探索が有効ではありません。");
        }

        if (dataLoader == null || !dataLoader.IsLoaded)
        {
            return TwoTurnBattlePhaseResult.CreateFailure("CaveBattleDataLoaderの読込が完了していません。");
        }

        return null;
    }

    private IEnumerator BattleSequence(
        CaveEventState state,
        int playerCharacterId,
        int enemyCharacterId,
        CaveBattleRuleset ruleset)
    {
        TwoTurnBattlePhaseResult result;

        try
        {
            CaveBattleDataRepository repository = dataLoader.Repository;
            CaveBattleCharacter playerData = repository.GetCharacter(playerCharacterId);
            CaveBattleCharacter enemyData = repository.GetCharacter(enemyCharacterId);

            state.BeginBattle(enemyData.Id.ToString(), enemyData.CharacterName, enemyData.MaxHp);

            if (enableDebugLog)
            {
                Debug.Log($"[TwoTurnBattlePhase] ルール適用: {ruleset.RulesetName}");
            }

            result = ResolveBattle(repository, playerData, enemyData, ruleset);
        }
        catch (Exception ex)
        {
            Debug.LogError("[TwoTurnBattlePhase] 戦闘計算エラー\n" + ex);
            FinishExecution(TwoTurnBattlePhaseResult.CreateFailure(ex.Message));
            yield break;
        }

        // 計算済みの結果だけを使って演出する。演出中に勝敗を再計算しない。
        for (int i = 0; i < result.Actions.Count; i++)
        {
            yield return PlayActionAnimation(result.Actions[i]);
        }

        ApplyResultToState(state, result);
        FinishExecution(result);
    }

    /// <summary>
    /// 2ターン分の行動をすべて計算する（演出とは独立した純粋な戦闘計算）。
    /// </summary>
    private TwoTurnBattlePhaseResult ResolveBattle(
        CaveBattleDataRepository repository,
        CaveBattleCharacter playerData,
        CaveBattleCharacter enemyData,
        CaveBattleRuleset ruleset)
    {
        Combatant player = new Combatant(BattleActorSide.Player, playerData);
        Combatant enemy = new Combatant(BattleActorSide.Enemy, enemyData);

        // 「負けたら勝ち」イベントはここでHpLowerWinsを最初からtrueにしておくだけでよい。
        // 通常戦闘中にRULE_CHANGE系の技が使われた場合は、そこから更に上書きされる。
        BattleRuleState ruleState = new BattleRuleState
        {
            HpLowerWins = ruleset.InvertFinalResult
        };

        List<CaveBattleActionRecord> records = new List<CaveBattleActionRecord>();

        for (int turn = 1; turn <= TotalTurns; turn++)
        {
            CaveBattleSkill playerSkill = repository.GetSkill(playerData.GetSkillIdForTurn(turn));
            CaveBattleSkill enemySkill = repository.GetSkill(enemyData.GetSkillIdForTurn(turn));

            foreach (BattleActorSide side in DetermineTurnOrder(player, playerSkill, enemy, enemySkill))
            {
                Combatant actor = side == BattleActorSide.Player ? player : enemy;
                Combatant opponent = side == BattleActorSide.Player ? enemy : player;
                CaveBattleSkill skill = side == BattleActorSide.Player ? playerSkill : enemySkill;

                records.Add(ResolveAction(turn, actor, opponent, skill, ruleState, ruleset));
            }

            TickBuffs(player);
            TickBuffs(enemy);
        }

        BattleResultType outcome = DetermineOutcome(player, enemy, ruleState);

        return TwoTurnBattlePhaseResult.CreateSuccess(
            outcome,
            player.CurrentHp,
            enemy.CurrentHp,
            records);
    }

    /// <summary>
    /// そのターンの行動順を決める。
    /// s_valが小さいほど先に行動する。同値ならbase_speedが高い方、それも同じならプレイヤーが先。
    /// s_val == -999 のキャラクターや、既にHPが0のキャラクターはそもそも行動しない。
    /// </summary>
    private static IEnumerable<BattleActorSide> DetermineTurnOrder(
        Combatant player,
        CaveBattleSkill playerSkill,
        Combatant enemy,
        CaveBattleSkill enemySkill)
    {
        bool playerCanAct = player.IsAlive && !playerSkill.CannotAct;
        bool enemyCanAct = enemy.IsAlive && !enemySkill.CannotAct;

        if (playerCanAct && enemyCanAct)
        {
            bool playerFirst = playerSkill.SVal != enemySkill.SVal
                ? playerSkill.SVal < enemySkill.SVal
                : player.Data.BaseSpeed >= enemy.Data.BaseSpeed;

            if (playerFirst)
            {
                yield return BattleActorSide.Player;
                yield return BattleActorSide.Enemy;
            }
            else
            {
                yield return BattleActorSide.Enemy;
                yield return BattleActorSide.Player;
            }
        }
        else if (playerCanAct)
        {
            yield return BattleActorSide.Player;
        }
        else if (enemyCanAct)
        {
            yield return BattleActorSide.Enemy;
        }
        // どちらも行動できない場合、このターンは誰も行動しない。
    }

    /// <summary>
    /// 1体分の行動（技1回）を解決する。
    ///
    /// 「affected」= 実際にHPが増減する対象。target列がself/all指定の技は自分自身、
    /// enemy指定の技は相手になる（RULE_CHANGE_AND_SUICIDEのみtarget=allだが自傷なので特別扱い）。
    /// AffectedSideとCausedDefeatはこの「affected」を基準にアニメーション側へ渡す。
    /// </summary>
    private static CaveBattleActionRecord ResolveAction(
        int turnNumber,
        Combatant actor,
        Combatant opponent,
        CaveBattleSkill skill,
        BattleRuleState ruleState,
        CaveBattleRuleset ruleset)
    {
        Combatant defaultAffected = skill.TargetsSelf ? actor : opponent;

        CaveBattleActionRecord record = new CaveBattleActionRecord(
            turnNumber, actor.Side, defaultAffected.Side, actor.Data.Id, skill.Id, skill.SkillName);

        if (!actor.IsAlive || skill.CannotAct)
        {
            record.DidAct = false;
            record.Note = skill.CannotAct
                ? "s_valが-999のため、このターンは何もできない。"
                : "HPが0のため行動できない。";
            record.ActorRemainingHp = actor.CurrentHp;
            record.AffectedRemainingHp = defaultAffected.CurrentHp;
            return record;
        }

        Combatant affected = defaultAffected;
        int flatDamage = Math.Max(0, skill.NVal) * Math.Max(1, skill.Hits);
        int affectedHpBefore = affected.CurrentHp;

        switch (skill.EffectTypeRaw.ToUpperInvariant())
        {
            case "ATTACK":
            case "IGNORE_DEF_ATTACK":
                record.Damage = affected.ApplyDamage(flatDamage);
                break;

            case "CONDITIONAL_ATTACK":
                if (CaveBattleParamUtil.TryGetInt(skill.ParamsJson, "targetHp_gte", out int threshold) &&
                    affected.CurrentHp < threshold)
                {
                    record.Note = "発動条件（相手の残りHP）を満たさず不発。";
                }
                else
                {
                    int conditionalDamage = CaveBattleParamUtil.TryGetInt(
                        skill.ParamsJson, "damage", out int paramDamage)
                        ? Math.Max(0, paramDamage)
                        : flatDamage;
                    record.Damage = affected.ApplyDamage(conditionalDamage);
                }

                break;

            case "HEAL":
                record.Healing = affected.ApplyHeal(Math.Max(0, skill.NVal));
                break;

            case "BUFF":
                actor.Buffs.Add(new CaveBattleActiveBuff(skill.Id, skill.SkillName, skill.RVal));
                record.Note = "バフを付与（持続ターンのみ管理。個別効果の演算は未実装）。";
                break;

            case "NO_ACTION":
                record.Note = "行動なし。";
                break;

            case "SELF_DAMAGE":
                {
                    int amount;
                    if (CaveBattleParamUtil.IsStringValue(skill.ParamsJson, "amount", "ALL"))
                    {
                        amount = affected.CurrentHp;
                    }
                    else if (!CaveBattleParamUtil.TryGetInt(skill.ParamsJson, "amount", out amount))
                    {
                        amount = Math.Max(0, skill.NVal);
                    }

                    record.Damage = affected.ApplyDamage(Math.Max(0, amount));
                    break;
                }

            case "SELF_DEBUFF":
                {
                    int amount = Math.Abs(skill.NVal);
                    if (amount > 0)
                    {
                        record.Damage = affected.ApplyDamage(amount);
                    }

                    actor.Buffs.Add(new CaveBattleActiveBuff(skill.Id, skill.SkillName, skill.RVal));
                    record.Note = "能力低下バフとして登録（ステータス演算は未実装。HP分のみ反映）。";
                    break;
                }

            case "SPECIAL_ATTACK":
                {
                    // 現状データはINSTANT_DEFEATのみだが、effectパラメータで将来の追加に備える。
                    float successChance;
                    if (ruleset.UseFixedLuckPercent)
                    {
                        // 「運が絡む効果が90%になる」イベント等では、通常の計算式を無視して固定値にする。
                        successChance = ruleset.FixedLuckPercent;
                    }
                    else
                    {
                        CaveBattleParamUtil.TryGetInt(skill.ParamsJson, "baseAccuracy", out int baseAccuracy);
                        baseAccuracy = Mathf.Clamp(baseAccuracy, 0, 100);

                        float hpRatio = affected.MaxHp > 0
                            ? Mathf.Clamp01((float)affected.CurrentHp / affected.MaxHp)
                            : 0f;
                        // 相手のHPが高いほど成功率が上がる：baseAccuracy(HP0%時)～100%(満タン時)で線形補間。
                        successChance = baseAccuracy + hpRatio * (100 - baseAccuracy);
                    }

                    bool success = UnityEngine.Random.Range(0f, 100f) < successChance;

                    if (success)
                    {
                        record.Damage = affected.ApplyDamage(affected.CurrentHp);
                        record.SpecialEffect = SpecialEffectAnimationType.InstantDefeat;
                        record.Note = $"即死効果が発動した（成功率{successChance:F0}%）。";
                    }
                    else
                    {
                        record.Note = $"即死効果が外れた（成功率{successChance:F0}%）。";
                    }

                    break;
                }

            case "RULE_CHANGE":
                {
                    bool reversed = CaveBattleParamUtil.IsStringValue(skill.ParamsJson, "rule", "REVERSE_BATTLE");
                    ruleState.HpLowerWins = reversed;
                    record.SpecialEffect = reversed
                        ? SpecialEffectAnimationType.RuleReversed
                        : SpecialEffectAnimationType.RuleNormalized;
                    record.Note = reversed
                        ? "バトルルールを「HPが低い方が勝つ」に変更した。"
                        : "バトルルールを通常（HPが高い方が勝つ）に戻した。";
                    break;
                }

            case "RULE_CHANGE_AND_SUICIDE":
                {
                    // target列は"all"だが、実際に自分のHPを0にするのは常にactor自身。
                    affected = actor;
                    affectedHpBefore = affected.CurrentHp;

                    ruleState.HpLowerWins = true;
                    record.Damage = affected.ApplyDamage(affected.CurrentHp);
                    record.SpecialEffect = SpecialEffectAnimationType.RuleReversed;
                    record.Note = "バトルルールを「HPが低い方が勝つ」に反転させ、自身のHPを0にした。";
                    break;
                }

            case "OVERWRITE_AUTHORITY":
                record.Damage = affected.ApplyDamage(flatDamage);
                affected.Buffs.Clear();
                ruleState.HpLowerWins = false;
                record.SpecialEffect = SpecialEffectAnimationType.AuthorityOverwrite;
                record.Note = "相手のバフと特殊ルールを解除しつつダメージを与えた。";
                break;

            default:
                if (skill.TargetsEnemy && skill.NVal > 0)
                {
                    record.Damage = affected.ApplyDamage(flatDamage);
                    record.Note =
                        $"未対応のeffect_type '{skill.EffectTypeRaw}' のため、n_val分のダメージのみ適用。";
                }
                else
                {
                    record.Note = $"未対応のeffect_type '{skill.EffectTypeRaw}' のため効果なし。";
                }

                break;
        }

        record.AffectedSide = affected.Side;
        record.CausedDefeat = affectedHpBefore > 0 && affected.CurrentHp <= 0;
        record.ActorRemainingHp = actor.CurrentHp;
        record.AffectedRemainingHp = affected.CurrentHp;
        return record;
    }

    private static void TickBuffs(Combatant combatant)
    {
        for (int i = combatant.Buffs.Count - 1; i >= 0; i--)
        {
            CaveBattleActiveBuff buff = combatant.Buffs[i];
            buff.RemainingTurns--;

            // r_valが0や999でも、ここで単純に1ずつ減らすだけなので暴走しない。
            if (buff.RemainingTurns <= 0)
            {
                combatant.Buffs.RemoveAt(i);
            }
        }
    }

    private static BattleResultType DetermineOutcome(Combatant player, Combatant enemy, BattleRuleState ruleState)
    {
        int comparison = player.CurrentHp.CompareTo(enemy.CurrentHp);
        if (ruleState.HpLowerWins)
        {
            comparison = -comparison;
        }

        if (comparison > 0)
        {
            return BattleResultType.Win;
        }

        if (comparison < 0)
        {
            return BattleResultType.Lose;
        }

        return BattleResultType.Draw;
    }

    /// <summary>
    /// 1アクション分の演出を再生する。
    /// 1. 行動側が「相手にダメージを与えたかどうか」で分岐したアクションを再生
    /// 2. 相手にダメージが入った場合のみ、受け手側が被弾/撃破リアクションを再生
    /// 3. 自傷等で自分が倒れた場合は、行動側自身が撃破モーションを再生
    /// 4. 即死・ルール変更などの特殊効果があれば、発動させた側に重ねて再生
    /// </summary>
    private IEnumerator PlayActionAnimation(CaveBattleActionRecord record)
    {
        if (!record.DidAct)
        {
            yield break;
        }

        CharacterAnimationController actorController = GetController(record.ActorSide);
        CharacterAnimationController affectedController = GetController(record.AffectedSide);
        bool dealsDamageToOpponent = record.AffectedSide != record.ActorSide && record.Damage > 0;

        yield return PlayOrWait(
            actorController != null ? actorController.PlayAction(dealsDamageToOpponent) : null);

        if (record.AffectedSide != record.ActorSide && record.Damage > 0)
        {
            IEnumerator reaction = affectedController == null
                ? null
                : (record.CausedDefeat ? affectedController.PlayDefeat() : affectedController.PlayHitReaction());
            yield return PlayOrWait(reaction);
        }
        else if (record.AffectedSide == record.ActorSide && record.CausedDefeat)
        {
            yield return PlayOrWait(actorController != null ? actorController.PlayDefeat() : null);
        }

        if (record.SpecialEffect != SpecialEffectAnimationType.None)
        {
            yield return PlayOrWait(
                actorController != null ? actorController.PlaySpecialEffect(record.SpecialEffect) : null);
        }
    }

    private CharacterAnimationController GetController(BattleActorSide side)
    {
        return side == BattleActorSide.Player ? playerAnimationController : enemyAnimationController;
    }

    /// <summary>
    /// アニメーションルーチンがあれば再生し、なければ最低限の間だけ待つ
    /// （controllerが未アサインでも演出テンポを崩さないためのフォールバック）。
    /// </summary>
    private IEnumerator PlayOrWait(IEnumerator routine)
    {
        if (routine == null)
        {
            if (missingControllerDelaySeconds > 0f)
            {
                yield return new WaitForSecondsRealtime(missingControllerDelaySeconds);
            }

            yield break;
        }

        bool completed = false;
        Coroutine animationCoroutine = StartCoroutine(RunAnimation(routine, () => completed = true));

        float startedAt = Time.realtimeSinceStartup;
        while (!completed && Time.realtimeSinceStartup - startedAt < animationTimeoutSeconds)
        {
            yield return null;
        }

        if (!completed && animationCoroutine != null)
        {
            StopCoroutine(animationCoroutine);
            Debug.LogWarning("[TwoTurnBattlePhase] アニメーションがタイムアウトしました。");
        }
    }

    private static IEnumerator RunAnimation(IEnumerator routine, Action onCompleted)
    {
        if (routine != null)
        {
            yield return routine;
        }

        onCompleted?.Invoke();
    }

    private static void ApplyResultToState(CaveEventState state, TwoTurnBattlePhaseResult result)
    {
        state.SetCurrentTurn(TotalTurns);

        int playerDamageDealt = 0;
        int playerDamageReceived = 0;
        for (int i = 0; i < result.Actions.Count; i++)
        {
            CaveBattleActionRecord record = result.Actions[i];
            if (record.ActorSide == BattleActorSide.Player && record.AffectedSide == BattleActorSide.Enemy)
            {
                playerDamageDealt += record.Damage;
            }

            if (record.AffectedSide == BattleActorSide.Player)
            {
                playerDamageReceived += record.Damage;
            }
        }

        state.ApplyBattleResult(result.ResultType, playerDamageDealt, playerDamageReceived, result.EnemyRemainingHp);
    }

    private void FinishExecution(TwoTurnBattlePhaseResult result)
    {
        Action<TwoTurnBattlePhaseResult> callback = activeCallback;
        activeCallback = null;
        runningCoroutine = null;
        isRunning = false;

        if (enableDebugLog)
        {
            Debug.Log(result != null && result.Succeeded
                ? $"[TwoTurnBattlePhase] 完了: {result.ResultType}, Actions={result.Actions.Count}"
                : $"[TwoTurnBattlePhase] 失敗: {result?.ErrorMessage}");
        }

        callback?.Invoke(result);
    }

    private void OnDisable()
    {
        if (isRunning)
        {
            Cancel();
        }
    }

    /// <summary>
    /// 計算専用の実行時ステータス。CharacterDataは変更しない。
    /// </summary>
    private sealed class Combatant
    {
        public BattleActorSide Side { get; }
        public CaveBattleCharacter Data { get; }
        public int MaxHp => Data.MaxHp;
        public int CurrentHp { get; private set; }
        public List<CaveBattleActiveBuff> Buffs { get; } = new List<CaveBattleActiveBuff>();
        public bool IsAlive => CurrentHp > 0;

        public Combatant(BattleActorSide side, CaveBattleCharacter data)
        {
            Side = side;
            Data = data;
            CurrentHp = data.MaxHp;
        }

        /// <summary>ダメージを適用し、実際に減った量を返す。</summary>
        public int ApplyDamage(int amount)
        {
            int before = CurrentHp;
            CurrentHp = Math.Max(0, CurrentHp - Math.Max(0, amount));
            return before - CurrentHp;
        }

        /// <summary>回復を適用し、実際に増えた量を返す。</summary>
        public int ApplyHeal(int amount)
        {
            int before = CurrentHp;
            CurrentHp = Math.Min(Data.MaxHp, CurrentHp + Math.Max(0, amount));
            return CurrentHp - before;
        }
    }

    /// <summary>
    /// バトル全体で共有される特殊ルール状態（RULE_CHANGE系で書き換えられる）。
    /// </summary>
    private sealed class BattleRuleState
    {
        /// <summary>trueの間はHPが低い方が勝利する（通常はfalse＝HPが高い方が勝利）。</summary>
        public bool HpLowerWins;
    }
}

public enum BattleActorSide
{
    Player = 0,
    Enemy = 1
}

/// <summary>
/// 技の基本効果に対して、バフ等で追加されうる「特殊効果」の演出種別。
/// 発動させた側（actor）のCharacterAnimationController.PlaySpecialEffectに渡される。
/// </summary>
public enum SpecialEffectAnimationType
{
    None = 0,
    /// <summary>即死効果が成功した（SPECIAL_ATTACK / INSTANT_DEFEAT）。</summary>
    InstantDefeat,
    /// <summary>勝敗条件を「HPが低い方が勝つ」へ反転させた（RULE_CHANGE / RULE_CHANGE_AND_SUICIDE）。</summary>
    RuleReversed,
    /// <summary>勝敗条件を通常に戻した（RULE_CHANGE）。</summary>
    RuleNormalized,
    /// <summary>相手のバフ・特殊ルールを解除した（OVERWRITE_AUTHORITY）。</summary>
    AuthorityOverwrite
}

/// <summary>
/// 戦闘中に付与されたバフの実行時状態。
/// 個別の効果（EVASION_UPなど）の演算はまだ実装していないため、
/// ここでは「誰が・どの技で・あと何ターン持続するか」だけを管理する。
/// </summary>
[Serializable]
public sealed class CaveBattleActiveBuff
{
    public int SourceSkillId { get; }
    public string SourceSkillName { get; }
    public int RemainingTurns { get; set; }

    public CaveBattleActiveBuff(int sourceSkillId, string sourceSkillName, int remainingTurns)
    {
        SourceSkillId = sourceSkillId;
        SourceSkillName = sourceSkillName ?? string.Empty;
        RemainingTurns = remainingTurns;
    }
}

[Serializable]
public sealed class CaveBattleActionRecord
{
    public int TurnNumber { get; }
    public BattleActorSide ActorSide { get; }

    /// <summary>実際にHP等が増減した対象。self系技ならActorSideと同じ、enemy系技なら相手側。</summary>
    public BattleActorSide AffectedSide { get; set; }

    public int ActorCharacterId { get; }
    public int SkillId { get; }
    public string SkillName { get; }
    public int Damage { get; set; }
    public int Healing { get; set; }
    public bool DidAct { get; set; } = true;

    /// <summary>このアクションでAffectedSide側のHPが0になった（撃破/自滅）。</summary>
    public bool CausedDefeat { get; set; }

    /// <summary>バフ等で追加された特殊効果の演出種別。Noneなら通常のアクション/リアクションのみ。</summary>
    public SpecialEffectAnimationType SpecialEffect { get; set; } = SpecialEffectAnimationType.None;

    public string Note { get; set; }
    public int ActorRemainingHp { get; set; }
    public int AffectedRemainingHp { get; set; }

    public CaveBattleActionRecord(
        int turnNumber,
        BattleActorSide actorSide,
        BattleActorSide affectedSide,
        int actorCharacterId,
        int skillId,
        string skillName)
    {
        TurnNumber = turnNumber;
        ActorSide = actorSide;
        AffectedSide = affectedSide;
        ActorCharacterId = actorCharacterId;
        SkillId = skillId;
        SkillName = skillName ?? string.Empty;
    }
}

[Serializable]
public sealed class TwoTurnBattlePhaseResult
{
    public bool Succeeded { get; private set; }
    public string ErrorMessage { get; private set; }
    public BattleResultType ResultType { get; private set; }
    public int PlayerRemainingHp { get; private set; }
    public int EnemyRemainingHp { get; private set; }
    public IReadOnlyList<CaveBattleActionRecord> Actions { get; private set; }

    private TwoTurnBattlePhaseResult()
    {
        ErrorMessage = string.Empty;
        Actions = new List<CaveBattleActionRecord>().AsReadOnly();
    }

    public static TwoTurnBattlePhaseResult CreateSuccess(
        BattleResultType resultType,
        int playerRemainingHp,
        int enemyRemainingHp,
        IList<CaveBattleActionRecord> actions)
    {
        return new TwoTurnBattlePhaseResult
        {
            Succeeded = true,
            ResultType = resultType,
            PlayerRemainingHp = Math.Max(0, playerRemainingHp),
            EnemyRemainingHp = Math.Max(0, enemyRemainingHp),
            Actions = new List<CaveBattleActionRecord>(actions ?? new List<CaveBattleActionRecord>()).AsReadOnly()
        };
    }

    public static TwoTurnBattlePhaseResult CreateFailure(string errorMessage)
    {
        return new TwoTurnBattlePhaseResult
        {
            Succeeded = false,
            ErrorMessage = errorMessage ?? "不明な戦闘エラーです。"
        };
    }
}
