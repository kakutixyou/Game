using System;
using System.Collections.Generic;
using UnityEngine;

namespace CaveGame.CaveBattle
{
    /// <summary>
    /// 日本史/理科/数学バフダンジョン用の「何人抜きできるか」ガントレット進行役。
    ///
    /// 仕様:
    /// ・演出なし。TwoTurnBattlePhaseにCharacterAnimationControllerを割り当てなければ、
    ///   各アクションはmissingControllerDelaySeconds分の短い待機だけで進む。
    /// ・毎戦、HPは全回復する（TwoTurnBattlePhaseは戦闘のたびに新しいCombatantをMaxHpで
    ///   生成するため、これは特別な実装をしなくても自動的に満たされる）。
    /// ・1勝するごとに、数学→理科→日本史の順で、それぞれ独立に指定確率（既定1%ずつ）で
    ///   バフを1つ抽選して獲得する。
    /// ・終了条件は「負け」のみ。引き分けは敗北扱いにせず次戦へ進む（勝利カウントも増えない）。
    /// ・負けた時点で、敗因（現状は常にキャラクター起因。理由はCaveGauntletDefeatCauseのコメント参照）
    ///   とその時点のバフ構成をCaveGauntletResultにまとめて返す。
    /// </summary>
    public sealed class CaveGauntletRunner : MonoBehaviour
    {
        [Header("Dependencies")]
        [SerializeField] private TwoTurnBattlePhase battlePhase;
        [SerializeField] private CaveBattleDataLoader dataLoader;
        [SerializeField] private CaveBattleBuffDataLoader buffDataLoader;

        [Header("勝利ごとのバフ獲得確率")]
        [SerializeField, Range(0f, 1f)] private float mathBuffChance = 0.01f;
        [SerializeField, Range(0f, 1f)] private float scienceBuffChance = 0.01f;
        [SerializeField, Range(0f, 1f)] private float historyBuffChance = 0.01f;

        [Header("Debug")]
        [SerializeField] private bool enableDebugLog = true;

        private readonly List<CaveGauntletRoundLog> rounds = new List<CaveGauntletRoundLog>();
        private readonly List<CaveAcquiredBuff> acquiredBuffs = new List<CaveAcquiredBuff>();

        private int winCount;
        private int playerCharacterId;
        private CaveEventState state;
        private Action<CaveGauntletResult> onFinished;

        public bool IsRunning { get; private set; }
        public int CurrentWinCount => winCount;

        /// <summary>
        /// ガントレットを開始する。playerCharacterIdはjapanese_history_chars_expanded.csvのid。
        /// </summary>
        public bool StartRun(CaveEventState state, int playerCharacterId, Action<CaveGauntletResult> onFinished)
        {
            if (IsRunning)
            {
                Debug.LogWarning("[CaveGauntletRunner] 既にガントレット実行中です。");
                return false;
            }

            if (battlePhase == null || dataLoader == null || !dataLoader.IsLoaded)
            {
                CaveGauntletResult failure =
                    CaveGauntletResult.CreateAborted("TwoTurnBattlePhaseまたはCaveBattleDataLoaderが未設定/未読込です。");
                onFinished?.Invoke(failure);
                return false;
            }

            this.state = state;
            this.playerCharacterId = playerCharacterId;
            this.onFinished = onFinished;

            rounds.Clear();
            acquiredBuffs.Clear();
            winCount = 0;
            IsRunning = true;

            PlayNextRound();
            return true;
        }

        private void PlayNextRound()
        {
            int enemyCharacterId = PickRandomEnemyId();

            bool started = battlePhase.Execute(
                state,
                playerCharacterId,
                enemyCharacterId,
                CaveBattleRuleset.Normal,
                result => OnRoundCompleted(result, enemyCharacterId));

            if (!started)
            {
                IsRunning = false;
                onFinished?.Invoke(CaveGauntletResult.CreateAborted("戦闘の開始に失敗しました。"));
            }
        }

        /// <summary>
        /// 次に戦う相手をランダムに選ぶ（プレイヤー自身のキャラは除く）。
        /// 現状は毎回全キャラから抽選するだけの単純な実装で、既に戦った相手の重複除外はしていない。
        /// </summary>
        private int PickRandomEnemyId()
        {
            List<int> candidates = new List<int>(dataLoader.Repository.Characters.Keys);
            candidates.Remove(playerCharacterId);

            if (candidates.Count == 0)
            {
                // キャラクターが1人しかいない等の極端なケースのフォールバック。
                return playerCharacterId;
            }

            return candidates[UnityEngine.Random.Range(0, candidates.Count)];
        }

        private void OnRoundCompleted(TwoTurnBattlePhaseResult result, int enemyCharacterId)
        {
            if (result == null || !result.Succeeded)
            {
                IsRunning = false;
                onFinished?.Invoke(CaveGauntletResult.CreateAborted(result?.ErrorMessage));
                return;
            }

            CaveBattleCharacter enemyData = dataLoader.Repository.GetCharacter(enemyCharacterId);

            rounds.Add(new CaveGauntletRoundLog(
                rounds.Count + 1,
                enemyCharacterId,
                enemyData.CharacterName,
                result.ResultType,
                result.PlayerRemainingHp,
                result.EnemyRemainingHp));

            switch (result.ResultType)
            {
                case BattleResultType.Win:
                    winCount++;
                    RollBuffs();
                    PlayNextRound();
                    break;

                case BattleResultType.Draw:
                    // 終了条件は負けのみ。引き分けは勝利数を増やさずそのまま次戦へ。
                    if (enableDebugLog)
                    {
                        Debug.Log("[CaveGauntletRunner] 引き分けのため勝利数は増やさず次戦へ進みます。");
                    }

                    PlayNextRound();
                    break;

                case BattleResultType.Lose:
                    IsRunning = false;
                    FinishRun(enemyCharacterId, enemyData.CharacterName);
                    break;
            }
        }

        private void RollBuffs()
        {
            CaveBattleBuffRepository buffRepository =
                buffDataLoader != null && buffDataLoader.IsLoaded ? buffDataLoader.Repository : null;

            if (buffRepository == null)
            {
                return;
            }

            // 仕様どおり数学→理科→日本史の順で、それぞれ独立に抽選する。
            TryAcquireSubjectBuff(buffRepository, CaveBuffSubject.Math, mathBuffChance);
            TryAcquireSubjectBuff(buffRepository, CaveBuffSubject.Science, scienceBuffChance);
            TryAcquireHistoryBuff(buffRepository, historyBuffChance);
        }

        private void TryAcquireSubjectBuff(CaveBattleBuffRepository repository, CaveBuffSubject subject, float chance)
        {
            if (UnityEngine.Random.value >= chance)
            {
                return;
            }

            CaveSubjectBuffData buff = repository.DrawRandomSubjectBuff(subject);
            if (buff == null)
            {
                return;
            }

            acquiredBuffs.Add(new CaveAcquiredBuff(subject, buff.Id, buff.BuffName, buff.Description, winCount));

            if (enableDebugLog)
            {
                Debug.Log($"[CaveGauntletRunner] {subject}バフ獲得: {buff.BuffName}（{winCount}勝後）");
            }
        }

        private void TryAcquireHistoryBuff(CaveBattleBuffRepository repository, float chance)
        {
            if (UnityEngine.Random.value >= chance)
            {
                return;
            }

            CaveHistoryBuffData buff = repository.DrawRandomHistoryBuff();
            if (buff == null)
            {
                return;
            }

            acquiredBuffs.Add(
                new CaveAcquiredBuff(CaveBuffSubject.History, buff.Id, buff.BuffName, buff.Description, winCount));

            if (enableDebugLog)
            {
                Debug.Log($"[CaveGauntletRunner] 日本史バフ獲得: {buff.BuffName}（{winCount}勝後）");
            }
        }

        private void FinishRun(int losingEnemyCharacterId, string losingEnemyCharacterName)
        {
            // 現時点ではバフが戦闘計算に一切影響しないため、敗因は常にキャラクター起因として記録する。
            // バフの個別効果を実装した後は、「バフが無かった場合でも同じ結果だったか」等の
            // 判定を追加してCharacter/Buffを出し分ける必要がある。
            const string defeatNote =
                "現時点ではバフが戦闘計算に影響しないため、敗因は常にキャラクター起因として記録しています。";

            CaveGauntletResult result = CaveGauntletResult.CreateFinished(
                winCount,
                rounds,
                acquiredBuffs,
                CaveGauntletDefeatCause.Character,
                defeatNote,
                losingEnemyCharacterId,
                losingEnemyCharacterName);

            if (enableDebugLog)
            {
                Debug.Log($"[CaveGauntletRunner] 終了: {winCount}人抜き、獲得バフ{acquiredBuffs.Count}個。");
            }

            onFinished?.Invoke(result);
        }
    }
}
