using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 1体のキャラクターの戦闘中アニメーションを制御する。
///
/// 設計方針:
/// ・攻撃側自身のアニメーションは「相手にダメージを与える行動か、与えない行動か」の
///   2系統だけをキャラクター単位で設定できればよい（技ごとに個別クリップを
///   大量に用意する必要はない）。TwoTurnBattlePhaseはこの2系統しか要求しない。
/// ・「攻撃を受けた」ことを見せるのは受け手側の役目。PlayHitReaction/PlayDefeatは
///   ダメージが実際に入った時だけTwoTurnBattlePhase側から呼ばれる。
/// ・即死技やルール反転など、既存技にバフ等で追加された特殊効果は
///   PlaySpecialEffectで演出として重ねて再生する。
///
/// このクラスはAnimatorのTrigger駆動を前提にした最小実装。
/// 実際のプロジェクトのAnimator Controller / モーションに合わせて、
/// トリガー名やクリップ長、Animation Eventでの終了通知などを調整してほしい。
/// </summary>
[RequireComponent(typeof(Animator))]
public class CharacterAnimationController : MonoBehaviour
{
    [Header("Animator")]
    [SerializeField] private Animator animator;

    [Header("基本アクション（キャラクター単位で1個ずつ設定）")]
    [Tooltip("このキャラクターの技が相手にダメージを与える時に再生するTrigger名")]
    [SerializeField] private string dealDamageActionTrigger = "Action_DealDamage";
    [Tooltip("このキャラクターの技が相手にダメージを与えない時（バフ・回復・不発など）に再生するTrigger名")]
    [SerializeField] private string noDamageActionTrigger = "Action_NoDamage";

    [Header("被弾側リアクション")]
    [SerializeField] private string hitReactionTrigger = "Hit";
    [SerializeField] private string defeatTrigger = "Defeat";

    [Header("特殊効果演出（発生しうるものだけ登録すればよい）")]
    [SerializeField] private List<SpecialEffectTriggerBinding> specialEffectTriggers =
        new List<SpecialEffectTriggerBinding>();

    [Header("再生完了までの待ち時間")]
    [Tooltip("Animation Event等で終了通知する仕組みを別途用意するまでのフォールバック秒数")]
    [SerializeField, Min(0.05f)] private float defaultClipSeconds = 0.8f;

    private void Reset()
    {
        animator = GetComponent<Animator>();
    }

    /// <summary>
    /// 自分の技が相手にダメージを与えるかどうかだけを見て、2系統のうち一方を再生する。
    /// </summary>
    public IEnumerator PlayAction(bool dealsDamageToOpponent)
    {
        string trigger = dealsDamageToOpponent ? dealDamageActionTrigger : noDamageActionTrigger;
        yield return PlayTrigger(trigger);
    }

    /// <summary>相手の攻撃で実際にダメージを受けた時のリアクション。</summary>
    public IEnumerator PlayHitReaction()
    {
        yield return PlayTrigger(hitReactionTrigger);
    }

    /// <summary>このキャラクターのHPが0になった時の撃破モーション（自滅時もこちらを使う）。</summary>
    public IEnumerator PlayDefeat()
    {
        yield return PlayTrigger(defeatTrigger);
    }

    /// <summary>
    /// 即死技・ルール反転など、既存技にバフ等で追加された特殊効果の演出。
    /// 対応するTriggerが未登録の場合は警告のみでスキップする（未実装の効果でも進行は止めない）。
    /// </summary>
    public IEnumerator PlaySpecialEffect(SpecialEffectAnimationType effectType)
    {
        if (effectType == SpecialEffectAnimationType.None)
        {
            yield break;
        }

        for (int i = 0; i < specialEffectTriggers.Count; i++)
        {
            SpecialEffectTriggerBinding binding = specialEffectTriggers[i];
            if (binding != null && binding.EffectType == effectType)
            {
                yield return PlayTrigger(binding.TriggerName);
                yield break;
            }
        }

        Debug.LogWarning(
            $"[CharacterAnimationController] '{effectType}' 用のTriggerが未設定のため演出をスキップしました。" +
            "specialEffectTriggersに追加してください。");
    }

    private IEnumerator PlayTrigger(string triggerName)
    {
        if (animator == null || string.IsNullOrEmpty(triggerName))
        {
            yield break;
        }

        animator.ResetTrigger(triggerName);
        animator.SetTrigger(triggerName);

        // TODO: Animation Eventからの終了通知に置き換えると、
        // クリップ長に依存しない正確なタイミングで次の行動へ進められる。
        yield return new WaitForSeconds(defaultClipSeconds);
    }

    [Serializable]
    private sealed class SpecialEffectTriggerBinding
    {
        [SerializeField] private SpecialEffectAnimationType effectType;
        [SerializeField] private string triggerName;

        public SpecialEffectAnimationType EffectType => effectType;
        public string TriggerName => triggerName;
    }
}
