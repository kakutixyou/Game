CavePhase.cs が処理を行うのではなく、「現在どこにいるか」を表します。実際の進行管理は CaveExplorationHandler.cs が担当します。

ファイル	役割
CavePhase.cs	現在の段階を表す番号・名前
CaveExplorationHandler.cs	各Phaseを順番に呼び出す進行役
ScienceQuizPhase.cs など	各段階の具体的な処理
CaveEventState.cs	選択キャラ、バフ、連勝数などを保持
CaveEventInspector.cs	次へ進める条件を確認
EventSetTrigger.cs	ボタンとHandlerのメソッドを接続