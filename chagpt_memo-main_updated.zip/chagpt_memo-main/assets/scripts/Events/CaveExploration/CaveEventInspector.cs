using System.Text;
using UnityEngine;

/// <summary>
/// CaveEventStateを読み、各Phaseを実行できるか判定する門番。
/// UI表示・問題判定・バフ効果・戦闘計算は担当しない。
/// </summary>
public sealed class CaveEventInspector : MonoBehaviour
{
    [SerializeField] private CaveEventConfig config;
    [SerializeField] private bool logRejectedPhase = true;

    public CaveEventConfig Config => config;

    public void Configure(CaveEventConfig value)
    {
        config = value;
    }

    public bool CanStartExploration(CaveEventState state, out string reason)
    {
        if (state == null)
            return Reject("CaveEventStateがありません。", out reason);

        if (config != null && !config.IsValid(out string configError))
            return Reject($"CaveEventConfigが不正です。\n{configError}", out reason);

        if (state.IsRunActive && !state.IsRunFinished)
            return Reject("すでに洞窟探索が進行中です。", out reason);

        reason = string.Empty;
        return true;
    }

    public bool CanExecutePhase(
        CavePhase phase,
        CaveEventState state,
        out string reason)
    {
        if (state == null)
            return Reject("CaveEventStateがありません。", out reason);

        if (phase == CavePhase.None || phase == CavePhase.Entry)
        {
            reason = string.Empty;
            return true;
        }

        if (!state.IsRunActive || state.IsRunFinished)
            return Reject("有効な洞窟探索がありません。", out reason);

        switch (phase)
        {
            case CavePhase.ScienceQuiz:
                return Allow(out reason);

            case CavePhase.ScienceBuff:
                return Require(
                    state.ScienceCompleted,
                    "理科問題が完了していません。",
                    out reason);

            case CavePhase.MathQuiz:
                if (!state.ScienceCompleted)
                    return Reject("理科問題が完了していません。", out reason);
                if (RequiresScienceBuff() && state.ScienceBuffs.Count == 0)
                    return Reject("理科バフが確定していません。", out reason);
                return Allow(out reason);

            case CavePhase.MathBuff:
                return Require(
                    state.MathCompleted,
                    "数学問題が完了していません。",
                    out reason);

            case CavePhase.JapaneseHistoryQuiz:
                if (!state.ScienceCompleted || !state.MathCompleted)
                    return Reject("理科・数学問題が完了していません。", out reason);
                if (RequiresMathBuff() && state.MathBuffs.Count == 0)
                    return Reject("数学バフが確定していません。", out reason);
                return Allow(out reason);

            case CavePhase.HistoryBuff:
                // 日本史問題の専用完了値は、現在はバフ確定時にHistoryCompletedへ反映する。
                return Allow(out reason);

            case CavePhase.CharacterSelect:
                if (!state.ScienceCompleted || !state.MathCompleted || !state.HistoryCompleted)
                    return Reject("3教科の学習フェーズが完了していません。", out reason);
                if (RequiresHistoryBuff() && !state.HasHistoryBuff())
                    return Reject("日本史バフが確定していません。", out reason);
                return Allow(out reason);

            case CavePhase.Battle:
                return CanStartBattle(state, out reason);

            case CavePhase.Reward:
            case CavePhase.Result:
            case CavePhase.Finished:
                return Allow(out reason);

            default:
                return Reject($"未対応のPhaseです: {phase}", out reason);
        }
    }

    public bool CanStartBattle(CaveEventState state, out string reason)
    {
        if (state == null)
            return Reject("CaveEventStateがありません。", out reason);
        if (!state.HasCompletedLearningPhase())
            return Reject("3教科の学習フェーズが完了していません。", out reason);
        if (!state.HasCharacter())
            return Reject("キャラクターが選択されていません。", out reason);
        if (RequiresScienceBuff() && state.ScienceBuffs.Count == 0)
            return Reject("理科バフがありません。", out reason);
        if (RequiresMathBuff() && state.MathBuffs.Count == 0)
            return Reject("数学バフがありません。", out reason);
        if (RequiresHistoryBuff() && !state.HasHistoryBuff())
            return Reject("日本史バフがありません。", out reason);

        reason = string.Empty;
        return true;
    }

    /// <summary>
    /// Unity Consoleで現在値を確認するための読み取り専用レポート。
    /// </summary>
    public string BuildStateReport(CavePhase currentPhase, CaveEventState state)
    {
        if (state == null)
            return "[CaveEventInspector] State=null";

        StringBuilder report = new StringBuilder();
        report.AppendLine("[CaveEventInspector]");
        report.AppendLine($"Phase: {currentPhase}");
        report.AppendLine($"Run: Active={state.IsRunActive}, Finished={state.IsRunFinished}");
        report.AppendLine(
            $"Learning: Science={state.ScienceCompleted}, Math={state.MathCompleted}, History={state.HistoryCompleted}");
        report.AppendLine(
            $"Buffs: Science={state.ScienceBuffs.Count}, Math={state.MathBuffs.Count}, History={state.HistoryBuffId}");
        report.AppendLine(
            $"Character: {state.SelectedCharacterId} / {state.SelectedCharacterName}");
        report.AppendLine($"Round={state.CurrentRound}, WinStreak={state.WinStreak}");
        return report.ToString();
    }

    public void PrintStateReport(CavePhase currentPhase, CaveEventState state)
    {
        Debug.Log(BuildStateReport(currentPhase, state));
    }

    private bool RequiresScienceBuff()
    {
        return config == null || config.RequireScienceBuff;
    }

    private bool RequiresMathBuff()
    {
        return config == null || config.RequireMathBuff;
    }

    private bool RequiresHistoryBuff()
    {
        return config == null || config.RequireHistoryBuff;
    }

    private static bool Allow(out string reason)
    {
        reason = string.Empty;
        return true;
    }

    private bool Require(bool condition, string message, out string reason)
    {
        return condition ? Allow(out reason) : Reject(message, out reason);
    }

    private bool Reject(string message, out string reason)
    {
        reason = message;

        if (logRejectedPhase && (config == null || config.EnableDebugLog))
            Debug.LogWarning($"[CaveEventInspector] {message}");

        return false;
    }
}
