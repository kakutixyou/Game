using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 洞窟探索全体で変更可能な数値・進行条件をまとめる設定ファイル。
/// Projectビューから Create > Game > Cave Exploration Config で作成する。
/// </summary>
[CreateAssetMenu(
    fileName = "CaveEventConfig",
    menuName = "Game/Cave Exploration Config",
    order = 100)]
public sealed class CaveEventConfig : ScriptableObject
{
    [Header("Identity")]
    [SerializeField] private string eventId = "cave_exploration";
    [SerializeField] private string displayName = "洞窟探索";

    [Header("Startup")]
    [SerializeField] private bool autoEnterOnStart = true;
    [Min(0)]
    [SerializeField] private int staminaCostPerRun = 1;

    [Header("Progress")]
    [Min(1)]
    [SerializeField] private int maximumWinStreak = 50;
    [Min(1)]
    [SerializeField] private int streakRewardInterval = 3;
    [Min(1)]
    [SerializeField] private int questionsPerSubject = 1;

    [Header("Required Learning")]
    [SerializeField] private bool requireScienceBuff = true;
    [SerializeField] private bool requireMathBuff = true;
    [SerializeField] private bool requireHistoryBuff = true;

    [Header("Debug")]
    [SerializeField] private bool enableDebugLog = true;

    public string EventId => eventId;
    public string DisplayName => displayName;
    public bool AutoEnterOnStart => autoEnterOnStart;
    public int StaminaCostPerRun => staminaCostPerRun;
    public int MaximumWinStreak => maximumWinStreak;
    public int StreakRewardInterval => streakRewardInterval;
    public int QuestionsPerSubject => questionsPerSubject;
    public bool RequireScienceBuff => requireScienceBuff;
    public bool RequireMathBuff => requireMathBuff;
    public bool RequireHistoryBuff => requireHistoryBuff;
    public bool EnableDebugLog => enableDebugLog;

    /// <summary>
    /// Inspector値の不整合を一覧で返す。空なら設定は有効。
    /// </summary>
    public IReadOnlyList<string> ValidateSettings()
    {
        List<string> errors = new List<string>();

        if (string.IsNullOrWhiteSpace(eventId))
            errors.Add("Event Idが空です。");
        if (string.IsNullOrWhiteSpace(displayName))
            errors.Add("Display Nameが空です。");
        if (staminaCostPerRun < 0)
            errors.Add("Stamina Cost Per Runは0以上にしてください。");
        if (maximumWinStreak < 1)
            errors.Add("Maximum Win Streakは1以上にしてください。");
        if (streakRewardInterval < 1)
            errors.Add("Streak Reward Intervalは1以上にしてください。");
        if (questionsPerSubject < 1)
            errors.Add("Questions Per Subjectは1以上にしてください。");
        if (streakRewardInterval > maximumWinStreak)
            errors.Add("報酬間隔が最大連勝数より大きくなっています。");

        return errors;
    }

    public bool IsValid(out string message)
    {
        IReadOnlyList<string> errors = ValidateSettings();
        message = errors.Count == 0 ? string.Empty : string.Join("\n", errors);
        return errors.Count == 0;
    }

    private void OnValidate()
    {
        staminaCostPerRun = Mathf.Max(0, staminaCostPerRun);
        maximumWinStreak = Mathf.Max(1, maximumWinStreak);
        streakRewardInterval = Mathf.Max(1, streakRewardInterval);
        questionsPerSubject = Mathf.Max(1, questionsPerSubject);
    }
}
