using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 洞窟探索イベント専用の状態管理クラス。
///
/// 役割:
/// ・現在の連勝数
/// ・今回の探索状態
/// ・選択キャラクター
/// ・数学 / 理科 / 日本史バフ
/// ・ショップ持ち込み
/// ・直近の戦闘結果
/// ・イベントログ
/// ・問題評価結果
///
/// 注意:
/// このクラス自身はUIや戦闘処理を行わない。
/// あくまで「現在の洞窟イベントの状態」を保持する。
/// </summary>
[Serializable]
public class CaveEventState
{
    // =========================================================
    // Run
    // =========================================================

    [Header("Run State")]

    [SerializeField]
    private string runId;

    [SerializeField]
    private bool isRunActive;

    [SerializeField]
    private bool isRunFinished;

    [SerializeField]
    private int battleCount;

    [SerializeField]
    private int winStreak;

    [SerializeField]
    private int highestWinStreak;

    [SerializeField]
    private int drawCount;

    [SerializeField]
    private int loseCount;


    // =========================================================
    // Turn / Round
    // =========================================================

    [Header("Turn State")]

    [SerializeField]
    private int currentTurn;

    [SerializeField]
    private int currentRound;

    [SerializeField]
    private int nextBonusBuffStreak = 3;


    // =========================================================
    // Character
    // =========================================================

    [Header("Character")]

    [SerializeField]
    private string selectedCharacterId;

    [SerializeField]
    private string selectedCharacterName;


    // =========================================================
    // Quiz Progress
    // =========================================================

    [Header("Quiz Progress")]

    [SerializeField]
    private bool scienceCompleted;

    [SerializeField]
    private bool mathCompleted;

    [SerializeField]
    private bool historyCompleted;


    // =========================================================
    // Science Evaluation
    // =========================================================

    [Header("Science Evaluation")]

    [SerializeField]
    private float scienceScore;

    [SerializeField]
    private float scienceAnswerTime;

    [SerializeField]
    private float sciencePreviousAnswerTime;

    [SerializeField]
    private float scienceImprovementRate;

    [SerializeField]
    private float scienceNoteQuality;

    [SerializeField]
    private string scienceRewardTier;


    // =========================================================
    // Math Evaluation
    // =========================================================

    [Header("Math Evaluation")]

    [SerializeField]
    private float mathScore;

    [SerializeField]
    private float mathAnswerTime;

    [SerializeField]
    private float mathPreviousAnswerTime;

    [SerializeField]
    private float mathImprovementRate;

    [SerializeField]
    private float mathNoteQuality;

    [SerializeField]
    private string mathRewardTier;


    // =========================================================
    // Buffs
    // =========================================================

    [Header("Buffs")]

    [SerializeField]
    private List<string> scienceBuffs = new List<string>();

    [SerializeField]
    private List<string> mathBuffs = new List<string>();

    [SerializeField]
    private string historyBuffId;

    [SerializeField]
    private string historyBuffName;

    [SerializeField]
    private List<string> bonusBuffs = new List<string>();


    // =========================================================
    // Carry-In / Shop
    // =========================================================

    [Header("Shop / Carry In")]

    [SerializeField]
    private List<string> carriedBuffs = new List<string>();

    [SerializeField]
    private int scienceRerollTickets;

    [SerializeField]
    private int mathRerollTickets;

    [SerializeField]
    private int historyRerollTickets;

    [SerializeField]
    private int universalRerollTickets;

    [SerializeField]
    private bool unlimitedStamina;

    [SerializeField]
    private int staminaConsumed;


    // =========================================================
    // Battle Result
    // =========================================================

    [Header("Last Battle")]

    [SerializeField]
    private BattleResultType lastBattleResult = BattleResultType.None;

    [SerializeField]
    private int lastDamage;

    [SerializeField]
    private int lastReceivedDamage;

    [SerializeField]
    private int lastEnemyMaxHp;

    [SerializeField]
    private int lastEnemyRemainingHp;

    [SerializeField]
    private string lastEnemyId;

    [SerializeField]
    private string lastEnemyName;


    // =========================================================
    // Special Battle Flags
    // =========================================================

    [Header("Special Flags")]

    [SerializeField]
    private bool survivedLethalDamage;

    [SerializeField]
    private bool activatedScienceCombo;

    [SerializeField]
    private bool activatedMathPerfectBuff;

    [SerializeField]
    private bool activatedHistoryGlobalEffect;

    [SerializeField]
    private bool triggeredJokeSkill;

    [SerializeField]
    private bool enemyRevivedByJokeSkill;


    // =========================================================
    // Result / Reward
    // =========================================================

    [Header("Rewards")]

    [SerializeField]
    private int earnedCoins;

    [SerializeField]
    private int earnedEventPoints;

    [SerializeField]
    private List<string> earnedItems = new List<string>();


    // =========================================================
    // Logs
    // =========================================================

    [Header("Logs")]

    [SerializeField]
    private List<string> logs = new List<string>();


    // =========================================================
    // Public Properties
    // =========================================================

    public string RunId => runId;

    public bool IsRunActive => isRunActive;

    public bool IsRunFinished => isRunFinished;

    public int BattleCount => battleCount;

    public int WinStreak => winStreak;

    public int HighestWinStreak => highestWinStreak;

    public int DrawCount => drawCount;

    public int LoseCount => loseCount;

    public int CurrentTurn => currentTurn;

    public int CurrentRound => currentRound;

    public int NextBonusBuffStreak => nextBonusBuffStreak;


    public string SelectedCharacterId => selectedCharacterId;

    public string SelectedCharacterName => selectedCharacterName;


    public bool ScienceCompleted => scienceCompleted;

    public bool MathCompleted => mathCompleted;

    public bool HistoryCompleted => historyCompleted;


    public float ScienceScore => scienceScore;

    public float ScienceAnswerTime => scienceAnswerTime;

    public float SciencePreviousAnswerTime => sciencePreviousAnswerTime;

    public float ScienceImprovementRate => scienceImprovementRate;

    public float ScienceNoteQuality => scienceNoteQuality;

    public string ScienceRewardTier => scienceRewardTier;


    public float MathScore => mathScore;

    public float MathAnswerTime => mathAnswerTime;

    public float MathPreviousAnswerTime => mathPreviousAnswerTime;

    public float MathImprovementRate => mathImprovementRate;

    public float MathNoteQuality => mathNoteQuality;

    public string MathRewardTier => mathRewardTier;


    public IReadOnlyList<string> ScienceBuffs => scienceBuffs;

    public IReadOnlyList<string> MathBuffs => mathBuffs;

    public string HistoryBuffId => historyBuffId;

    public string HistoryBuffName => historyBuffName;

    public IReadOnlyList<string> BonusBuffs => bonusBuffs;


    public IReadOnlyList<string> CarriedBuffs => carriedBuffs;

    public int ScienceRerollTickets => scienceRerollTickets;

    public int MathRerollTickets => mathRerollTickets;

    public int HistoryRerollTickets => historyRerollTickets;

    public int UniversalRerollTickets => universalRerollTickets;

    public bool UnlimitedStamina => unlimitedStamina;

    public int StaminaConsumed => staminaConsumed;


    public BattleResultType LastBattleResult => lastBattleResult;

    public int LastDamage => lastDamage;

    public int LastReceivedDamage => lastReceivedDamage;

    public int LastEnemyMaxHp => lastEnemyMaxHp;

    public int LastEnemyRemainingHp => lastEnemyRemainingHp;

    public string LastEnemyId => lastEnemyId;

    public string LastEnemyName => lastEnemyName;


    public bool SurvivedLethalDamage => survivedLethalDamage;

    public bool ActivatedScienceCombo => activatedScienceCombo;

    public bool ActivatedMathPerfectBuff => activatedMathPerfectBuff;

    public bool ActivatedHistoryGlobalEffect => activatedHistoryGlobalEffect;

    public bool TriggeredJokeSkill => triggeredJokeSkill;

    public bool EnemyRevivedByJokeSkill => enemyRevivedByJokeSkill;


    public int EarnedCoins => earnedCoins;

    public int EarnedEventPoints => earnedEventPoints;

    public IReadOnlyList<string> EarnedItems => earnedItems;

    public IReadOnlyList<string> Logs => logs;


    // =========================================================
    // Run Start / End
    // =========================================================

    public void StartNewRun()
    {
        runId = Guid.NewGuid().ToString();

        isRunActive = true;
        isRunFinished = false;

        battleCount = 0;

        winStreak = 0;

        drawCount = 0;
        loseCount = 0;

        currentTurn = 0;
        currentRound = 1;

        nextBonusBuffStreak = 3;

        ClearCharacter();

        ResetQuizProgress();

        ClearBattleBuffs();

        ResetLastBattle();

        ResetSpecialFlags();

        ResetRewards();

        ClearLogs();

        AddLog("洞窟探索を開始しました。");
    }


    public void FinishRun()
    {
        isRunActive = false;
        isRunFinished = true;

        AddLog(
            $"洞窟探索終了。最終連勝数: {winStreak}"
        );
    }


    // =========================================================
    // Character
    // =========================================================

    public void SetCharacter(
        string characterId,
        string characterName
    )
    {
        selectedCharacterId =
            characterId ?? string.Empty;

        selectedCharacterName =
            characterName ?? string.Empty;

        AddLog(
            $"キャラクター選択: {selectedCharacterName}"
        );
    }


    public void ClearCharacter()
    {
        selectedCharacterId = string.Empty;
        selectedCharacterName = string.Empty;
    }


    public bool HasCharacter()
    {
        return !string.IsNullOrWhiteSpace(
            selectedCharacterId
        );
    }


    // =========================================================
    // Science
    // =========================================================

    public void SetScienceResult(
        float score,
        float answerTime,
        float previousAnswerTime,
        float noteQuality,
        string rewardTier
    )
    {
        scienceCompleted = true;

        scienceScore =
            Mathf.Max(0f, score);

        scienceAnswerTime =
            Mathf.Max(0f, answerTime);

        sciencePreviousAnswerTime =
            Mathf.Max(0f, previousAnswerTime);

        scienceNoteQuality =
            Mathf.Clamp(noteQuality, 0f, 100f);

        scienceRewardTier =
            rewardTier ?? string.Empty;

        scienceImprovementRate =
            CalculateImprovementRate(
                scienceAnswerTime,
                sciencePreviousAnswerTime
            );
    }


    public void AddScienceBuff(
        string buffId
    )
    {
        if (string.IsNullOrWhiteSpace(buffId))
        {
            return;
        }

        scienceBuffs.Add(buffId);

        AddLog(
            $"理科バフ獲得: {buffId}"
        );
    }


    public bool HasScienceBuff(
        string buffId
    )
    {
        return scienceBuffs.Contains(buffId);
    }


    // =========================================================
    // Math
    // =========================================================

    public void SetMathResult(
        float score,
        float answerTime,
        float previousAnswerTime,
        float noteQuality,
        string rewardTier
    )
    {
        mathCompleted = true;

        mathScore =
            Mathf.Max(0f, score);

        mathAnswerTime =
            Mathf.Max(0f, answerTime);

        mathPreviousAnswerTime =
            Mathf.Max(0f, previousAnswerTime);

        mathNoteQuality =
            Mathf.Clamp(noteQuality, 0f, 100f);

        mathRewardTier =
            rewardTier ?? string.Empty;

        mathImprovementRate =
            CalculateImprovementRate(
                mathAnswerTime,
                mathPreviousAnswerTime
            );
    }


    public void AddMathBuff(
        string buffId
    )
    {
        if (string.IsNullOrWhiteSpace(buffId))
        {
            return;
        }

        mathBuffs.Add(buffId);

        AddLog(
            $"数学バフ獲得: {buffId}"
        );
    }


    public bool HasMathBuff(
        string buffId
    )
    {
        return mathBuffs.Contains(buffId);
    }


    // =========================================================
    // History
    // =========================================================

    /// <summary>
    /// 日本史バフは原則1個だけ保持。
    /// 新しい日本史バフを取った場合は上書きする。
    /// </summary>
    public void SetHistoryBuff(
        string buffId,
        string buffName
    )
    {
        if (!string.IsNullOrWhiteSpace(
            historyBuffId
        ))
        {
            AddLog(
                $"日本史バフ消失: {historyBuffName}"
            );
        }

        historyBuffId =
            buffId ?? string.Empty;

        historyBuffName =
            buffName ?? string.Empty;

        historyCompleted = true;

        AddLog(
            $"日本史バフ獲得: {historyBuffName}"
        );
    }


    public void ClearHistoryBuff()
    {
        if (!string.IsNullOrWhiteSpace(
            historyBuffId
        ))
        {
            AddLog(
                $"日本史バフ消失: {historyBuffName}"
            );
        }

        historyBuffId = string.Empty;
        historyBuffName = string.Empty;
    }


    public bool HasHistoryBuff()
    {
        return !string.IsNullOrWhiteSpace(
            historyBuffId
        );
    }


    // =========================================================
    // Bonus Buff
    // =========================================================

    public void AddBonusBuff(
        string buffId
    )
    {
        if (string.IsNullOrWhiteSpace(buffId))
        {
            return;
        }

        bonusBuffs.Add(buffId);

        AddLog(
            $"連勝ボーナスバフ獲得: {buffId}"
        );
    }


    public bool ShouldGrantStreakBonus()
    {
        return winStreak >= nextBonusBuffStreak;
    }


    public void MarkStreakBonusGranted()
    {
        while (nextBonusBuffStreak <= winStreak)
        {
            nextBonusBuffStreak += 3;
        }
    }


    // =========================================================
    // Carry-In Buff
    // =========================================================

    public void AddCarriedBuff(
        string buffId
    )
    {
        if (string.IsNullOrWhiteSpace(buffId))
        {
            return;
        }

        carriedBuffs.Add(buffId);

        AddLog(
            $"持ち込みバフ: {buffId}"
        );
    }


    public void RemoveCarriedBuff(
        string buffId
    )
    {
        carriedBuffs.Remove(buffId);
    }


    public void ClearCarriedBuffs()
    {
        carriedBuffs.Clear();
    }


    // =========================================================
    // Reroll Tickets
    // =========================================================

    public void AddScienceRerollTickets(
        int amount
    )
    {
        scienceRerollTickets =
            Mathf.Max(
                0,
                scienceRerollTickets + amount
            );
    }


    public bool ConsumeScienceRerollTicket()
    {
        if (scienceRerollTickets > 0)
        {
            scienceRerollTickets--;
            return true;
        }

        return ConsumeUniversalRerollTicket();
    }


    public void AddMathRerollTickets(
        int amount
    )
    {
        mathRerollTickets =
            Mathf.Max(
                0,
                mathRerollTickets + amount
            );
    }


    public bool ConsumeMathRerollTicket()
    {
        if (mathRerollTickets > 0)
        {
            mathRerollTickets--;
            return true;
        }

        return ConsumeUniversalRerollTicket();
    }


    public void AddHistoryRerollTickets(
        int amount
    )
    {
        historyRerollTickets =
            Mathf.Max(
                0,
                historyRerollTickets + amount
            );
    }


    public bool ConsumeHistoryRerollTicket()
    {
        if (historyRerollTickets > 0)
        {
            historyRerollTickets--;
            return true;
        }

        return ConsumeUniversalRerollTicket();
    }


    public void AddUniversalRerollTickets(
        int amount
    )
    {
        universalRerollTickets =
            Mathf.Max(
                0,
                universalRerollTickets + amount
            );
    }


    public bool ConsumeUniversalRerollTicket()
    {
        if (universalRerollTickets <= 0)
        {
            return false;
        }

        universalRerollTickets--;

        return true;
    }


    // =========================================================
    // Stamina
    // =========================================================

    public void SetUnlimitedStamina(
        bool value
    )
    {
        unlimitedStamina = value;
    }


    public bool ConsumeStamina(
        int amount = 1
    )
    {
        if (amount <= 0)
        {
            return true;
        }

        if (unlimitedStamina)
        {
            return true;
        }

        staminaConsumed += amount;

        return true;
    }


    // =========================================================
    // Battle Start
    // =========================================================

    public void BeginBattle(
        string enemyId,
        string enemyName,
        int enemyMaxHp
    )
    {
        battleCount++;

        currentTurn = 1;

        lastEnemyId =
            enemyId ?? string.Empty;

        lastEnemyName =
            enemyName ?? string.Empty;

        lastEnemyMaxHp =
            Mathf.Max(1, enemyMaxHp);

        lastEnemyRemainingHp =
            lastEnemyMaxHp;

        ResetSpecialFlags();

        AddLog(
            $"戦闘開始: {lastEnemyName} HP {lastEnemyMaxHp}"
        );
    }


    public void SetCurrentTurn(
        int turn
    )
    {
        currentTurn =
            Mathf.Max(1, turn);
    }


    public void NextTurn()
    {
        currentTurn++;
    }


    // =========================================================
    // Battle End
    // =========================================================

    public void ApplyBattleResult(
        BattleResultType resultType,
        int dealtDamage,
        int receivedDamage,
        int enemyRemainingHp
    )
    {
        lastBattleResult =
            resultType;

        lastDamage =
            Mathf.Max(0, dealtDamage);

        lastReceivedDamage =
            Mathf.Max(0, receivedDamage);

        lastEnemyRemainingHp =
            Mathf.Max(0, enemyRemainingHp);


        switch (resultType)
        {
            case BattleResultType.Win:

                winStreak++;

                if (winStreak > highestWinStreak)
                {
                    highestWinStreak =
                        winStreak;
                }

                AddLog(
                    $"勝利。現在 {winStreak} 連勝。"
                );

                break;


            case BattleResultType.Draw:

                drawCount++;

                // 引き分けは連勝を途切れさせない。
                AddLog(
                    $"引き分け。連勝は {winStreak} のまま継続。"
                );

                break;


            case BattleResultType.Lose:

                loseCount++;

                AddLog(
                    $"敗北。{winStreak} 連勝で終了。"
                );

                winStreak = 0;

                isRunFinished = true;

                break;


            default:

                break;
        }
    }


    // =========================================================
    // Special Battle Events
    // =========================================================

    public void MarkLethalSurvival()
    {
        survivedLethalDamage = true;

        AddLog(
            "致死ダメージをHP1で耐えました。"
        );
    }


    public void MarkScienceCombo()
    {
        activatedScienceCombo = true;

        AddLog(
            "理科コンボが発動しました。"
        );
    }


    public void MarkMathPerfectBuff()
    {
        activatedMathPerfectBuff = true;

        AddLog(
            "数学の上位バフが発動しました。"
        );
    }


    public void MarkHistoryGlobalEffect()
    {
        activatedHistoryGlobalEffect = true;

        AddLog(
            $"日本史バフ発動: {historyBuffName}"
        );
    }


    public void MarkJokeSkill(
        bool enemyRevived
    )
    {
        triggeredJokeSkill = true;

        enemyRevivedByJokeSkill =
            enemyRevived;

        if (enemyRevived)
        {
            AddLog(
                "おふざけ技により敵が復活しました。"
            );
        }
        else
        {
            AddLog(
                "おふざけ技が発動しました。"
            );
        }
    }


    // =========================================================
    // Rewards
    // =========================================================

    public void AddCoins(
        int amount
    )
    {
        earnedCoins =
            Mathf.Max(
                0,
                earnedCoins + amount
            );
    }


    public void AddEventPoints(
        int amount
    )
    {
        earnedEventPoints =
            Mathf.Max(
                0,
                earnedEventPoints + amount
            );
    }


    public void AddRewardItem(
        string itemId
    )
    {
        if (string.IsNullOrWhiteSpace(itemId))
        {
            return;
        }

        earnedItems.Add(itemId);

        AddLog(
            $"報酬獲得: {itemId}"
        );
    }


    // =========================================================
    // Validation
    // =========================================================

    public bool CanStartBattle()
    {
        if (!isRunActive)
        {
            return false;
        }

        if (!HasCharacter())
        {
            return false;
        }

        return true;
    }


    public bool HasCompletedLearningPhase()
    {
        return
            scienceCompleted &&
            mathCompleted &&
            historyCompleted;
    }


    public bool HasAnyBuff()
    {
        return
            scienceBuffs.Count > 0 ||
            mathBuffs.Count > 0 ||
            HasHistoryBuff() ||
            bonusBuffs.Count > 0 ||
            carriedBuffs.Count > 0;
    }


    // =========================================================
    // Reset
    // =========================================================

    /// <summary>
    /// 次の問題セットへ移る際に使う。
    /// 連勝数やバフは維持。
    /// </summary>
    public void ResetQuizProgress()
    {
        scienceCompleted = false;
        mathCompleted = false;
        historyCompleted = false;

        scienceScore = 0f;
        scienceAnswerTime = 0f;
        sciencePreviousAnswerTime = 0f;
        scienceImprovementRate = 0f;
        scienceNoteQuality = 0f;
        scienceRewardTier = string.Empty;

        mathScore = 0f;
        mathAnswerTime = 0f;
        mathPreviousAnswerTime = 0f;
        mathImprovementRate = 0f;
        mathNoteQuality = 0f;
        mathRewardTier = string.Empty;
    }


    public void ResetLastBattle()
    {
        lastBattleResult =
            BattleResultType.None;

        lastDamage = 0;
        lastReceivedDamage = 0;

        lastEnemyMaxHp = 0;
        lastEnemyRemainingHp = 0;

        lastEnemyId = string.Empty;
        lastEnemyName = string.Empty;

        currentTurn = 0;
    }


    public void ResetSpecialFlags()
    {
        survivedLethalDamage = false;

        activatedScienceCombo = false;

        activatedMathPerfectBuff = false;

        activatedHistoryGlobalEffect = false;

        triggeredJokeSkill = false;

        enemyRevivedByJokeSkill = false;
    }


    public void ResetRewards()
    {
        earnedCoins = 0;
        earnedEventPoints = 0;

        earnedItems.Clear();
    }


    public void ClearBattleBuffs()
    {
        scienceBuffs.Clear();
        mathBuffs.Clear();

        historyBuffId = string.Empty;
        historyBuffName = string.Empty;

        bonusBuffs.Clear();
    }


    // =========================================================
    // Round
    // =========================================================

    public void NextRound()
    {
        currentRound++;

        ResetQuizProgress();
        ResetLastBattle();
        ResetSpecialFlags();

        AddLog(
            $"第 {currentRound} ラウンドへ移行。"
        );
    }


    // =========================================================
    // Logs
    // =========================================================

    public void AddLog(
        string message
    )
    {
        if (string.IsNullOrWhiteSpace(message))
        {
            return;
        }

        string log =
            $"[{DateTime.Now:HH:mm:ss}] {message}";

        logs.Add(log);

        Debug.Log(
            $"[CaveEventState] {message}"
        );
    }


    public void ClearLogs()
    {
        logs.Clear();
    }


    public string GetLogText()
    {
        return string.Join(
            "\n",
            logs
        );
    }


    // =========================================================
    // Utility
    // =========================================================

    private float CalculateImprovementRate(
        float currentTime,
        float previousTime
    )
    {
        if (previousTime <= 0f)
        {
            return 0f;
        }

        if (currentTime <= 0f)
        {
            return 0f;
        }

        float improvement =
            (
                previousTime - currentTime
            )
            / previousTime
            * 100f;

        return improvement;
    }
}


/// <summary>
/// 戦闘結果。
/// 引き分けは連勝を維持する。
/// </summary>
public enum BattleResultType
{
    None = 0,

    Win = 1,

    Draw = 2,

    Lose = 3
}
