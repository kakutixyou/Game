public sealed class CharacterSelectionResult
{
    public string CharacterId { get; }
    public string CharacterName { get; }

    public CharacterSelectionResult(string characterId, string characterName)
    {
        CharacterId = characterId ?? string.Empty;
        CharacterName = characterName ?? string.Empty;
    }
}
