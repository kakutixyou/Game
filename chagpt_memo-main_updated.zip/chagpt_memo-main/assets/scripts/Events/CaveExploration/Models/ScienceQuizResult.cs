public sealed class ScienceQuizResult : QuizAnswerResult
{
    public ScienceQuizResult(
        string questionId,
        bool isCorrect,
        int selectedChoiceIndex,
        int correctChoiceIndex,
        float answerTime,
        string explanation,
        string rewardBuffId,
        string rewardBuffName)
        : base(
            questionId,
            QuizSubject.Science,
            isCorrect,
            selectedChoiceIndex,
            correctChoiceIndex,
            answerTime,
            explanation,
            rewardBuffId,
            rewardBuffName)
    {
    }
}
