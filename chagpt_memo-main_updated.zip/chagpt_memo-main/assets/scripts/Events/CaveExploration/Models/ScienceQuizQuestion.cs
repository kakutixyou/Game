using System;
using System.Collections.Generic;

[Serializable]
public sealed class ScienceQuizQuestion : QuizQuestionBase
{
    public static ScienceQuizQuestion FromCsvRow(QuizCsvRow row)
    {
        ScienceQuizQuestion question = new ScienceQuizQuestion();
        question.PopulateFromCsv(row, QuizSubject.Science);
        return question;
    }

    public static List<ScienceQuizQuestion> ReadCsv(string csvText)
    {
        return QuizQuestionCsvLoader.Read(csvText, FromCsvRow);
    }

    public static ScienceQuizQuestion CreateBoilingPointDemo()
    {
        ScienceQuizQuestion question = new ScienceQuizQuestion();
        question.PopulateDemo(
            "science.demo.boiling_point",
            QuizSubject.Science,
            "状態変化",
            "水が標準的な気圧で沸騰する温度は？",
            new[] { "0℃", "50℃", "100℃" },
            2,
            "水が液体から気体へ変化するときの温度を思い出そう。",
            "標準的な気圧では、水は100℃で沸騰します。気圧が変わると沸点も変化します。",
            "science.heat_mastery",
            "加熱反応・強",
            "science.research_spirit",
            "観察の心得");
        return question;
    }
}
