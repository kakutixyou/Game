using System;
using System.Collections.Generic;

[Serializable]
public sealed class JapaneseHistoryQuizQuestion : QuizQuestionBase
{
    public string Period => Unit;

    public static JapaneseHistoryQuizQuestion FromCsvRow(QuizCsvRow row)
    {
        JapaneseHistoryQuizQuestion question = new JapaneseHistoryQuizQuestion();
        question.PopulateFromCsv(row, QuizSubject.JapaneseHistory);
        return question;
    }

    public static List<JapaneseHistoryQuizQuestion> ReadCsv(string csvText)
    {
        return QuizQuestionCsvLoader.Read(csvText, FromCsvRow);
    }

    public static JapaneseHistoryQuizQuestion CreateKamakuraDemo()
    {
        JapaneseHistoryQuizQuestion question = new JapaneseHistoryQuizQuestion();
        question.PopulateDemo(
            "history.demo.kamakura",
            QuizSubject.JapaneseHistory,
            "鎌倉時代",
            "鎌倉幕府を開いた人物は？",
            new[] { "源頼朝", "織田信長", "徳川家康", "聖徳太子" },
            0,
            "平安時代の次に武士の政権を築いた人物です。",
            "源頼朝は鎌倉に武家政権を築き、征夷大将軍に任命されました。",
            "history.first_skill_guard",
            "武家の守り",
            "history.retry_memory",
            "年表の心得");
        return question;
    }
}
