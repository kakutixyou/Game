using System;
using System.Collections.Generic;
using System.Globalization;

/// <summary>
/// CSVの1行。列名から値を安全に取得する。
/// </summary>
public sealed class QuizCsvRow
{
    private readonly IReadOnlyDictionary<string, string> values;

    public int LineNumber { get; }

    public QuizCsvRow(int lineNumber, IReadOnlyDictionary<string, string> values)
    {
        LineNumber = lineNumber;
        this.values = values ?? throw new ArgumentNullException(nameof(values));
    }

    public string GetRequired(string column)
    {
        string value = GetOptional(column);
        if (string.IsNullOrWhiteSpace(value))
        {
            throw new FormatException(
                $"CSV {LineNumber}行目: 必須列'{column}'が空です。");
        }

        return value;
    }

    public string GetOptional(string column, string defaultValue = "")
    {
        if (values.TryGetValue(column, out string value))
        {
            return !string.IsNullOrWhiteSpace(value) ? value.Trim() : defaultValue;
        }

        return defaultValue;
    }

    public int GetInt(string column, int defaultValue = 0)
    {
        string raw = GetOptional(column);
        if (raw.Length == 0)
        {
            return defaultValue;
        }

        if (int.TryParse(raw, NumberStyles.Integer, CultureInfo.InvariantCulture, out int value))
        {
            return value;
        }

        throw new FormatException(
            $"CSV {LineNumber}行目: 列'{column}'の'{raw}'は整数ではありません。");
    }
}
