public enum QuizDifficulty
{
    Unknown = 0,
    Easy = 1,
    Normal = 2,
    Hard = 3
}
