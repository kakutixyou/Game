using System;
using UnityEngine;

[Serializable]
public sealed class CharacterSelectionOption
{
    [SerializeField] private string characterId;
    [SerializeField] private string characterName;
    [SerializeField, TextArea(1, 3)] private string description;

    public string CharacterId => characterId;
    public string CharacterName => characterName;
    public string Description => description;

    public CharacterSelectionOption(string id, string displayName, string detail)
    {
        characterId = id ?? string.Empty;
        characterName = displayName ?? string.Empty;
        description = detail ?? string.Empty;
    }

    public bool IsValid()
    {
        return !string.IsNullOrWhiteSpace(characterId)
            && !string.IsNullOrWhiteSpace(characterName);
    }
}
