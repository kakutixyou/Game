/// <summary>
/// 3教科で共通する回答結果。
/// </summary>
public abstract class QuizAnswerResult
{
    public string QuestionId { get; }
    public QuizSubject Subject { get; }
    public bool IsCorrect { get; }
    public int SelectedChoiceIndex { get; }
    public int CorrectChoiceIndex { get; }
    public float Score { get; }
    public float AnswerTime { get; }
    public string Explanation { get; }
    public string RewardBuffId { get; }
    public string RewardBuffName { get; }
    public string RewardTier { get; }

    protected QuizAnswerResult(
        string questionId,
        QuizSubject subject,
        bool isCorrect,
        int selectedChoiceIndex,
        int correctChoiceIndex,
        float answerTime,
        string explanation,
        string rewardBuffId,
        string rewardBuffName)
    {
        QuestionId = questionId ?? string.Empty;
        Subject = subject;
        IsCorrect = isCorrect;
        SelectedChoiceIndex = selectedChoiceIndex;
        CorrectChoiceIndex = correctChoiceIndex;
        Score = isCorrect ? 100f : 0f;
        AnswerTime = answerTime < 0f ? 0f : answerTime;
        Explanation = explanation ?? string.Empty;
        RewardBuffId = rewardBuffId ?? string.Empty;
        RewardBuffName = rewardBuffName ?? string.Empty;
        RewardTier = isCorrect ? "correct" : "learning";
    }
}
