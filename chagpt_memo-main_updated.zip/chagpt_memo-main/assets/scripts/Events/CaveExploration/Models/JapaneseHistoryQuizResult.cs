public sealed class JapaneseHistoryQuizResult : QuizAnswerResult
{
    public JapaneseHistoryQuizResult(
        string questionId,
        bool isCorrect,
        int selectedChoiceIndex,
        int correctChoiceIndex,
        float answerTime,
        string explanation,
        string rewardBuffId,
        string rewardBuffName)
        : base(
            questionId,
            QuizSubject.JapaneseHistory,
            isCorrect,
            selectedChoiceIndex,
            correctChoiceIndex,
            answerTime,
            explanation,
            rewardBuffId,
            rewardBuffName)
    {
    }
}
