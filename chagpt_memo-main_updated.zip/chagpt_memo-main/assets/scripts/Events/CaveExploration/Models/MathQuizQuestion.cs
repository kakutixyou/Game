using System;
using System.Collections.Generic;

[Serializable]
public sealed class MathQuizQuestion : QuizQuestionBase
{
    public string FormulaHint => Hint;

    public static MathQuizQuestion FromCsvRow(QuizCsvRow row)
    {
        MathQuizQuestion question = new MathQuizQuestion();
        question.PopulateFromCsv(row, QuizSubject.Math);
        return question;
    }

    public static List<MathQuizQuestion> ReadCsv(string csvText)
    {
        return QuizQuestionCsvLoader.Read(csvText, FromCsvRow);
    }

    public static MathQuizQuestion CreateLinearEquationDemo()
    {
        MathQuizQuestion question = new MathQuizQuestion();
        question.PopulateDemo(
            "math.demo.linear_equation",
            QuizSubject.Math,
            "一次方程式",
            "2x + 3 = 11 のとき、xはいくつ？",
            new[] { "2", "4", "7", "8" },
            1,
            "両辺から3を引いてから、2で割ろう。",
            "2x + 3 = 11 → 2x = 8 → x = 4です。",
            "math.step_focus",
            "途中式集中",
            "math.retry_focus",
            "見直しの心得");
        return question;
    }
}
