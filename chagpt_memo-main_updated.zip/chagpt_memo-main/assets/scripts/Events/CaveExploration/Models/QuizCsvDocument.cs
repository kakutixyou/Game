using System;
using System.Collections.Generic;
using System.Text;

/// <summary>
/// 問題CSVを列名付きの行へ変換する小さなCSVリーダー。
/// ダブルクォート、カンマ、セル内改行、UTF-8 BOMに対応する。
/// </summary>
public static class QuizCsvDocument
{
    public static List<QuizCsvRow> Parse(string csvText)
    {
        if (string.IsNullOrWhiteSpace(csvText))
        {
            throw new FormatException("問題CSVが空です。");
        }

        List<List<string>> records = ParseRecords(csvText);
        if (records.Count < 2)
        {
            throw new FormatException("問題CSVにはヘッダーと1件以上のデータが必要です。");
        }

        List<string> headers = records[0];
        if (headers.Count > 0)
        {
            headers[0] = headers[0].TrimStart('\uFEFF');
        }

        HashSet<string> uniqueHeaders = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        for (int i = 0; i < headers.Count; i++)
        {
            headers[i] = headers[i].Trim();
            if (headers[i].Length == 0 || !uniqueHeaders.Add(headers[i]))
            {
                throw new FormatException($"CSVヘッダーの{i + 1}列目が空、または重複しています。");
            }
        }

        List<QuizCsvRow> rows = new List<QuizCsvRow>();
        for (int recordIndex = 1; recordIndex < records.Count; recordIndex++)
        {
            List<string> record = records[recordIndex];
            if (IsBlankRecord(record))
            {
                continue;
            }

            if (record.Count > headers.Count)
            {
                throw new FormatException(
                    $"CSV {recordIndex + 1}行目: ヘッダーより列数が多いです。");
            }

            Dictionary<string, string> values =
                new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

            for (int columnIndex = 0; columnIndex < headers.Count; columnIndex++)
            {
                string value = columnIndex < record.Count ? record[columnIndex] : string.Empty;
                values.Add(headers[columnIndex], value);
            }

            rows.Add(new QuizCsvRow(recordIndex + 1, values));
        }

        return rows;
    }

    private static List<List<string>> ParseRecords(string text)
    {
        List<List<string>> records = new List<List<string>>();
        List<string> record = new List<string>();
        StringBuilder cell = new StringBuilder();
        bool inQuotes = false;

        for (int i = 0; i < text.Length; i++)
        {
            char current = text[i];

            if (current == '"')
            {
                if (inQuotes && i + 1 < text.Length && text[i + 1] == '"')
                {
                    cell.Append('"');
                    i++;
                }
                else
                {
                    inQuotes = !inQuotes;
                }

                continue;
            }

            if (current == ',' && !inQuotes)
            {
                record.Add(cell.ToString());
                cell.Clear();
                continue;
            }

            if ((current == '\n' || current == '\r') && !inQuotes)
            {
                if (current == '\r' && i + 1 < text.Length && text[i + 1] == '\n')
                {
                    i++;
                }

                record.Add(cell.ToString());
                cell.Clear();
                records.Add(record);
                record = new List<string>();
                continue;
            }

            cell.Append(current);
        }

        if (inQuotes)
        {
            throw new FormatException("CSVのダブルクォートが閉じられていません。");
        }

        if (cell.Length > 0 || record.Count > 0)
        {
            record.Add(cell.ToString());
            records.Add(record);
        }

        return records;
    }

    private static bool IsBlankRecord(List<string> record)
    {
        for (int i = 0; i < record.Count; i++)
        {
            if (!string.IsNullOrWhiteSpace(record[i]))
            {
                return false;
            }
        }

        return true;
    }
}
