public enum QuizSubject
{
    Unknown = 0,
    Science = 1,
    Math = 2,
    JapaneseHistory = 3
}
