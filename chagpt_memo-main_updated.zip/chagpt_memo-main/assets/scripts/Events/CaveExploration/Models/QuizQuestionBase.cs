using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 理科・数学・日本史で共通する問題データ。
/// 正解番号はC#内部では0始まり、CSVでは人が編集しやすい1始まりで扱う。
/// </summary>
[Serializable]
public abstract class QuizQuestionBase
{
    [SerializeField] private string questionId;
    [SerializeField] private QuizSubject subject;
    [SerializeField] private string unit;
    [SerializeField] private QuizDifficulty difficulty;
    [SerializeField, TextArea(2, 5)] private string questionText;
    [SerializeField] private List<string> choices = new List<string>();
    [SerializeField] private int correctChoiceIndex;
    [SerializeField, TextArea(1, 3)] private string hint;
    [SerializeField, TextArea(2, 5)] private string explanation;
    [SerializeField] private string rewardBuffId;
    [SerializeField] private string rewardBuffName;
    [SerializeField] private string retryBuffId;
    [SerializeField] private string retryBuffName;
    [SerializeField] private string rewardTier;
    [SerializeField] private List<string> tags = new List<string>();

    public string QuestionId => questionId;
    public QuizSubject Subject => subject;
    public string Unit => unit;
    public QuizDifficulty Difficulty => difficulty;
    public string QuestionText => questionText;
    public IReadOnlyList<string> Choices => choices;
    public int CorrectChoiceIndex => correctChoiceIndex;
    public string Hint => hint;
    public string Explanation => explanation;
    public string RewardBuffId => rewardBuffId;
    public string RewardBuffName => rewardBuffName;
    public string RetryBuffId => retryBuffId;
    public string RetryBuffName => retryBuffName;
    public string RewardTier => rewardTier;
    public IReadOnlyList<string> Tags => tags;

    public bool IsCorrect(int selectedChoiceIndex)
    {
        return selectedChoiceIndex == correctChoiceIndex;
    }

    public string GetRewardBuffId(bool isCorrect)
    {
        return isCorrect || string.IsNullOrWhiteSpace(retryBuffId)
            ? rewardBuffId
            : retryBuffId;
    }

    public string GetRewardBuffName(bool isCorrect)
    {
        return isCorrect || string.IsNullOrWhiteSpace(retryBuffName)
            ? rewardBuffName
            : retryBuffName;
    }

    public string GetChoice(int index)
    {
        return index >= 0 && index < choices.Count ? choices[index] : string.Empty;
    }

    public bool IsValid()
    {
        return TryValidate(out _);
    }

    public bool TryValidate(out string error)
    {
        if (string.IsNullOrWhiteSpace(questionId))
        {
            error = "question_idが空です。";
            return false;
        }

        if (subject == QuizSubject.Unknown)
        {
            error = $"{questionId}: subjectが不明です。";
            return false;
        }

        if (difficulty == QuizDifficulty.Unknown)
        {
            error = $"{questionId}: difficultyが不明です。";
            return false;
        }

        if (string.IsNullOrWhiteSpace(questionText))
        {
            error = $"{questionId}: question_textが空です。";
            return false;
        }

        if (choices == null || choices.Count < 2)
        {
            error = $"{questionId}: 選択肢が2個未満です。";
            return false;
        }

        if (correctChoiceIndex < 0 || correctChoiceIndex >= choices.Count)
        {
            error = $"{questionId}: correct_choiceが選択肢の範囲外です。";
            return false;
        }

        if (string.IsNullOrWhiteSpace(rewardBuffId))
        {
            error = $"{questionId}: reward_buff_idが空です。";
            return false;
        }

        error = string.Empty;
        return true;
    }

    protected void PopulateFromCsv(QuizCsvRow row, QuizSubject expectedSubject)
    {
        if (row == null)
        {
            throw new ArgumentNullException(nameof(row));
        }

        QuizSubject parsedSubject = ParseSubject(row.GetRequired(QuizCsvSchema.Subject));
        if (parsedSubject != expectedSubject)
        {
            throw new FormatException(
                $"CSV {row.LineNumber}行目: subjectは{expectedSubject}である必要があります。" +
                $" 実際の値: {parsedSubject}");
        }

        questionId = row.GetRequired(QuizCsvSchema.QuestionId);
        subject = parsedSubject;
        unit = row.GetOptional(QuizCsvSchema.Unit);
        difficulty = ParseDifficulty(row.GetOptional(QuizCsvSchema.Difficulty, "easy"));
        questionText = row.GetRequired(QuizCsvSchema.QuestionText);
        choices = ReadChoices(row);
        correctChoiceIndex = ParseCorrectChoice(row.GetRequired(QuizCsvSchema.CorrectChoice));
        hint = row.GetOptional(QuizCsvSchema.Hint);
        explanation = row.GetRequired(QuizCsvSchema.Explanation);
        rewardBuffId = row.GetRequired(QuizCsvSchema.RewardBuffId);
        rewardBuffName = row.GetOptional(QuizCsvSchema.RewardBuffName, rewardBuffId);
        retryBuffId = row.GetOptional(QuizCsvSchema.RetryBuffId, rewardBuffId);
        retryBuffName = row.GetOptional(QuizCsvSchema.RetryBuffName, rewardBuffName);
        rewardTier = row.GetOptional(QuizCsvSchema.RewardTier, "normal");
        tags = ReadTags(row.GetOptional(QuizCsvSchema.Tags));

        if (!TryValidate(out string error))
        {
            throw new FormatException($"CSV {row.LineNumber}行目: {error}");
        }
    }

    protected void PopulateDemo(
        string id,
        QuizSubject quizSubject,
        string quizUnit,
        string text,
        string[] answerChoices,
        int correctIndex,
        string answerHint,
        string answerExplanation,
        string buffId,
        string buffName,
        string learningBuffId,
        string learningBuffName)
    {
        questionId = id;
        subject = quizSubject;
        unit = quizUnit;
        difficulty = QuizDifficulty.Easy;
        questionText = text;
        choices = new List<string>(answerChoices);
        correctChoiceIndex = correctIndex;
        hint = answerHint;
        explanation = answerExplanation;
        rewardBuffId = buffId;
        rewardBuffName = buffName;
        retryBuffId = learningBuffId;
        retryBuffName = learningBuffName;
        rewardTier = "normal";
        tags = new List<string> { "demo" };
    }

    private static List<string> ReadChoices(QuizCsvRow row)
    {
        List<string> result = new List<string>();
        string[] values =
        {
            row.GetOptional(QuizCsvSchema.Choice1),
            row.GetOptional(QuizCsvSchema.Choice2),
            row.GetOptional(QuizCsvSchema.Choice3),
            row.GetOptional(QuizCsvSchema.Choice4)
        };

        bool foundEmpty = false;
        for (int i = 0; i < values.Length; i++)
        {
            if (string.IsNullOrWhiteSpace(values[i]))
            {
                foundEmpty = true;
                continue;
            }

            if (foundEmpty)
            {
                throw new FormatException(
                    $"CSV {row.LineNumber}行目: 選択肢はchoice_1から詰めて入力してください。");
            }

            result.Add(values[i].Trim());
        }

        return result;
    }

    private static int ParseCorrectChoice(string raw)
    {
        string normalized = raw.Trim().ToUpperInvariant();
        switch (normalized)
        {
            case "A": return 0;
            case "B": return 1;
            case "C": return 2;
            case "D": return 3;
        }

        if (int.TryParse(normalized, out int oneBased) && oneBased >= 1 && oneBased <= 4)
        {
            return oneBased - 1;
        }

        throw new FormatException(
            $"correct_choiceの'{raw}'は1～4、またはA～Dで指定してください。");
    }

    private static QuizSubject ParseSubject(string raw)
    {
        switch (Normalize(raw))
        {
            case "science":
            case "rika":
            case "理科":
                return QuizSubject.Science;
            case "math":
            case "mathematics":
            case "数学":
                return QuizSubject.Math;
            case "japanesehistory":
            case "japanese_history":
            case "history":
            case "日本史":
                return QuizSubject.JapaneseHistory;
            default:
                return QuizSubject.Unknown;
        }
    }

    private static QuizDifficulty ParseDifficulty(string raw)
    {
        switch (Normalize(raw))
        {
            case "easy":
            case "1":
            case "簡単":
                return QuizDifficulty.Easy;
            case "normal":
            case "2":
            case "普通":
                return QuizDifficulty.Normal;
            case "hard":
            case "3":
            case "難しい":
                return QuizDifficulty.Hard;
            default:
                return QuizDifficulty.Unknown;
        }
    }

    private static string Normalize(string value)
    {
        return string.IsNullOrWhiteSpace(value)
            ? string.Empty
            : value.Trim().Replace(" ", string.Empty).ToLowerInvariant();
    }

    private static List<string> ReadTags(string raw)
    {
        List<string> result = new List<string>();
        if (string.IsNullOrWhiteSpace(raw))
        {
            return result;
        }

        string[] values = raw.Split('|');
        for (int i = 0; i < values.Length; i++)
        {
            string tag = values[i].Trim();
            if (tag.Length > 0)
            {
                result.Add(tag);
            }
        }

        return result;
    }
}
