using System;
using System.Collections.Generic;

public static class QuizQuestionCsvLoader
{
    public static List<TQuestion> Read<TQuestion>(
        string csvText,
        Func<QuizCsvRow, TQuestion> factory)
        where TQuestion : QuizQuestionBase
    {
        if (factory == null)
        {
            throw new ArgumentNullException(nameof(factory));
        }

        List<QuizCsvRow> rows = QuizCsvDocument.Parse(csvText);
        List<TQuestion> questions = new List<TQuestion>();
        HashSet<string> ids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        for (int i = 0; i < rows.Count; i++)
        {
            TQuestion question = factory(rows[i]);
            if (question == null)
            {
                throw new FormatException($"CSV {rows[i].LineNumber}行目を問題へ変換できませんでした。");
            }

            if (!ids.Add(question.QuestionId))
            {
                throw new FormatException(
                    $"CSV {rows[i].LineNumber}行目: question_id '{question.QuestionId}'が重複しています。");
            }

            questions.Add(question);
        }

        return questions;
    }
}
