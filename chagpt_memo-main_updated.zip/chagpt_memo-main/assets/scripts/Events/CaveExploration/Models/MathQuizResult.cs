public sealed class MathQuizResult : QuizAnswerResult
{
    public MathQuizResult(
        string questionId,
        bool isCorrect,
        int selectedChoiceIndex,
        int correctChoiceIndex,
        float answerTime,
        string explanation,
        string rewardBuffId,
        string rewardBuffName)
        : base(
            questionId,
            QuizSubject.Math,
            isCorrect,
            selectedChoiceIndex,
            correctChoiceIndex,
            answerTime,
            explanation,
            rewardBuffId,
            rewardBuffName)
    {
    }
}
