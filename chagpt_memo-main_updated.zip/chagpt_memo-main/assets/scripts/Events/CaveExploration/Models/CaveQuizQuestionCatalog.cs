using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 3教科のTextAssetを読み、型付き問題リストとして保持する。
/// </summary>
[Serializable]
public sealed class CaveQuizQuestionCatalog
{
    private List<ScienceQuizQuestion> scienceQuestions = new List<ScienceQuizQuestion>();
    private List<MathQuizQuestion> mathQuestions = new List<MathQuizQuestion>();
    private List<JapaneseHistoryQuizQuestion> japaneseHistoryQuestions =
        new List<JapaneseHistoryQuizQuestion>();

    public IReadOnlyList<ScienceQuizQuestion> ScienceQuestions => scienceQuestions;
    public IReadOnlyList<MathQuizQuestion> MathQuestions => mathQuestions;
    public IReadOnlyList<JapaneseHistoryQuizQuestion> JapaneseHistoryQuestions =>
        japaneseHistoryQuestions;

    public void Load(
        TextAsset scienceCsv,
        TextAsset mathCsv,
        TextAsset japaneseHistoryCsv)
    {
        scienceQuestions = ReadRequired(
            scienceCsv,
            "理科",
            ScienceQuizQuestion.ReadCsv);
        mathQuestions = ReadRequired(
            mathCsv,
            "数学",
            MathQuizQuestion.ReadCsv);
        japaneseHistoryQuestions = ReadRequired(
            japaneseHistoryCsv,
            "日本史",
            JapaneseHistoryQuizQuestion.ReadCsv);
    }

    private static List<T> ReadRequired<T>(
        TextAsset asset,
        string displayName,
        Func<string, List<T>> reader)
    {
        if (asset == null)
        {
            throw new InvalidOperationException($"{displayName}問題CSVが設定されていません。");
        }

        List<T> result = reader(asset.text);
        if (result.Count == 0)
        {
            throw new InvalidOperationException($"{displayName}問題CSVに問題がありません。");
        }

        return result;
    }
}
