/// <summary>
/// 3教科で共通使用するCSV列名。
/// CSVとC#の表記揺れを防ぐため、文字列を直接書かずこの定数を使用する。
/// </summary>
public static class QuizCsvSchema
{
    public const string QuestionId = "question_id";
    public const string Subject = "subject";
    public const string Unit = "unit";
    public const string Difficulty = "difficulty";
    public const string QuestionText = "question_text";
    public const string Choice1 = "choice_1";
    public const string Choice2 = "choice_2";
    public const string Choice3 = "choice_3";
    public const string Choice4 = "choice_4";
    public const string CorrectChoice = "correct_choice";
    public const string Hint = "hint";
    public const string Explanation = "explanation";
    public const string RewardBuffId = "reward_buff_id";
    public const string RewardBuffName = "reward_buff_name";
    public const string RetryBuffId = "retry_buff_id";
    public const string RetryBuffName = "retry_buff_name";
    public const string RewardTier = "reward_tier";
    public const string Tags = "tags";
}
