using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

/// <summary>
/// 日本史CSVから問題を選び、表示・回答・解説表示を行う。
/// </summary>
public sealed class JapaneseHistoryQuizController : MonoBehaviour
{
    [Header("Screen")]
    [SerializeField] private GameObject quizScreen;
    [SerializeField] private Text periodText;
    [SerializeField] private Text questionText;
    [SerializeField] private Text hintText;
    [SerializeField] private Text feedbackText;

    [Header("Choices")]
    [SerializeField] private Button[] choiceButtons;
    [SerializeField] private Text[] choiceButtonTexts;

    [Header("Continue")]
    [SerializeField] private Button continueButton;
    [SerializeField] private Text continueButtonText;

    [Header("CSV")]
    [SerializeField] private TextAsset japaneseHistoryQuestionsCsv;
    [SerializeField] private List<JapaneseHistoryQuizQuestion> questions =
        new List<JapaneseHistoryQuizQuestion>();

    private readonly List<UnityAction> choiceListeners = new List<UnityAction>();
    private UnityAction continueListener;
    private JapaneseHistoryQuizQuestion currentQuestion;
    private JapaneseHistoryQuizResult pendingResult;
    private Action<JapaneseHistoryQuizResult> completedCallback;
    private float startedAt;
    private bool answered;
    private bool csvLoaded;

    public void StartQuiz(
        CaveEventState state,
        Action<JapaneseHistoryQuizResult> onCompleted)
    {
        completedCallback = onCompleted;
        pendingResult = null;
        answered = false;
        currentQuestion = SelectQuestion();

        if (currentQuestion == null)
        {
            Debug.LogError("[JapaneseHistoryQuizController] 有効な日本史問題がありません。");
            return;
        }

        SetActive(quizScreen, true);
        BindChoiceButtons();
        BindContinueButton();
        RenderQuestion();
        startedAt = Time.realtimeSinceStartup;
    }

    private JapaneseHistoryQuizQuestion SelectQuestion()
    {
        LoadCsvIfNeeded();
        if (questions == null)
            questions = new List<JapaneseHistoryQuizQuestion>();

        List<JapaneseHistoryQuizQuestion> valid =
            questions.FindAll(item => item != null && item.IsValid());
        return valid.Count > 0
            ? valid[UnityEngine.Random.Range(0, valid.Count)]
            : JapaneseHistoryQuizQuestion.CreateKamakuraDemo();
    }

    private void LoadCsvIfNeeded()
    {
        if (csvLoaded || japaneseHistoryQuestionsCsv == null) return;
        csvLoaded = true;

        try
        {
            questions = JapaneseHistoryQuizQuestion.ReadCsv(japaneseHistoryQuestionsCsv.text);
            Debug.Log(
                $"[JapaneseHistoryQuizController] 日本史問題CSVを{questions.Count}件読み込みました。");
        }
        catch (Exception ex)
        {
            questions = new List<JapaneseHistoryQuizQuestion>();
            Debug.LogError(
                $"[JapaneseHistoryQuizController] 日本史問題CSVの読み込みに失敗しました。\n{ex}");
        }
    }

    private void RenderQuestion()
    {
        if (periodText != null) periodText.text = currentQuestion.Period;
        if (questionText != null) questionText.text = currentQuestion.QuestionText;
        if (hintText != null) hintText.text = $"ヒント: {currentQuestion.Hint}";
        if (feedbackText != null) feedbackText.text = string.Empty;

        if (choiceButtons == null) choiceButtons = Array.Empty<Button>();
        for (int i = 0; i < choiceButtons.Length; i++)
        {
            Button button = choiceButtons[i];
            if (button == null) continue;

            bool hasChoice = i < currentQuestion.Choices.Count;
            button.gameObject.SetActive(hasChoice);
            button.interactable = hasChoice;
            Text label = GetChoiceLabel(i);
            if (hasChoice && label != null) label.text = currentQuestion.GetChoice(i);
        }

        SetActive(continueButton != null ? continueButton.gameObject : null, false);
        if (continueButtonText != null) continueButtonText.text = "日本史バフへ進む";
    }

    private void SelectAnswer(int index)
    {
        if (answered || currentQuestion == null) return;
        answered = true;

        bool correct = currentQuestion.IsCorrect(index);
        pendingResult = new JapaneseHistoryQuizResult(
            currentQuestion.QuestionId,
            correct,
            index,
            currentQuestion.CorrectChoiceIndex,
            Time.realtimeSinceStartup - startedAt,
            currentQuestion.Explanation,
            currentQuestion.GetRewardBuffId(correct),
            currentQuestion.GetRewardBuffName(correct));

        SetChoicesInteractable(false);
        if (feedbackText != null)
        {
            feedbackText.text =
                $"{(correct ? "正解！" : "今回は不正解。")}\n" +
                $"{pendingResult.Explanation}\n\n候補バフ: {pendingResult.RewardBuffName}";
        }

        if (continueButton == null)
        {
            CompleteQuiz();
        }
        else
        {
            SetActive(continueButton.gameObject, true);
            continueButton.interactable = true;
        }
    }

    private void CompleteQuiz()
    {
        if (pendingResult == null) return;
        JapaneseHistoryQuizResult result = pendingResult;
        Action<JapaneseHistoryQuizResult> callback = completedCallback;
        pendingResult = null;
        completedCallback = null;
        SetActive(quizScreen, false);
        callback?.Invoke(result);
    }

    private void BindChoiceButtons()
    {
        UnbindChoiceButtons();
        if (choiceButtons == null) choiceButtons = Array.Empty<Button>();
        for (int i = 0; i < choiceButtons.Length; i++)
        {
            int captured = i;
            UnityAction listener = () => SelectAnswer(captured);
            choiceListeners.Add(listener);
            if (choiceButtons[i] != null) choiceButtons[i].onClick.AddListener(listener);
        }
    }

    private void UnbindChoiceButtons()
    {
        if (choiceButtons != null)
        {
            int count = Mathf.Min(choiceButtons.Length, choiceListeners.Count);
            for (int i = 0; i < count; i++)
                if (choiceButtons[i] != null)
                    choiceButtons[i].onClick.RemoveListener(choiceListeners[i]);
        }
        choiceListeners.Clear();
    }

    private void BindContinueButton()
    {
        if (continueButton == null) return;
        if (continueListener != null) continueButton.onClick.RemoveListener(continueListener);
        continueListener = CompleteQuiz;
        continueButton.onClick.AddListener(continueListener);
    }

    private void SetChoicesInteractable(bool value)
    {
        if (choiceButtons == null) return;
        for (int i = 0; i < choiceButtons.Length; i++)
            if (choiceButtons[i] != null) choiceButtons[i].interactable = value;
    }

    private Text GetChoiceLabel(int index)
    {
        if (choiceButtonTexts != null && index < choiceButtonTexts.Length &&
            choiceButtonTexts[index] != null) return choiceButtonTexts[index];
        return choiceButtons[index] != null
            ? choiceButtons[index].GetComponentInChildren<Text>()
            : null;
    }

    private static void SetActive(GameObject target, bool active)
    {
        if (target != null) target.SetActive(active);
    }

    private void OnDestroy()
    {
        UnbindChoiceButtons();
        if (continueButton != null && continueListener != null)
            continueButton.onClick.RemoveListener(continueListener);
    }
}
