using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

/// <summary>
/// 3教科のバフ獲得画面に共通する表示と確認処理。
/// Stateの変更や次Phaseへの移動はHandlerへ委譲する。
/// </summary>
public abstract class BuffRewardControllerBase : MonoBehaviour
{
    [Header("Screen")]
    [SerializeField] private GameObject buffScreen;
    [SerializeField] private Text titleText;
    [SerializeField] private Text judgmentText;
    [SerializeField] private Text buffNameText;
    [SerializeField] private Text descriptionText;

    [Header("Confirm")]
    [SerializeField] private Button confirmButton;
    [SerializeField] private Text confirmButtonText;

    private UnityAction confirmListener;
    private Action<BuffRewardResult> completedCallback;
    private BuffRewardResult pendingResult;

    protected void OpenReward(
        string title,
        string confirmLabel,
        BuffRewardResult result,
        Action<BuffRewardResult> onCompleted)
    {
        if (result == null || !result.IsValid())
        {
            Debug.LogError($"[{GetType().Name}] バフ結果がnull、または不正です。");
            return;
        }

        pendingResult = result;
        completedCallback = onCompleted;

        SetText(titleText, title);
        SetText(judgmentText, result.WasCorrect ? "正解報酬" : "学習継続報酬");
        SetText(buffNameText, result.BuffName);
        SetText(descriptionText, result.Description);
        SetText(confirmButtonText, confirmLabel);

        BindConfirmButton();
        SetActive(buffScreen, true);

        if (confirmButton == null)
        {
            ConfirmReward();
        }
    }

    public void CloseWithoutGranting()
    {
        pendingResult = null;
        completedCallback = null;
        SetActive(buffScreen, false);
    }

    private void ConfirmReward()
    {
        if (pendingResult == null)
        {
            return;
        }

        BuffRewardResult result = pendingResult;
        Action<BuffRewardResult> callback = completedCallback;

        pendingResult = null;
        completedCallback = null;
        SetActive(buffScreen, false);
        callback?.Invoke(result);
    }

    private void BindConfirmButton()
    {
        if (confirmButton == null)
        {
            return;
        }

        if (confirmListener != null)
        {
            confirmButton.onClick.RemoveListener(confirmListener);
        }

        confirmListener = ConfirmReward;
        confirmButton.onClick.AddListener(confirmListener);
        confirmButton.interactable = true;
    }

    private static void SetText(Text target, string value)
    {
        if (target != null)
        {
            target.text = value ?? string.Empty;
        }
    }

    private static void SetActive(GameObject target, bool active)
    {
        if (target != null)
        {
            target.SetActive(active);
        }
    }

    protected virtual void OnDestroy()
    {
        if (confirmButton != null && confirmListener != null)
        {
            confirmButton.onClick.RemoveListener(confirmListener);
        }
    }
}
