using System;
using CaveGame.CaveBattle;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

/// <summary>
/// エンカウント時に戦闘の前へ挟む会話イベント。
///
/// プレイヤーがここでできること:
/// ・強さを調べる（InspectButton）: ステータス表示を開くだけで、会話は終わらない。
/// ・仲間にする（RecruitButton）: CaveRecruitmentServiceへ判定を委譲する。
///   所持6体未満なら無条件で成功する。
/// ・そのまま戦う（ProceedButton）: 勧誘せずに（＝断って）戦闘へ進む。
///
/// 重要: どの選択をしても、最終的には必ずonCompletedが呼ばれて戦闘へ進める。
/// 「仲間にできない戦闘」（CaveBattleRuleset.AllowsRecruitment=false）の場合は、
/// この画面自体を開かずSkipConversation()で即座に戦闘へ進む
/// （＝会話に関係なく戦闘画面へ行けるルート）。
///
/// StateやBattlePhaseの直接操作はしない。CaveBattleEncounterServiceへ結果を返すだけ。
/// </summary>
public sealed class CaveConversationController : MonoBehaviour
{
    [Header("Screen")]
    [SerializeField] private GameObject conversationScreen;
    [SerializeField] private Text nameText;
    [SerializeField] private Text statusText;
    [SerializeField] private Text resultText;

    [Header("Buttons")]
    [SerializeField] private Button inspectButton;
    [SerializeField] private Button recruitButton;
    [SerializeField] private Button proceedButton;

    [Header("Dependencies")]
    [SerializeField] private CaveRecruitmentService recruitmentService;

    [Header("Debug")]
    [SerializeField] private bool enableDebugLog = true;

    private UnityAction inspectListener;
    private UnityAction recruitListener;
    private UnityAction proceedListener;

    private CaveBattleCharacter pendingEnemy;
    private Action<CaveConversationResult> completedCallback;
    private bool hasDecided;

    private void Awake()
    {
        SetActive(conversationScreen, false);
    }

    /// <summary>
    /// 会話イベントを開く。呼び出し前にCaveBattleEncounterService側で
    /// ruleset.AllowsRecruitmentを確認しておくこと（falseならSkipConversationを呼ぶ）。
    /// </summary>
    public void Open(CaveBattleCharacter enemyData, Action<CaveConversationResult> onCompleted)
    {
        if (enemyData == null)
        {
            Debug.LogError("[CaveConversationController] enemyDataがnullです。");
            SkipConversation(onCompleted);
            return;
        }

        pendingEnemy = enemyData;
        completedCallback = onCompleted;
        hasDecided = false;

        SetText(nameText, $"{enemyData.CharacterName} が現れた！");
        SetText(statusText, string.Empty);
        SetText(resultText, string.Empty);

        BindButtons();
        SetActive(conversationScreen, true);
    }

    /// <summary>
    /// 会話を挟まず、直接戦闘へ進むためのショートカット。
    /// 「仲間にできない戦闘」や、演出をスキップしたい場合に使う。
    /// </summary>
    public void SkipConversation(Action<CaveConversationResult> onCompleted)
    {
        SetActive(conversationScreen, false);
        onCompleted?.Invoke(CaveConversationResult.CreateSkipped());
    }

    private void OnInspectClicked()
    {
        if (pendingEnemy == null)
        {
            return;
        }

        SetText(
            statusText,
            $"ランク:{pendingEnemy.Rank}  HP:{pendingEnemy.MaxHp}  " +
            $"攻撃:{pendingEnemy.BaseAttack}  素早さ:{pendingEnemy.BaseSpeed}");

        Log($"{pendingEnemy.CharacterName} の強さを調べた。");
        // 会話は終了しない。プレイヤーはこの後まだ仲間にする／そのまま戦うを選べる。
    }

    private void OnRecruitClicked()
    {
        if (hasDecided || pendingEnemy == null)
        {
            return;
        }

        CaveRecruitmentOutcome outcome = recruitmentService != null
            ? recruitmentService.TryRecruit(pendingEnemy)
            : CaveRecruitmentOutcome.NotAttempted;

        SetText(resultText, BuildRecruitmentMessage(outcome));
        Complete(CaveConversationChoice.AttemptRecruit, outcome);
    }

    private void OnProceedClicked()
    {
        if (hasDecided)
        {
            return;
        }

        // 勧誘せずに戦闘へ進む＝断ったのと同じ扱い。
        Complete(CaveConversationChoice.Decline, CaveRecruitmentOutcome.NotAttempted);
    }

    private void Complete(CaveConversationChoice choice, CaveRecruitmentOutcome outcome)
    {
        hasDecided = true;

        CaveBattleCharacter enemy = pendingEnemy;
        Action<CaveConversationResult> callback = completedCallback;

        pendingEnemy = null;
        completedCallback = null;

        SetActive(conversationScreen, false);

        Log($"会話終了: {enemy?.CharacterName} choice={choice} outcome={outcome}");
        callback?.Invoke(new CaveConversationResult(choice, outcome, proceedToBattle: true));
    }

    private static string BuildRecruitmentMessage(CaveRecruitmentOutcome outcome)
    {
        switch (outcome)
        {
            case CaveRecruitmentOutcome.RecruitedUnconditionally:
                return "仲間になった！";
            case CaveRecruitmentOutcome.AlreadyRecruited:
                return "すでに仲間です。";
            case CaveRecruitmentOutcome.FailedNotEligible:
                return "仲間にはならなかった…。";
            default:
                return string.Empty;
        }
    }

    private void BindButtons()
    {
        UnbindButtons();

        inspectListener = OnInspectClicked;
        recruitListener = OnRecruitClicked;
        proceedListener = OnProceedClicked;

        if (inspectButton != null)
        {
            inspectButton.onClick.AddListener(inspectListener);
        }

        if (recruitButton != null)
        {
            recruitButton.onClick.AddListener(recruitListener);
        }

        if (proceedButton != null)
        {
            proceedButton.onClick.AddListener(proceedListener);
        }
    }

    private void UnbindButtons()
    {
        if (inspectButton != null && inspectListener != null)
        {
            inspectButton.onClick.RemoveListener(inspectListener);
        }

        if (recruitButton != null && recruitListener != null)
        {
            recruitButton.onClick.RemoveListener(recruitListener);
        }

        if (proceedButton != null && proceedListener != null)
        {
            proceedButton.onClick.RemoveListener(proceedListener);
        }
    }

    private void OnDestroy()
    {
        UnbindButtons();
    }

    private static void SetText(Text target, string value)
    {
        if (target != null)
        {
            target.text = value ?? string.Empty;
        }
    }

    private static void SetActive(GameObject target, bool active)
    {
        if (target != null)
        {
            target.SetActive(active);
        }
    }

    private void Log(string message)
    {
        if (enableDebugLog)
        {
            Debug.Log($"[CaveConversationController] {message}");
        }
    }
}
