using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

/// <summary>
/// 数学CSVから問題を選び、表示・回答・解説表示を行う。
/// </summary>
public sealed class MathQuizController : MonoBehaviour
{
    [Header("Screen")]
    [SerializeField] private GameObject quizScreen;
    [SerializeField] private Text questionText;
    [SerializeField] private Text hintText;
    [SerializeField] private Text feedbackText;

    [Header("Choices")]
    [SerializeField] private Button[] choiceButtons;
    [SerializeField] private Text[] choiceButtonTexts;

    [Header("Continue")]
    [SerializeField] private Button continueButton;
    [SerializeField] private Text continueButtonText;

    [Header("CSV")]
    [SerializeField] private TextAsset mathQuestionsCsv;
    [SerializeField] private List<MathQuizQuestion> questions = new List<MathQuizQuestion>();

    private readonly List<UnityAction> choiceListeners = new List<UnityAction>();
    private UnityAction continueListener;
    private MathQuizQuestion currentQuestion;
    private MathQuizResult pendingResult;
    private Action<MathQuizResult> completedCallback;
    private float startedAt;
    private bool answered;
    private bool csvLoaded;

    public void StartQuiz(CaveEventState state, Action<MathQuizResult> onCompleted)
    {
        completedCallback = onCompleted;
        pendingResult = null;
        answered = false;
        currentQuestion = SelectQuestion();

        if (currentQuestion == null)
        {
            Debug.LogError("[MathQuizController] 有効な数学問題がありません。");
            return;
        }

        SetActive(quizScreen, true);
        BindChoiceButtons();
        BindContinueButton();
        RenderQuestion();
        startedAt = Time.realtimeSinceStartup;
    }

    private MathQuizQuestion SelectQuestion()
    {
        LoadCsvIfNeeded();
        if (questions == null)
        {
            questions = new List<MathQuizQuestion>();
        }

        List<MathQuizQuestion> valid = questions.FindAll(item => item != null && item.IsValid());
        return valid.Count > 0
            ? valid[UnityEngine.Random.Range(0, valid.Count)]
            : MathQuizQuestion.CreateLinearEquationDemo();
    }

    private void LoadCsvIfNeeded()
    {
        if (csvLoaded || mathQuestionsCsv == null)
        {
            return;
        }

        csvLoaded = true;
        try
        {
            questions = MathQuizQuestion.ReadCsv(mathQuestionsCsv.text);
            Debug.Log($"[MathQuizController] 数学問題CSVを{questions.Count}件読み込みました。");
        }
        catch (Exception ex)
        {
            questions = new List<MathQuizQuestion>();
            Debug.LogError($"[MathQuizController] 数学問題CSVの読み込みに失敗しました。\n{ex}");
        }
    }

    private void RenderQuestion()
    {
        if (questionText != null) questionText.text = currentQuestion.QuestionText;
        if (hintText != null) hintText.text = $"ヒント: {currentQuestion.FormulaHint}";
        if (feedbackText != null) feedbackText.text = string.Empty;

        if (choiceButtons == null) choiceButtons = Array.Empty<Button>();
        for (int i = 0; i < choiceButtons.Length; i++)
        {
            Button button = choiceButtons[i];
            if (button == null) continue;

            bool hasChoice = i < currentQuestion.Choices.Count;
            button.gameObject.SetActive(hasChoice);
            button.interactable = hasChoice;

            Text label = GetChoiceLabel(i);
            if (hasChoice && label != null) label.text = currentQuestion.GetChoice(i);
        }

        SetActive(continueButton != null ? continueButton.gameObject : null, false);
        if (continueButtonText != null) continueButtonText.text = "数学バフを受け取る";
    }

    private void SelectAnswer(int index)
    {
        if (answered || currentQuestion == null) return;
        answered = true;

        bool correct = currentQuestion.IsCorrect(index);
        pendingResult = new MathQuizResult(
            currentQuestion.QuestionId,
            correct,
            index,
            currentQuestion.CorrectChoiceIndex,
            Time.realtimeSinceStartup - startedAt,
            currentQuestion.Explanation,
            currentQuestion.GetRewardBuffId(correct),
            currentQuestion.GetRewardBuffName(correct));

        SetChoicesInteractable(false);
        if (feedbackText != null)
        {
            feedbackText.text =
                $"{(correct ? "正解！" : "今回は不正解。")}\n" +
                $"{pendingResult.Explanation}\n\n獲得バフ: {pendingResult.RewardBuffName}";
        }

        if (continueButton == null)
        {
            CompleteQuiz();
        }
        else
        {
            SetActive(continueButton.gameObject, true);
            continueButton.interactable = true;
        }
    }

    private void CompleteQuiz()
    {
        if (pendingResult == null) return;
        MathQuizResult result = pendingResult;
        Action<MathQuizResult> callback = completedCallback;
        pendingResult = null;
        completedCallback = null;
        SetActive(quizScreen, false);
        callback?.Invoke(result);
    }

    private void BindChoiceButtons()
    {
        UnbindChoiceButtons();
        if (choiceButtons == null) choiceButtons = Array.Empty<Button>();

        for (int i = 0; i < choiceButtons.Length; i++)
        {
            int captured = i;
            UnityAction listener = () => SelectAnswer(captured);
            choiceListeners.Add(listener);
            if (choiceButtons[i] != null) choiceButtons[i].onClick.AddListener(listener);
        }
    }

    private void UnbindChoiceButtons()
    {
        if (choiceButtons != null)
        {
            int count = Mathf.Min(choiceButtons.Length, choiceListeners.Count);
            for (int i = 0; i < count; i++)
            {
                if (choiceButtons[i] != null)
                    choiceButtons[i].onClick.RemoveListener(choiceListeners[i]);
            }
        }
        choiceListeners.Clear();
    }

    private void BindContinueButton()
    {
        if (continueButton == null) return;
        if (continueListener != null) continueButton.onClick.RemoveListener(continueListener);
        continueListener = CompleteQuiz;
        continueButton.onClick.AddListener(continueListener);
    }

    private void SetChoicesInteractable(bool value)
    {
        if (choiceButtons == null) return;
        for (int i = 0; i < choiceButtons.Length; i++)
            if (choiceButtons[i] != null) choiceButtons[i].interactable = value;
    }

    private Text GetChoiceLabel(int index)
    {
        if (choiceButtonTexts != null && index < choiceButtonTexts.Length &&
            choiceButtonTexts[index] != null) return choiceButtonTexts[index];
        return choiceButtons[index] != null
            ? choiceButtons[index].GetComponentInChildren<Text>()
            : null;
    }

    private static void SetActive(GameObject target, bool active)
    {
        if (target != null) target.SetActive(active);
    }

    private void OnDestroy()
    {
        UnbindChoiceButtons();
        if (continueButton != null && continueListener != null)
            continueButton.onClick.RemoveListener(continueListener);
    }
}
