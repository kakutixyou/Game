using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

/// <summary>
/// 理科問題画面の表示、回答受付、正誤表示を担当する。
/// 洞窟のPhase変更やState更新はCaveExplorationHandlerへ返す。
/// </summary>
public sealed class ScienceQuizController : MonoBehaviour
{
    [Header("Screen")]
    [SerializeField] private GameObject quizScreen;
    [SerializeField] private Text questionText;
    [SerializeField] private Text feedbackText;

    [Header("Choices")]
    [SerializeField] private Button[] choiceButtons;
    [SerializeField] private Text[] choiceButtonTexts;

    [Header("Continue")]
    [SerializeField] private Button continueButton;
    [SerializeField] private Text continueButtonText;

    [Header("Questions")]
    [Tooltip("Resources/GameData/science_questions.csvを設定。未設定時はInspectorのQuestionsを使用する。")]
    [SerializeField] private TextAsset scienceQuestionsCsv;
    [SerializeField] private List<ScienceQuizQuestion> questions =
        new List<ScienceQuizQuestion>();

    private readonly List<UnityAction> choiceListeners = new List<UnityAction>();
    private UnityAction continueListener;
    private ScienceQuizQuestion currentQuestion;
    private ScienceQuizResult pendingResult;
    private Action<ScienceQuizResult> completedCallback;
    private float startedAt;
    private bool answered;
    private bool csvLoaded;

    public void StartQuiz(
        CaveEventState state,
        Action<ScienceQuizResult> onCompleted)
    {
        completedCallback = onCompleted;
        pendingResult = null;
        answered = false;

        currentQuestion = SelectQuestion();
        if (currentQuestion == null)
        {
            Debug.LogError("[ScienceQuizController] 有効な理科問題がありません。");
            return;
        }

        SetActive(quizScreen, true);
        BindChoiceButtons();
        BindContinueButton();
        RenderQuestion();
        startedAt = Time.realtimeSinceStartup;
    }

    private ScienceQuizQuestion SelectQuestion()
    {
        LoadCsvIfNeeded();

        if (questions == null)
        {
            questions = new List<ScienceQuizQuestion>();
        }

        List<ScienceQuizQuestion> validQuestions = questions.FindAll(
            item => item != null && item.IsValid());

        if (validQuestions.Count == 0)
        {
            return ScienceQuizQuestion.CreateBoilingPointDemo();
        }

        return validQuestions[UnityEngine.Random.Range(0, validQuestions.Count)];
    }

    private void LoadCsvIfNeeded()
    {
        if (csvLoaded || scienceQuestionsCsv == null)
        {
            return;
        }

        csvLoaded = true;

        try
        {
            questions = ScienceQuizQuestion.ReadCsv(scienceQuestionsCsv.text);
            Debug.Log($"[ScienceQuizController] 理科問題CSVを{questions.Count}件読み込みました。");
        }
        catch (Exception ex)
        {
            Debug.LogError($"[ScienceQuizController] 理科問題CSVの読み込みに失敗しました。\n{ex}");
            questions = new List<ScienceQuizQuestion>();
        }
    }

    private void RenderQuestion()
    {
        if (questionText != null)
        {
            questionText.text = currentQuestion.QuestionText;
        }

        if (feedbackText != null)
        {
            feedbackText.text = string.Empty;
        }

        for (int i = 0; i < choiceButtons.Length; i++)
        {
            if (choiceButtons[i] == null)
            {
                continue;
            }

            bool hasChoice = i < currentQuestion.Choices.Count;
            choiceButtons[i].gameObject.SetActive(hasChoice);
            choiceButtons[i].interactable = hasChoice;

            if (hasChoice)
            {
                Text label = GetChoiceLabel(i);
                if (label != null)
                {
                    label.text = currentQuestion.GetChoice(i);
                }
            }
        }

        SetActive(continueButton != null ? continueButton.gameObject : null, false);
        if (continueButtonText != null)
        {
            continueButtonText.text = "バフを受け取る";
        }
    }

    private void SelectAnswer(int selectedIndex)
    {
        if (answered || currentQuestion == null)
        {
            return;
        }

        answered = true;
        bool isCorrect = selectedIndex == currentQuestion.CorrectChoiceIndex;
        float answerTime = Time.realtimeSinceStartup - startedAt;

        pendingResult = new ScienceQuizResult(
            currentQuestion.QuestionId,
            isCorrect,
            selectedIndex,
            currentQuestion.CorrectChoiceIndex,
            answerTime,
            currentQuestion.Explanation,
            currentQuestion.GetRewardBuffId(isCorrect),
            currentQuestion.GetRewardBuffName(isCorrect));

        for (int i = 0; i < choiceButtons.Length; i++)
        {
            if (choiceButtons[i] != null)
            {
                choiceButtons[i].interactable = false;
            }
        }

        if (feedbackText != null)
        {
            string judgment = isCorrect ? "正解！" : "今回は不正解。";
            feedbackText.text =
                $"{judgment}\n{pendingResult.Explanation}\n\n" +
                $"獲得バフ: {pendingResult.RewardBuffName}";
        }

        if (continueButton == null)
        {
            CompleteQuiz();
            return;
        }

        SetActive(continueButton.gameObject, true);
        continueButton.interactable = true;
    }

    private void CompleteQuiz()
    {
        if (pendingResult == null)
        {
            return;
        }

        ScienceQuizResult result = pendingResult;
        Action<ScienceQuizResult> callback = completedCallback;

        pendingResult = null;
        completedCallback = null;
        SetActive(quizScreen, false);
        callback?.Invoke(result);
    }

    private void BindChoiceButtons()
    {
        UnbindChoiceButtons();

        if (choiceButtons == null)
        {
            choiceButtons = Array.Empty<Button>();
        }

        for (int i = 0; i < choiceButtons.Length; i++)
        {
            Button button = choiceButtons[i];
            int capturedIndex = i;
            UnityAction listener = () => SelectAnswer(capturedIndex);
            choiceListeners.Add(listener);

            if (button != null)
            {
                button.onClick.AddListener(listener);
            }
        }
    }

    private void UnbindChoiceButtons()
    {
        if (choiceButtons != null)
        {
            int count = Mathf.Min(choiceButtons.Length, choiceListeners.Count);
            for (int i = 0; i < count; i++)
            {
                if (choiceButtons[i] != null)
                {
                    choiceButtons[i].onClick.RemoveListener(choiceListeners[i]);
                }
            }
        }

        choiceListeners.Clear();
    }

    private void BindContinueButton()
    {
        if (continueButton == null)
        {
            return;
        }

        if (continueListener != null)
        {
            continueButton.onClick.RemoveListener(continueListener);
        }

        continueListener = CompleteQuiz;
        continueButton.onClick.AddListener(continueListener);
    }

    private Text GetChoiceLabel(int index)
    {
        if (choiceButtonTexts != null &&
            index >= 0 &&
            index < choiceButtonTexts.Length &&
            choiceButtonTexts[index] != null)
        {
            return choiceButtonTexts[index];
        }

        return choiceButtons[index] != null
            ? choiceButtons[index].GetComponentInChildren<Text>()
            : null;
    }

    private static void SetActive(GameObject target, bool active)
    {
        if (target != null)
        {
            target.SetActive(active);
        }
    }

    private void OnDestroy()
    {
        UnbindChoiceButtons();

        if (continueButton != null && continueListener != null)
        {
            continueButton.onClick.RemoveListener(continueListener);
        }
    }
}
