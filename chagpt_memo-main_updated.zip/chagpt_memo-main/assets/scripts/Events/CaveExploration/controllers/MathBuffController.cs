using System;
using UnityEngine;

public sealed class MathBuffController : BuffRewardControllerBase
{
    public void Open(
        MathQuizResult quizResult,
        Action<BuffRewardResult> onCompleted)
    {
        if (quizResult == null)
        {
            Debug.LogError("[MathBuffController] MathQuizResultがnullです。");
            return;
        }

        BuffRewardResult result = new BuffRewardResult(
            QuizSubject.Math,
            quizResult.QuestionId,
            quizResult.RewardBuffId,
            quizResult.RewardBuffName,
            BuildDescription(quizResult),
            quizResult.RewardTier,
            quizResult.IsCorrect);

        OpenReward("数学バフ獲得", "日本史問題へ進む", result, onCompleted);
    }

    private static string BuildDescription(MathQuizResult result)
    {
        string rank = result.IsCorrect ? "正解による強化バフです。" : "途中式を見直すための補助バフです。";
        return $"{rank}\n{result.Explanation}";
    }
}
