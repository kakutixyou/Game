using System;
using System.Collections.Generic;
using CaveGame.CaveBattle;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

/// <summary>
/// キャラクター候補の表示と決定を担当する。
/// repositoryを渡さずOpen()を呼ぶとInspector内の候補（デモ用）を使い、
/// Open(onSelected, repository)を呼ぶとCaveBattleDataRepositoryの実キャラクター
/// （japanese_history_chars_expanded.csv）を候補にする。選択結果のidはCSVのidをそのまま
/// 文字列化したものなので、TwoTurnBattlePhase.Executeへ渡す際はint.Parseするだけでよい。
/// </summary>
public sealed class CharacterSelectController : MonoBehaviour
{
    [Header("Screen")]
    [SerializeField] private GameObject characterSelectScreen;
    [SerializeField] private Text guideText;
    [SerializeField] private Text selectedCharacterText;

    [Header("Candidates")]
    [SerializeField] private List<CharacterSelectionOption> candidates =
        new List<CharacterSelectionOption>();
    [SerializeField] private Button[] characterButtons;
    [SerializeField] private Text[] characterButtonTexts;

    [Header("Confirm")]
    [SerializeField] private Button confirmButton;

    private readonly List<UnityAction> characterListeners = new List<UnityAction>();
    private UnityAction confirmListener;
    private Action<string, string> selectedCallback;
    private CharacterSelectionOption selectedCharacter;

    public void Open(Action<string, string> onSelected)
    {
        Open(onSelected, null);
    }

    /// <summary>
    /// repositoryを渡すと、実際のjapanese_history_chars_expanded.csvのキャラクターを候補にする。
    /// nullの場合は従来通りInspector内の候補（デモ用）を使う。
    /// </summary>
    public void Open(Action<string, string> onSelected, CaveBattleDataRepository repository)
    {
        selectedCallback = onSelected;
        selectedCharacter = null;

        if (repository != null)
        {
            PopulateCandidatesFromRepository(repository);
        }
        else
        {
            EnsureDemoCandidates();
        }

        SetActive(characterSelectScreen, true);
        BindCharacterButtons();
        BindConfirmButton();
        Render();
    }

    private void PopulateCandidatesFromRepository(CaveBattleDataRepository repository)
    {
        candidates = new List<CharacterSelectionOption>();

        foreach (KeyValuePair<int, CaveBattleCharacter> pair in repository.Characters)
        {
            CaveBattleCharacter character = pair.Value;
            candidates.Add(new CharacterSelectionOption(
                character.Id.ToString(),
                character.CharacterName,
                character.Description));
        }
    }

    private void EnsureDemoCandidates()
    {
        if (candidates == null)
        {
            candidates = new List<CharacterSelectionOption>();
        }

        if (candidates.Count > 0)
        {
            return;
        }

        candidates.Add(new CharacterSelectionOption(
            "character.swordsman",
            "剣士",
            "攻撃と守りのバランスが良いキャラクター"));
        candidates.Add(new CharacterSelectionOption(
            "character.scholar",
            "学者",
            "理科バフとの組み合わせを得意とするキャラクター"));
        candidates.Add(new CharacterSelectionOption(
            "character.runner",
            "俊足の冒険者",
            "先攻しやすい素早さ重視のキャラクター"));
    }

    private void Render()
    {
        if (guideText != null)
        {
            guideText.text = "戦闘に参加するキャラクターを選んでください。";
        }

        if (selectedCharacterText != null)
        {
            selectedCharacterText.text = "未選択";
        }

        if (characterButtons == null)
        {
            characterButtons = Array.Empty<Button>();
        }

        for (int i = 0; i < characterButtons.Length; i++)
        {
            Button button = characterButtons[i];
            if (button == null)
            {
                continue;
            }

            bool hasCandidate = i < candidates.Count;
            button.gameObject.SetActive(hasCandidate);
            button.interactable = hasCandidate;

            if (hasCandidate)
            {
                Text label = GetCharacterLabel(i);
                if (label != null)
                {
                    label.text = candidates[i].CharacterName;
                }
            }
        }

        if (confirmButton != null)
        {
            confirmButton.interactable = false;
        }
    }

    private void SelectCharacter(int index)
    {
        if (index < 0 || index >= candidates.Count)
        {
            return;
        }

        selectedCharacter = candidates[index];

        if (selectedCharacterText != null)
        {
            selectedCharacterText.text =
                $"選択中: {selectedCharacter.CharacterName}\n" +
                selectedCharacter.Description;
        }

        if (confirmButton == null)
        {
            ConfirmSelection();
            return;
        }

        confirmButton.interactable = true;
    }

    private void ConfirmSelection()
    {
        if (selectedCharacter == null)
        {
            return;
        }

        Action<string, string> callback = selectedCallback;
        string id = selectedCharacter.CharacterId;
        string displayName = selectedCharacter.CharacterName;

        selectedCallback = null;
        SetActive(characterSelectScreen, false);
        callback?.Invoke(id, displayName);
    }

    private void BindCharacterButtons()
    {
        UnbindCharacterButtons();

        if (characterButtons == null)
        {
            characterButtons = Array.Empty<Button>();
        }

        for (int i = 0; i < characterButtons.Length; i++)
        {
            Button button = characterButtons[i];
            int capturedIndex = i;
            UnityAction listener = () => SelectCharacter(capturedIndex);
            characterListeners.Add(listener);

            if (button != null)
            {
                button.onClick.AddListener(listener);
            }
        }
    }

    private void UnbindCharacterButtons()
    {
        if (characterButtons != null)
        {
            int count = Mathf.Min(characterButtons.Length, characterListeners.Count);
            for (int i = 0; i < count; i++)
            {
                if (characterButtons[i] != null)
                {
                    characterButtons[i].onClick.RemoveListener(characterListeners[i]);
                }
            }
        }

        characterListeners.Clear();
    }

    private void BindConfirmButton()
    {
        if (confirmButton == null)
        {
            return;
        }

        if (confirmListener != null)
        {
            confirmButton.onClick.RemoveListener(confirmListener);
        }

        confirmListener = ConfirmSelection;
        confirmButton.onClick.AddListener(confirmListener);
    }

    private Text GetCharacterLabel(int index)
    {
        if (characterButtonTexts != null &&
            index >= 0 &&
            index < characterButtonTexts.Length &&
            characterButtonTexts[index] != null)
        {
            return characterButtonTexts[index];
        }

        return characterButtons[index] != null
            ? characterButtons[index].GetComponentInChildren<Text>()
            : null;
    }

    private static void SetActive(GameObject target, bool active)
    {
        if (target != null)
        {
            target.SetActive(active);
        }
    }

    private void OnDestroy()
    {
        UnbindCharacterButtons();

        if (confirmButton != null && confirmListener != null)
        {
            confirmButton.onClick.RemoveListener(confirmListener);
        }
    }
}
