using System;
using UnityEngine;

public sealed class ScienceBuffController : BuffRewardControllerBase
{
    public void Open(
        ScienceQuizResult quizResult,
        Action<BuffRewardResult> onCompleted)
    {
        if (quizResult == null)
        {
            Debug.LogError("[ScienceBuffController] ScienceQuizResultがnullです。");
            return;
        }

        BuffRewardResult result = new BuffRewardResult(
            QuizSubject.Science,
            quizResult.QuestionId,
            quizResult.RewardBuffId,
            quizResult.RewardBuffName,
            BuildDescription(quizResult),
            quizResult.RewardTier,
            quizResult.IsCorrect);

        OpenReward("理科バフ獲得", "数学問題へ進む", result, onCompleted);
    }

    private static string BuildDescription(ScienceQuizResult result)
    {
        string rank = result.IsCorrect ? "正解による強化バフです。" : "復習を続けるための補助バフです。";
        return $"{rank}\n{result.Explanation}";
    }
}
