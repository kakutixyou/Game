using System.Collections.Generic;
using System.Text;
using CaveGame.CaveBattle;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 日本史/理科/数学バフダンジョン用のリザルト画面。
/// ・外枠を黄色、内側をピンクにして「何人抜きできたか」を大きく表示する
/// ・右上のログボタンを押すと、敗因（キャラクター起因/バフ起因）とその時点のバフ構成を表示する
///
/// 色や文言はプレースホルダーなので、実際のアートに合わせて調整してほしい。
/// </summary>
public sealed class CaveGauntletResultView : MonoBehaviour
{
    [Header("Root")]
    [SerializeField] private GameObject resultScreenRoot;

    [Header("外枠・内側（ご指定の配色）")]
    [SerializeField] private Image outerFrameImage;
    [SerializeField] private Image innerPanelImage;
    [SerializeField] private Color outerFrameColor = new Color(1f, 0.84f, 0f); // 黄色
    [SerializeField] private Color innerPanelColor = new Color(1f, 0.75f, 0.8f); // ピンク

    [Header("何人抜き表示")]
    [SerializeField] private Text winCountText;
    [SerializeField] private string winCountFormat = "{0}人抜き！";

    [Header("敗北した相手")]
    [SerializeField] private Text losingEnemyText;
    [SerializeField] private string losingEnemyFormat = "敗北した相手: {0}";

    [Header("ログ（右上ボタン）")]
    [SerializeField] private Button logButton;
    [SerializeField] private GameObject logPanelRoot;
    [SerializeField] private Text logContentText;

    [Header("閉じるボタン（任意）")]
    [SerializeField] private Button closeButton;

    private bool isLogOpen;

    private void Awake()
    {
        if (logButton != null)
        {
            logButton.onClick.AddListener(ToggleLog);
        }

        if (closeButton != null)
        {
            closeButton.onClick.AddListener(Close);
        }
    }

    private void OnDestroy()
    {
        if (logButton != null)
        {
            logButton.onClick.RemoveListener(ToggleLog);
        }

        if (closeButton != null)
        {
            closeButton.onClick.RemoveListener(Close);
        }
    }

    public void Show(CaveGauntletResult result)
    {
        if (result == null)
        {
            return;
        }

        SetActive(resultScreenRoot, true);
        SetActive(logPanelRoot, false);
        isLogOpen = false;

        if (outerFrameImage != null)
        {
            outerFrameImage.color = outerFrameColor;
        }

        if (innerPanelImage != null)
        {
            innerPanelImage.color = innerPanelColor;
        }

        if (!result.Succeeded)
        {
            if (winCountText != null)
            {
                winCountText.text = "エラーが発生しました";
            }

            if (losingEnemyText != null)
            {
                losingEnemyText.text = result.ErrorMessage;
            }

            if (logContentText != null)
            {
                logContentText.text = result.ErrorMessage;
            }

            return;
        }

        if (winCountText != null)
        {
            winCountText.text = string.Format(winCountFormat, result.WinCount);
        }

        if (losingEnemyText != null)
        {
            losingEnemyText.text = string.Format(losingEnemyFormat, result.LosingEnemyCharacterName);
        }

        if (logContentText != null)
        {
            logContentText.text = BuildLogText(result);
        }
    }

    public void Close()
    {
        SetActive(resultScreenRoot, false);
    }

    private void ToggleLog()
    {
        isLogOpen = !isLogOpen;
        SetActive(logPanelRoot, isLogOpen);
    }

    /// <summary>
    /// ログ本文を組み立てる。「敗因（キャラクターによるものかバフによるものか）」と
    /// 「その時のバフ構成」を中心に、各戦の簡易サマリーも添える。
    /// </summary>
    private static string BuildLogText(CaveGauntletResult result)
    {
        StringBuilder sb = new StringBuilder();

        sb.Append(result.WinCount).AppendLine("人抜きで敗北。");
        sb.Append("敗因: ").AppendLine(FormatDefeatCause(result.DefeatCause));
        if (!string.IsNullOrEmpty(result.DefeatCauseNote))
        {
            sb.AppendLine(result.DefeatCauseNote);
        }

        sb.AppendLine();
        sb.AppendLine("== 敗北時点のバフ構成 ==");
        IReadOnlyList<CaveAcquiredBuff> buffs = result.AcquiredBuffs;
        if (buffs.Count == 0)
        {
            sb.AppendLine("（バフは1つも獲得していなかった）");
        }
        else
        {
            for (int i = 0; i < buffs.Count; i++)
            {
                CaveAcquiredBuff buff = buffs[i];
                sb.Append("・[").Append(FormatSubject(buff.Subject)).Append("] ")
                    .Append(buff.BuffName)
                    .Append("（").Append(buff.AcquiredAfterWinNumber).Append("勝後に獲得）")
                    .AppendLine();
            }
        }

        sb.AppendLine();
        sb.AppendLine("== 対戦履歴 ==");
        IReadOnlyList<CaveGauntletRoundLog> rounds = result.Rounds;
        for (int i = 0; i < rounds.Count; i++)
        {
            CaveGauntletRoundLog round = rounds[i];
            sb.Append(round.RoundNumber).Append("戦目 vs ").Append(round.EnemyCharacterName)
                .Append(" : ").Append(FormatBattleResult(round.Result))
                .Append("（残りHP 自分").Append(round.PlayerRemainingHp)
                .Append(" / 相手").Append(round.EnemyRemainingHp).Append("）")
                .AppendLine();
        }

        return sb.ToString();
    }

    private static string FormatDefeatCause(CaveGauntletDefeatCause cause)
    {
        switch (cause)
        {
            case CaveGauntletDefeatCause.Buff:
                return "バフによるもの";
            case CaveGauntletDefeatCause.Character:
            default:
                return "キャラクターによるもの";
        }
    }

    private static string FormatSubject(CaveBuffSubject subject)
    {
        switch (subject)
        {
            case CaveBuffSubject.Math:
                return "数学";
            case CaveBuffSubject.Science:
                return "理科";
            case CaveBuffSubject.History:
                return "日本史";
            default:
                return "-";
        }
    }

    private static string FormatBattleResult(BattleResultType result)
    {
        switch (result)
        {
            case BattleResultType.Win:
                return "勝利";
            case BattleResultType.Lose:
                return "敗北";
            case BattleResultType.Draw:
                return "引き分け";
            default:
                return result.ToString();
        }
    }

    private static void SetActive(GameObject target, bool active)
    {
        if (target != null)
        {
            target.SetActive(active);
        }
    }
}
