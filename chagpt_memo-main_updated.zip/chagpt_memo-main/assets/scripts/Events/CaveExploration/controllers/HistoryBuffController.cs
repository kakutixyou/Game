using System;
using UnityEngine;

public sealed class HistoryBuffController : BuffRewardControllerBase
{
    public void Open(
        JapaneseHistoryQuizResult quizResult,
        Action<BuffRewardResult> onCompleted)
    {
        if (quizResult == null)
        {
            Debug.LogError("[HistoryBuffController] JapaneseHistoryQuizResultがnullです。");
            return;
        }

        BuffRewardResult result = new BuffRewardResult(
            QuizSubject.JapaneseHistory,
            quizResult.QuestionId,
            quizResult.RewardBuffId,
            quizResult.RewardBuffName,
            BuildDescription(quizResult),
            quizResult.RewardTier,
            quizResult.IsCorrect);

        OpenReward("日本史バフ獲得", "キャラクター選択へ進む", result, onCompleted);
    }

    private static string BuildDescription(JapaneseHistoryQuizResult result)
    {
        string rank = result.IsCorrect ? "正解した時代・人物に由来するバフです。" : "年表を整理するための補助バフです。";
        return $"{rank}\n{result.Explanation}";
    }
}
