会話・仲間勧誘機能 実装メモ

最終更新: 2026-09-25

## 30秒で思い出す要約

エンカウント（ボタン or 敵prefab）→ 会話イベント（任意）→ 戦闘、という流れを追加した。

- 会話イベントは「仲間にできる戦闘」でだけ発生する。
- 会話でプレイヤーが何を選んでも（仲間にする／断る／そのまま戦う）、最終的に必ず戦闘へ進む。
- 会話自体をスキップしても（仲間にできない戦闘、または演出省略設定）戦闘へ進める。
- 所持している仲間が5体以下（0〜5体）の間は、レア度・強さに関係なく無条件で仲間にできる。
- 仲間が6体になると、他ルールの戦闘（AllowsRecruitment=false）が解放される。

## 追加したクラス

| クラス | 役割 |
| --- | --- |
| `PartyRoster` / `PartyMember` | 仲間にしたキャラクターの永続所持データ。探索リセットの影響を受けない。 |
| `CaveRecruitmentService` | 勧誘の成否判定とPartyRosterへの書き込み。「他ルール解放済みか」もここで判定。 |
| `CaveConversationChoice` / `CaveRecruitmentOutcome` / `CaveConversationResult` | 会話・勧誘の結果を表すモデル（`CaveGame.CaveBattle`名前空間、`CaveRecruitmentModels.cs`）。 |
| `CaveConversationController` | 会話UIの表示・入力受付。強さを調べる／仲間にする／そのまま戦うの3ボタン想定。 |

## 既存クラスの変更点

- `CaveBattleRuleset` に `AllowsRecruitment`（bool）を追加。
  - **これが「開発時にどの戦闘が仲間にできる戦闘か管理する」ための一元管理ポイント。**
  - Inspectorでルールセットごとにチェックを入れるだけで、そのイベント／エリアが
    仲間集め対象かどうかを切り替えられる。
  - 通常ルール（`CaveBattleRuleset.Normal`）は既定でtrue。
- `CaveBattleEncounterService`
  - `TryStartEncounter` が、rulesetのAllowsRecruitmentを見て会話を挟むかどうかを自動判定するようになった。
  - `IsRulesetUnlocked(ruleset)` を追加。AllowsRecruitment=falseのルールは
    `CaveRecruitmentService.HasUnlockedOtherRules`（所持6体以上）がtrueになるまで開始を拒否する。
  - `TryStartEncounterSkippingConversation` を追加。会話を挟まず直接戦闘へ進みたい場合に使う
    （デバッグ、演出を省略したい特定ボタン等）。
  - Inspectorに `conversationController` と `recruitmentService` の参照を追加（任意）。
    どちらも未設定なら従来どおり会話なしで直接戦闘になる。
- `CaveBattleEncounterButton` / `CaveBattleEncounterTrigger`
  - `forceSkipConversation`（bool）を追加。trueにすると、そのボタン／prefabは
    rulesetの設定に関わらず常に会話を挟まない。
- `CavePhase`
  - `Conversation = 75` を追加（Battleの前段）。処理はConversationController側が担当し、
    CavePhase自体は「今どこにいるか」を表すだけという既存方針を踏襲。

## 仲間集めルールの実装場所

- 「所持5体以下なら無条件で仲間になれる」: `PartyRoster.IsFreeRecruitmentAvailable`
  （`OwnedCount <= 5`）と `CaveRecruitmentService.TryRecruit` に実装済み。
- 「所持6体で他ルール解放」: `PartyRoster.HasUnlockedOtherRules`
  （`OwnedCount >= 6`）と `CaveBattleEncounterService.IsRulesetUnlocked` に実装済み。
- 「6体目以降の勧誘条件」は未確定のため、`CaveRecruitmentService.TryRecruit` 内に
  拡張ポイントとしてコメントを残し、現状は常に失敗扱いにしている
  （＝6体という一次到達目標の体験を壊さないための暫定挙動）。
  確率抽選やレア度条件を入れる場合はここを実装する。

## セーブ／ロードについて

`PartyRoster` は `CaveRecruitmentService` がシーン中に1つ保持する想定（MonoBehaviour内のインスタンスフィールド）。
探索をまたいで保持したい永続データなので、既存のセーブシステムに接続する際は
`PartyRoster.Members`（`PartyMember` のリスト）をシリアライズ対象に含めること。
セーブ側の対応が完了するまでは、アプリ再起動でリセットされる。

## Unityでの最小配線

1. CaveSystems配下に `CaveRecruitmentService` を追加する（新規GameObjectでよい）。
2. `CaveConversationController` をUIに追加し、Screen/Text/Buttonを割り当てて、
   `recruitmentService` に上記のServiceを割り当てる。
3. `CaveBattleEncounterService` の `conversationController` と `recruitmentService` に
   それぞれ割り当てる。
4. 仲間にしたいエリアの `CaveBattleRuleset` アセットは `Allows Recruitment` にチェックを入れる。
   仲間にできない特殊ルール（負けたら勝ち等）は、チェックを外す。
5. Playして戦闘ボタンを押し、会話画面→仲間にする／そのまま戦う→戦闘、の順に進めば成功。
