/// <summary>
/// 洞窟探索イベントで使用するイベントIDを一元管理する。
///
/// EventSetTriggerへの登録、解除、デバッグ表示では、
/// 文字列を直接記述せず、このクラスの定数を使用する。
///
/// 注意:
/// IDの文字列はセーブデータ、ログ、外部設定から参照される可能性があるため、
/// 公開後は定数名を変更しても文字列値は不用意に変更しないこと。
/// </summary>
public static class CaveEventIds
{
    private const string Prefix = "cave.";

    // =========================================================
    // Cave Home
    // =========================================================

    /// <summary>
    /// 洞窟ホームから新しい探索を開始する。
    /// </summary>
    public const string StartExploration = Prefix + "start";

    /// <summary>
    /// 洞窟ホームからショップを開く。
    /// </summary>
    public const string OpenShop = Prefix + "shop";

    // =========================================================
    // Learning Phases
    // =========================================================

    /// <summary>
    /// 理科問題を開始する。
    /// </summary>
    public const string ScienceQuiz = Prefix + "science_quiz";

    /// <summary>
    /// 数学問題を開始する。
    /// </summary>
    public const string MathQuiz = Prefix + "math_quiz";

    /// <summary>
    /// 日本史バフの選択画面を開く。
    /// </summary>
    public const string HistoryBuff = Prefix + "history_buff";

    // =========================================================
    // Character / Battle
    // =========================================================

    /// <summary>
    /// 戦闘へ参加させるキャラクターの選択画面を開く。
    /// </summary>
    public const string CharacterSelect = Prefix + "character_select";

    /// <summary>
    /// 戦闘シミュレーションを開始する。
    /// </summary>
    public const string StartBattle = Prefix + "battle";

    // =========================================================
    // Result
    // =========================================================

    /// <summary>
    /// リザルト画面から次のラウンド、または洞窟ホームへ進む。
    /// </summary>
    public const string ResultNext = Prefix + "result_next";
}
