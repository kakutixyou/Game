using CaveGame.CaveBattle;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// UIボタンに付ける「ボタンを押した時に対応する敵とエンカウントする」ためのコンポーネント。
/// Inspectorで戦う相手（enemyCharacterId）と、必要ならこのボタン専用のルールを設定する。
/// </summary>
[RequireComponent(typeof(Button))]
public sealed class CaveBattleEncounterButton : MonoBehaviour
{
    [Header("Dependencies")]
    [SerializeField] private CaveBattleEncounterService encounterService;
    [SerializeField] private Button button;

    [Header("対応する敵")]
    [Tooltip("japanese_history_chars_expanded.csvのid。このボタンを押すと必ずこの敵と戦う。")]
    [SerializeField] private int enemyCharacterId;

    [Header("このボタン専用のルール（任意）")]
    [Tooltip(
        "未設定ならCaveBattleEncounterServiceの現在のアクティブルールを使う。" +
        "rulesetのAllowsRecruitmentで「このボタンは仲間にできる戦闘か」を管理する。")]
    [SerializeField] private CaveBattleRuleset rulesetOverride;

    [Header("会話イベント")]
    [Tooltip(
        "trueの場合、常に会話（仲間勧誘）を挟まず直接戦闘へ進む。" +
        "通常はfalseのままにし、rulesetのAllowsRecruitmentで管理すること。")]
    [SerializeField] private bool forceSkipConversation = false;

    private CaveEventState state;

    private void Reset()
    {
        button = GetComponent<Button>();
    }

    private void Awake()
    {
        if (button == null)
        {
            button = GetComponent<Button>();
        }

        if (button != null)
        {
            button.onClick.AddListener(OnClicked);
        }
    }

    private void OnDestroy()
    {
        if (button != null)
        {
            button.onClick.RemoveListener(OnClicked);
        }
    }

    /// <summary>CaveExplorationHandler等、CaveEventStateを持つ側から呼んで紐付ける。</summary>
    public void Bind(CaveEventState eventState)
    {
        state = eventState;
    }

    private void OnClicked()
    {
        if (encounterService == null)
        {
            Debug.LogError("[CaveBattleEncounterButton] CaveBattleEncounterServiceが未設定です。");
            return;
        }

        if (state == null)
        {
            Debug.LogError("[CaveBattleEncounterButton] Bind(CaveEventState)が呼ばれていません。");
            return;
        }

        if (button != null)
        {
            button.interactable = false;
        }

        if (forceSkipConversation)
        {
            encounterService.TryStartEncounterSkippingConversation(
                state, enemyCharacterId, rulesetOverride, OnBattleCompleted);
        }
        else
        {
            encounterService.TryStartEncounter(state, enemyCharacterId, rulesetOverride, OnBattleCompleted);
        }
    }

    private void OnBattleCompleted(TwoTurnBattlePhaseResult result)
    {
        if (button != null)
        {
            button.interactable = true;
        }

        if (result == null || !result.Succeeded)
        {
            Debug.LogWarning($"[CaveBattleEncounterButton] 戦闘開始に失敗: {result?.ErrorMessage}");
        }
    }
}
