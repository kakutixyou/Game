using System;
using System.Collections.Generic;

/// <summary>
/// プレイヤーが仲間にしたキャラクターの一覧を管理する。
///
/// CaveEventStateは「今回の洞窟探索」だけの状態（StartNewRunでリセットされる）だが、
/// 仲間集めは探索をまたいで積み上がる永続データなので、あえて別クラスにしている。
/// セーブ／ロードは呼び出し側（外部のセーブシステム）が
/// RecruitedCharacterIdsなどのSerializable情報を保存・復元する想定。
///
/// 仕様（仲間集めルール）:
/// ・所持キャラが5体以下（0〜5体）の間は、レア度・強さに関係なく無条件で仲間にできる
///   （プレイヤーは会話で強さを調べたり、勧誘を断ったりはできる＝無条件＝強制ではない）。
/// ・6体目以降は、この「無条件仲間化」の対象外になる。
///   6体目以降の勧誘条件（確率化する／特定条件を課す等）は未確定のため、
///   CaveRecruitmentServiceに拡張ポイントとして残してある。
/// ・6体仲間にした時点（OwnedCount >= 6）で、通常以外のルール
///   （CaveBattleRuleset.AllowsRecruitment = falseの戦闘）が解放される。
/// </summary>
[Serializable]
public sealed class PartyRoster
{
    /// <summary>この人数以下（このキャラを迎えて6体になるまで）は無条件で仲間にできる。</summary>
    public const int FreeRecruitmentMaxOwnedCount = 5;

    /// <summary>この人数に到達すると、仲間にできない戦闘（他ルール）が解放される。</summary>
    public const int OtherRulesUnlockCount = 6;

    private readonly List<PartyMember> members = new List<PartyMember>();

    public IReadOnlyList<PartyMember> Members => members;

    public int OwnedCount => members.Count;

    /// <summary>
    /// 「次に勧誘するキャラ」が無条件仲間化の対象かどうか。
    /// 現在の所持数が5以下（＝これから迎える1体を含めて6体以内）なら true。
    /// </summary>
    public bool IsFreeRecruitmentAvailable => OwnedCount <= FreeRecruitmentMaxOwnedCount;

    /// <summary>6体仲間にした後に解放される「他ルールの戦闘」に挑戦できるか。</summary>
    public bool HasUnlockedOtherRules => OwnedCount >= OtherRulesUnlockCount;

    public bool Contains(int characterId)
    {
        for (int i = 0; i < members.Count; i++)
        {
            if (members[i].CharacterId == characterId)
            {
                return true;
            }
        }

        return false;
    }

    /// <summary>
    /// 仲間を追加する。既に仲間の場合は何もせずfalseを返す。
    /// </summary>
    public bool AddMember(int characterId, string characterName, int rank)
    {
        if (Contains(characterId))
        {
            return false;
        }

        members.Add(new PartyMember(characterId, characterName, rank, DateTime.Now));
        return true;
    }

    public void Clear()
    {
        members.Clear();
    }
}

/// <summary>仲間になった1キャラクターの記録。</summary>
[Serializable]
public sealed class PartyMember
{
    public int CharacterId { get; }
    public string CharacterName { get; }
    public int Rank { get; }
    public DateTime RecruitedAt { get; }

    public PartyMember(int characterId, string characterName, int rank, DateTime recruitedAt)
    {
        CharacterId = characterId;
        CharacterName = characterName ?? string.Empty;
        Rank = rank;
        RecruitedAt = recruitedAt;
    }
}
