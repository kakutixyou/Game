using CaveGame.CaveBattle;
using UnityEngine;

/// <summary>
/// 「この戦闘は仲間にできるか」「今回の勧誘は成功するか」を判定する窓口。
///
/// PartyRosterへの実際の書き込みもここで行う。CaveConversationControllerや
/// CaveBattleEncounterServiceからはこのServiceのTryRecruit()だけを呼べばよい。
/// </summary>
public sealed class CaveRecruitmentService : MonoBehaviour
{
    [Header("Debug")]
    [SerializeField] private bool enableDebugLog = true;

    private readonly PartyRoster roster = new PartyRoster();

    public PartyRoster Roster => roster;

    /// <summary>6体仲間にした後に解放される「他ルールの戦闘」に挑戦できるか。</summary>
    public bool HasUnlockedOtherRules => roster.HasUnlockedOtherRules;

    /// <summary>
    /// このrulesetの戦闘が、そもそも仲間集めの対象（＝会話イベントを挟む対象）かどうか。
    /// 開発時はCaveBattleRuleset側のAllowsRecruitmentチェックボックス1つで
    /// 「仲間にできる戦闘」か「仲間にできない戦闘」かを管理できる。
    /// </summary>
    public bool IsRecruitableBattle(CaveBattleRuleset ruleset)
    {
        return ruleset == null || ruleset.AllowsRecruitment;
    }

    /// <summary>
    /// 勧誘を試みる。呼び出し前にIsRecruitableBattle(ruleset)がfalseの場合は呼ばないこと
    /// （CaveConversationController側で会話自体をスキップする想定）。
    /// </summary>
    public CaveRecruitmentOutcome TryRecruit(CaveBattleCharacter enemyData)
    {
        if (enemyData == null)
        {
            return CaveRecruitmentOutcome.NotAttempted;
        }

        if (roster.Contains(enemyData.Id))
        {
            Log($"{enemyData.CharacterName} は既に仲間です。");
            return CaveRecruitmentOutcome.AlreadyRecruited;
        }

        if (roster.IsFreeRecruitmentAvailable)
        {
            // 所持5体以下（＝これで6体目まで）は、レア度・強さを問わず無条件で仲間になる。
            roster.AddMember(enemyData.Id, enemyData.CharacterName, enemyData.Rank);
            Log($"{enemyData.CharacterName} が無条件で仲間になった（所持{roster.OwnedCount}体）。");
            return CaveRecruitmentOutcome.RecruitedUnconditionally;
        }

        // 所持6体目以降の勧誘条件は未確定。
        // ここを拡張すればレア度・確率抽選・所持済み仲間との組み合わせ制限などを追加できる。
        // 現時点では常に失敗として扱い、既存の6体分の仲間集め体験を壊さないようにしている。
        Log($"{enemyData.CharacterName} の勧誘条件は未確定のため、今回は仲間にできなかった。");
        return CaveRecruitmentOutcome.FailedNotEligible;
    }

    private void Log(string message)
    {
        if (enableDebugLog)
        {
            Debug.Log($"[CaveRecruitmentService] {message}");
        }
    }
}
