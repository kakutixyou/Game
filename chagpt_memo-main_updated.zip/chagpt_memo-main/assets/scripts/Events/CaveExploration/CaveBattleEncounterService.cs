using System;
using CaveGame.CaveBattle;
using UnityEngine;

/// <summary>
/// 「ボタンを押した時」「敵prefabとエンカウントした時」の両方から共通で戦闘を開始するための窓口。
///
/// CaveBattleEncounterButton（UI）とCaveBattleEncounterTrigger（ダンジョン内の敵prefab）は、
/// どちらもこのサービスのTryStartEncounter()を呼ぶだけでよい。
/// 「今このエリアはどのルールで戦うか」（通常/負けたら勝ち/運90%固定 等）はactiveRulesetとして
/// ここに保持し、エリア移動時などにSetActiveRulesetで切り替える想定。
///
/// 会話（仲間勧誘）イベントとの関係:
/// ・rulesetのAllowsRecruitmentがtrue（＝仲間にできる戦闘）の場合、戦闘の前に
///   CaveConversationControllerを開き、プレイヤーが強さを調べる／仲間にする／
///   そのまま戦うを選べるようにする。
/// ・AllowsRecruitmentがfalse（＝仲間にできない戦闘）の場合、あるいは
///   conversationControllerが未設定の場合は、会話を挟まず直接戦闘へ進む。
/// ・会話でどれを選んでも（仲間にする／断る／そのまま戦う）、最終的には必ず
///   戦闘へ進む。つまり「会話後」でも「会話に関係なく（未設定/対象外）」でも、
///   同じTryStartEncounter経由で戦闘画面に到達できる。
/// ・AllowsRecruitment=falseのルールは、PartyRosterが6体に到達する
///   （CaveRecruitmentService.HasUnlockedOtherRules）まで解放されない。
/// </summary>
public sealed class CaveBattleEncounterService : MonoBehaviour
{
    [Header("Dependencies")]
    [SerializeField] private TwoTurnBattlePhase battlePhase;
    [SerializeField] private CaveBattleDataLoader dataLoader;

    [Header("会話（仲間勧誘）")]
    [Tooltip("未設定の場合、AllowsRecruitmentがtrueのルールでも会話を挟まず直接戦闘へ進む。")]
    [SerializeField] private CaveConversationController conversationController;
    [Tooltip("PartyRosterの所持数を見て「他ルールの戦闘」が解放されているかを判定する。")]
    [SerializeField] private CaveRecruitmentService recruitmentService;

    [Header("既定ルール")]
    [Tooltip("SetActiveRulesetで切り替えていない間はこのルールが使われる。未設定なら通常ルール。")]
    [SerializeField] private CaveBattleRuleset defaultRuleset;

    [Header("Debug")]
    [SerializeField] private bool enableDebugLog = true;

    private CaveBattleRuleset activeRuleset;

    public bool IsBusy => battlePhase != null && battlePhase.IsRunning;

    private void Awake()
    {
        activeRuleset = defaultRuleset;
    }

    /// <summary>ダンジョンのエリア/イベントが切り替わったタイミングで呼ぶ。nullを渡すと既定ルールに戻る。</summary>
    public void SetActiveRuleset(CaveBattleRuleset ruleset)
    {
        activeRuleset = ruleset != null ? ruleset : defaultRuleset;

        if (enableDebugLog)
        {
            string name = activeRuleset != null ? activeRuleset.RulesetName : "通常ルール";
            Debug.Log($"[CaveBattleEncounterService] アクティブルールを切り替え: {name}");
        }
    }

    public CaveBattleRuleset ActiveRuleset => activeRuleset;

    /// <summary>
    /// このrulesetの戦闘が現在プレイ可能か。
    /// 仲間にできる戦闘（AllowsRecruitment=true）は常に解放済み。
    /// 仲間にできない戦闘（AllowsRecruitment=false）は、PartyRosterが6体に到達するまで未解放。
    /// </summary>
    public bool IsRulesetUnlocked(CaveBattleRuleset ruleset)
    {
        CaveBattleRuleset effective = ruleset != null ? ruleset : CaveBattleRuleset.Normal;

        if (effective.AllowsRecruitment)
        {
            return true;
        }

        return recruitmentService != null && recruitmentService.HasUnlockedOtherRules;
    }

    /// <summary>
    /// 戦闘を開始する（会話イベントの要否を自動判定する版）。
    /// enemyCharacterId: 対応する敵（プレイヤーが選んだキャラと戦わせる相手）のjapanese_history_chars_expanded.csv上のid。
    /// rulesetOverride: このエンカウント固有のルールがあれば指定（例: このボタンだけ「負けたら勝ち」にしたい等）。
    ///                  nullならSetActiveRulesetで設定中のルール（無ければ既定ルール）を使う。
    /// </summary>
    public bool TryStartEncounter(
        CaveEventState state,
        int enemyCharacterId,
        CaveBattleRuleset rulesetOverride,
        Action<TwoTurnBattlePhaseResult> onCompleted)
    {
        if (battlePhase == null)
        {
            Debug.LogError("[CaveBattleEncounterService] TwoTurnBattlePhaseが未設定です。");
            onCompleted?.Invoke(TwoTurnBattlePhaseResult.CreateFailure("TwoTurnBattlePhaseが未設定です。"));
            return false;
        }

        if (IsBusy)
        {
            Debug.LogWarning("[CaveBattleEncounterService] 既に戦闘中のため、このエンカウントは無視しました。");
            return false;
        }

        if (!TryResolvePlayerCharacterId(state, out int playerCharacterId, out string parseError))
        {
            Debug.LogError($"[CaveBattleEncounterService] {parseError}");
            onCompleted?.Invoke(TwoTurnBattlePhaseResult.CreateFailure(parseError));
            return false;
        }

        CaveBattleRuleset ruleset = rulesetOverride != null ? rulesetOverride : activeRuleset;
        CaveBattleRuleset effectiveRuleset = ruleset != null ? ruleset : CaveBattleRuleset.Normal;

        if (!IsRulesetUnlocked(effectiveRuleset))
        {
            const string message = "この戦闘はまだ解放されていません（仲間を6体にすると挑戦できます）。";
            Debug.LogWarning($"[CaveBattleEncounterService] {message}");
            onCompleted?.Invoke(TwoTurnBattlePhaseResult.CreateFailure(message));
            return false;
        }

        StartConversationThenBattle(state, playerCharacterId, enemyCharacterId, effectiveRuleset, onCompleted);
        return true;
    }

    /// <summary>
    /// 会話を完全にスキップして直接戦闘へ進みたい場合（デバッグ、演出省略設定等）に使う。
    /// これも「会話に関係なく戦闘画面へ行けるルート」の一つ。
    /// </summary>
    public bool TryStartEncounterSkippingConversation(
        CaveEventState state,
        int enemyCharacterId,
        CaveBattleRuleset rulesetOverride,
        Action<TwoTurnBattlePhaseResult> onCompleted)
    {
        if (battlePhase == null || IsBusy)
        {
            return false;
        }

        if (!TryResolvePlayerCharacterId(state, out int playerCharacterId, out string parseError))
        {
            Debug.LogError($"[CaveBattleEncounterService] {parseError}");
            onCompleted?.Invoke(TwoTurnBattlePhaseResult.CreateFailure(parseError));
            return false;
        }

        CaveBattleRuleset ruleset = rulesetOverride != null ? rulesetOverride : activeRuleset;
        CaveBattleRuleset effectiveRuleset = ruleset != null ? ruleset : CaveBattleRuleset.Normal;

        if (!IsRulesetUnlocked(effectiveRuleset))
        {
            onCompleted?.Invoke(TwoTurnBattlePhaseResult.CreateFailure("この戦闘はまだ解放されていません。"));
            return false;
        }

        return battlePhase.Execute(state, playerCharacterId, enemyCharacterId, effectiveRuleset, onCompleted);
    }

    private void StartConversationThenBattle(
        CaveEventState state,
        int playerCharacterId,
        int enemyCharacterId,
        CaveBattleRuleset ruleset,
        Action<TwoTurnBattlePhaseResult> onCompleted)
    {
        bool wantsConversation = ruleset.AllowsRecruitment && conversationController != null;

        if (!wantsConversation)
        {
            // 仲間にできない戦闘、または会話UIが未設定の場合は会話を挟まず直接戦闘へ。
            battlePhase.Execute(state, playerCharacterId, enemyCharacterId, ruleset, onCompleted);
            return;
        }

        CaveBattleCharacter enemyData = ResolveEnemyDataOrNull(enemyCharacterId);
        if (enemyData == null)
        {
            battlePhase.Execute(state, playerCharacterId, enemyCharacterId, ruleset, onCompleted);
            return;
        }

        conversationController.Open(enemyData, conversationResult =>
        {
            if (enableDebugLog)
            {
                Debug.Log(
                    "[CaveBattleEncounterService] 会話終了: " +
                    $"choice={conversationResult.Choice}, outcome={conversationResult.RecruitmentOutcome}");
            }

            // 現仕様ではConversationResult.ProceedToBattleは常にtrue
            // （仲間にする／断る／そのまま戦うのどれを選んでも戦闘へ進む）。
            if (!conversationResult.ProceedToBattle)
            {
                onCompleted?.Invoke(TwoTurnBattlePhaseResult.CreateFailure("会話により戦闘が中止されました。"));
                return;
            }

            battlePhase.Execute(state, playerCharacterId, enemyCharacterId, ruleset, onCompleted);
        });
    }

    private CaveBattleCharacter ResolveEnemyDataOrNull(int enemyCharacterId)
    {
        if (dataLoader == null || !dataLoader.IsLoaded)
        {
            return null;
        }

        try
        {
            return dataLoader.Repository.GetCharacter(enemyCharacterId);
        }
        catch (Exception ex)
        {
            Debug.LogWarning($"[CaveBattleEncounterService] 敵データ取得に失敗: {ex.Message}");
            return null;
        }
    }

    /// <summary>
    /// CaveEventState.SelectedCharacterId（文字列）をCSVのidに変換する。
    /// CharacterSelectController.Open(onSelected, repository)経由で選択していれば、
    /// idはCSVのidをそのまま文字列化したものになっているのでint.Parseで復元できる。
    /// デモ用の候補（character.swordsman等）で選択された場合はここで失敗する。
    /// </summary>
    private bool TryResolvePlayerCharacterId(CaveEventState state, out int playerCharacterId, out string error)
    {
        playerCharacterId = 0;
        error = null;

        if (state == null)
        {
            error = "CaveEventStateがnullです。";
            return false;
        }

        string selectedId = state.SelectedCharacterId;
        if (string.IsNullOrEmpty(selectedId) || !int.TryParse(selectedId, out playerCharacterId))
        {
            error =
                $"選択中のキャラクターID '{selectedId}' を戦闘用キャラクターIDへ変換できません。" +
                "CharacterSelectController.Openをrepository付きで呼び、実データから選ばせてください。";
            return false;
        }

        return true;
    }

    public CaveBattleDataLoader DataLoader => dataLoader;
    public CaveRecruitmentService RecruitmentService => recruitmentService;
}
