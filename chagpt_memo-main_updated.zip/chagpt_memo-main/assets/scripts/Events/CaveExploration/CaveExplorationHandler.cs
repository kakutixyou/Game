using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 洞窟探索の画面とPhaseを接続する進行役。
/// この版では Start → 理科問題 → 理科バフ → キャラクター選択を完成させる。
/// 数学、日本史、戦闘はCavePhase.Battle到達後に追加する。
/// </summary>
public sealed class CaveExplorationHandler : MonoBehaviour
{
    [Header("Startup")]
    [Tooltip("洞窟専用SceneならON。同じScene内で画面遷移する場合はOFFにし、遷移元からOnEnterCaveを呼ぶ。")]
    [SerializeField] private bool autoEnterOnStart = true;

    [Header("Screens")]
    [SerializeField] private GameObject caveHomeScreen;
    [SerializeField] private GameObject caveInsideScreen;

    [Header("Cave Home")]
    [SerializeField] private Button startExplorationButton;

    [Header("Optional Debug Buttons")]
    [SerializeField] private Button scienceQuizButton;
    [SerializeField] private Button characterSelectButton;

    [Header("Phase Controllers")]
    [SerializeField] private ScienceQuizController scienceQuizController;
    [SerializeField] private CharacterSelectController characterSelectController;

    [Header("Shared Systems")]
    [SerializeField] private EventSetTrigger eventSetTrigger;

    [Header("Status")]
    [SerializeField] private Text statusText;
    [SerializeField] private Text acquiredBuffText;

    [Header("Debug")]
    [SerializeField] private CavePhase currentPhase = CavePhase.None;

    private CaveEventState state;
    private bool eventsRegistered;
    private bool isPhaseRunning;

    public CaveEventState State => state;
    public CavePhase CurrentPhase => currentPhase;

    private void Awake()
    {
        state = new CaveEventState();
    }

    private void Start()
    {
        if (autoEnterOnStart)
        {
            OnEnterCave();
        }
    }

    /// <summary>
    /// 村などの別画面から洞窟へ遷移した直後に呼ぶ。
    /// </summary>
    public void OnEnterCave()
    {
        RegisterEvents();
        isPhaseRunning = false;
        ChangePhase(CavePhase.None);
        ShowCaveHome();
        SetStatus("洞窟を探索しますか？");
        RefreshUI();
    }

    public void OnExitCave()
    {
        UnregisterEvents();
        SetActive(caveHomeScreen, false);
        SetActive(caveInsideScreen, false);
        isPhaseRunning = false;
    }

    private void RegisterEvents()
    {
        if (eventsRegistered)
        {
            return;
        }

        if (eventSetTrigger == null)
        {
            Debug.LogError("[CaveExplorationHandler] EventSetTriggerが設定されていません。");
            return;
        }

        RegisterButton(
            CaveEventIds.StartExploration,
            startExplorationButton,
            StartExploration);

        // 通常はStartExplorationから自動で進む。以下2つは開発確認用。
        RegisterButton(
            CaveEventIds.ScienceQuiz,
            scienceQuizButton,
            OpenScienceQuiz);
        RegisterButton(
            CaveEventIds.CharacterSelect,
            characterSelectButton,
            OpenCharacterSelect);

        eventsRegistered = true;
    }

    private void RegisterButton(
        string eventId,
        Button button,
        UnityEngine.Events.UnityAction action)
    {
        if (button == null)
        {
            return;
        }

        eventSetTrigger.Register(eventId, button, action, this);
    }

    private void UnregisterEvents()
    {
        if (!eventsRegistered || eventSetTrigger == null)
        {
            return;
        }

        eventSetTrigger.UnregisterOwner(this);
        eventsRegistered = false;
    }

    /// <summary>
    /// Startボタンから呼ばれる、今回のゲーム進行の起点。
    /// </summary>
    private void StartExploration()
    {
        if (isPhaseRunning)
        {
            return;
        }

        state.StartNewRun();
        ChangePhase(CavePhase.Entry);
        state.AddLog("洞窟探索を開始しました。");

        ShowCaveInside();
        ChangePhase(CavePhase.ScienceQuiz);

        // Phase変更だけで止めず、そのまま理科問題を開く。
        OpenScienceQuiz();
    }

    private void OpenScienceQuiz()
    {
        if (!TryBeginPhase(CavePhase.ScienceQuiz))
        {
            return;
        }

        if (scienceQuizController == null)
        {
            FailPhase("ScienceQuizControllerが設定されていません。");
            return;
        }

        SetStatus("理科問題に答えてください。");
        scienceQuizController.StartQuiz(state, OnScienceQuizCompleted);
    }

    private void OnScienceQuizCompleted(ScienceQuizResult result)
    {
        if (!TryAcceptResult(result, CavePhase.ScienceQuiz, "理科問題"))
        {
            return;
        }

        state.SetScienceResult(
            result.Score,
            result.AnswerTime,
            0f,
            0f,
            result.RewardTier);

        EndRunningPhase();
        ChangePhase(CavePhase.ScienceBuff);

        state.AddScienceBuff(result.RewardBuffId);
        state.AddLog($"理科バフ決定: {result.RewardBuffName}");

        if (acquiredBuffText != null)
        {
            acquiredBuffText.text =
                $"獲得した理科バフ\n{result.RewardBuffName}";
        }

        SetStatus($"理科バフ「{result.RewardBuffName}」を獲得しました。");

        // 今回の縦切りでは数学・日本史を後回しにして、キャラクター選択へ進む。
        ChangePhase(CavePhase.CharacterSelect);
        OpenCharacterSelect();
    }

    private void OpenCharacterSelect()
    {
        if (!TryBeginPhase(CavePhase.CharacterSelect))
        {
            return;
        }

        if (characterSelectController == null)
        {
            FailPhase("CharacterSelectControllerが設定されていません。");
            return;
        }

        SetStatus("キャラクターを選択してください。");
        characterSelectController.Open(OnCharacterSelected);
    }

    private void OnCharacterSelected(string characterId, string characterName)
    {
        if (currentPhase != CavePhase.CharacterSelect || !isPhaseRunning)
        {
            Debug.LogWarning(
                "[CaveExplorationHandler] 現在のPhaseと異なるキャラクター結果を無視しました。");
            return;
        }

        if (string.IsNullOrWhiteSpace(characterId))
        {
            FailPhase("キャラクターIDが空です。");
            return;
        }

        state.SetCharacter(characterId, characterName);
        EndRunningPhase();
        ChangePhase(CavePhase.Battle);
        SetStatus($"{characterName}を選択しました。戦闘準備完了です。");
    }

    private bool TryBeginPhase(CavePhase expectedPhase)
    {
        if (isPhaseRunning)
        {
            return false;
        }

        if (currentPhase != expectedPhase)
        {
            Debug.LogWarning(
                $"[CaveExplorationHandler] 順番が違います。現在: {currentPhase} / 要求: {expectedPhase}");
            return false;
        }

        isPhaseRunning = true;
        RefreshUI();
        return true;
    }

    private bool TryAcceptResult(
        object result,
        CavePhase expectedPhase,
        string sourceName)
    {
        if (currentPhase != expectedPhase || !isPhaseRunning)
        {
            Debug.LogWarning(
                $"[CaveExplorationHandler] 現在のPhaseと異なる{sourceName}結果を無視しました。");
            return false;
        }

        if (result == null)
        {
            FailPhase($"{sourceName}結果がnullです。");
            return false;
        }

        return true;
    }

    private void EndRunningPhase()
    {
        isPhaseRunning = false;
        RefreshUI();
    }

    private void FailPhase(string message)
    {
        isPhaseRunning = false;
        SetStatus(message);
        Debug.LogError($"[CaveExplorationHandler] {message}");
        RefreshUI();
    }

    private void ChangePhase(CavePhase nextPhase)
    {
        currentPhase = nextPhase;
        Debug.Log($"[CaveExplorationHandler] Phase -> {nextPhase}");
        RefreshUI();
    }

    private void ShowCaveHome()
    {
        SetActive(caveInsideScreen, false);
        SetActive(caveHomeScreen, true);
    }

    private void ShowCaveInside()
    {
        SetActive(caveHomeScreen, false);
        SetActive(caveInsideScreen, true);
    }

    private void RefreshUI()
    {
        SetInteractable(
            startExplorationButton,
            !isPhaseRunning && (!state.IsRunActive || state.IsRunFinished));
        SetInteractable(
            scienceQuizButton,
            CanOperate(CavePhase.ScienceQuiz));
        SetInteractable(
            characterSelectButton,
            CanOperate(CavePhase.CharacterSelect));
    }

    private bool CanOperate(CavePhase phase)
    {
        return state.IsRunActive
            && !state.IsRunFinished
            && !isPhaseRunning
            && currentPhase == phase;
    }

    private void SetStatus(string message)
    {
        if (statusText != null)
        {
            statusText.text = message;
        }
    }

    private static void SetInteractable(Button button, bool value)
    {
        if (button != null)
        {
            button.interactable = value;
        }
    }

    private static void SetActive(GameObject target, bool value)
    {
        if (target != null)
        {
            target.SetActive(value);
        }
    }

    private void OnDestroy()
    {
        UnregisterEvents();
    }
}
