洞窟探索・開発再開メモ

最終更新: 2026-09-13

30秒で思い出す要約

中学生向けの「クイズで3教科のバフを集め、キャラクターを選び、一瞬の戦闘へ進む」ゲームを制作中。

現在は次の経路までコードを接続済み。

洞窟ホーム
→ Start
→ 理科CSV問題
→ 理科バフ確認・獲得
→ 数学CSV問題
→ 数学バフ確認・獲得
→ 日本史CSV問題
→ 日本史バフ確認・獲得
→ キャラクター選択
→ CavePhase.Battleへ到達

次の大きな作業はバトル基盤。最初にBattleTypes.cs、BattleActionType.cs、BattleConfig.cs、IBattleController.csを作る。

必ず守る現在の採用方針

正式な司令塔は、この一式に入っている最新版CaveExplorationHandler.cs。

627行の旧Handlerは参考資料。Assets内へ同名クラスとして置かない。

旧版を残す場合はプロジェクト外へ移すか、CaveExplorationHandler.Legacy.cs.txtにする。

CaveExplorationHandlerは画面遷移、Phase変更、Controller呼び出し、完了通知だけを担当する。

問題判定はQuizController、バフ確認画面はBuffController、状態保存はCaveEventStateが担当する。

Phaseの実行可否はCaveEventInspectorで確認する。

イベントIDの文字列は直書きせずCaveEventIdsを使う。

BattleTypesなどの共通型を複数ファイルで重複定義しない。

起動順

ゲームデータ側を含めた想定起動順は次の通り。

GameDataLoader
→ CsvParser
→ CsvDataValidator
→ GameDataRepository
→ EventSetTrigger
→ CaveExplorationHandler.OnEnterCave
→ Startボタン登録

洞窟専用SceneならCaveEventConfig.AutoEnterOnStartをON。同じScene内で村から遷移する場合はOFFにして、遷移元からOnEnterCave()を呼ぶ。

クラスの責務

クラス

責務

CaveExplorationHandler

全体の進行、Phase変更、Controller間の受け渡し

CaveEventState

連勝、問題結果、バフ、キャラ、報酬、ログなどの状態保持

CaveEventInspector

現在のStateでPhaseを開始可能か検査

CaveEventConfig

スタミナ、最大連勝、報酬間隔などの変更可能設定

EventSetTrigger

UI ButtonとイベントIDの登録・解除・発火

*QuizController

CSV問題の表示、回答受付、正誤と解説の表示

*BuffController

獲得バフの確認画面。Stateは直接変更しない

CharacterSelectController

キャラクター候補の表示と選択結果返却

GameDataRepository

IDからCharacter、Skill、Buffのマスターデータを取得

現在作成済み

洞窟中枢

CaveExplorationHandler.cs

CaveEventInspector.cs

CaveEventConfig.cs

CavePhase.cs

CaveEventIds.cs

CaveEventState.cs（以前作成済み。現在のZIPには未収録）

EventSetTrigger.cs（以前作成済み。Controllers ZIPには未収録）

問題

ScienceQuizController.cs

MathQuizController.cs

JapaneseHistoryQuizController.cs

ScienceQuizQuestion.cs

MathQuizQuestion.cs

JapaneseHistoryQuizQuestion.cs

各QuizResult

CSV共通パーサーと検証モデル

バフ

BuffRewardControllerBase.cs

ScienceBuffController.cs

MathBuffController.cs

HistoryBuffController.cs

BuffRewardResult.cs

キャラクター

CharacterSelectController.cs

CharacterSelectionOption.cs

CharacterSelectionResult.cs

現在のキャラクター候補は仮データ。次にGameDataRepositoryへ接続する必要がある。

CSV仕様

3教科の問題CSVは同じ18列。

question_id,subject,unit,difficulty,question_text,
choice_1,choice_2,choice_3,choice_4,correct_choice,
hint,explanation,reward_buff_id,reward_buff_name,
retry_buff_id,retry_buff_name,reward_tier,tags

subject: science / math / japanese_history

difficulty: easy / normal / hard

correct_choice: CSVは1～4またはA～D、C#内部は0始まり

tags: 水|状態変化のように|区切り

不正解でもretry_buffを与え、未習得者が進行不能にならない

問題はランダム出題し、固定問題の暗記だけで進めないようにする

サンプルはAssets/Resources/GameData/に各教科3問ずつある。

CaveEventConfig初期値

設定

初期値

1探索のスタミナ消費

1

最大連勝

50

連勝報酬間隔

3

各教科の問題数

1

理科・数学・日本史バフ

必須

Create > Game > Cave Exploration ConfigからAssetを作成し、最新版Handlerへ設定する。

バトル側の確定方針

戦闘はテンポ重視で、基本的に1ターン・一瞬のアニメーション。

イベントボスHPの目安は99,999。

技データはCSV管理。

技の主な列はid, skill_name, target, n_val, s_val, r_val, hits, buff_group, effect_type, description。

n_val: 攻撃力などの数値。

s_val: 先攻・後攻補正。

r_val: 効果持続。

理科の化学反応系バフは最大20倍ダメージ案。

バフをタップすると、元になった理科・数学・日本史の解説を表示する。

数学バフの説明では、答えだけでなく途中式を思い出せる内容にする。

理科と関連する日本史キャラクターには、関係性を示すヒントを出す。

1番目の技は日本史バフにより1%で「おふざけ技」へ置換される可能性がある。

この置換判定はHistoryJokeSkillRule.csに閉じ込める。

CharacterAnimationControllerは置換済みの技IDを受け取り、演出だけを担当する。

引き分けは連勝を維持する。

3連勝ごとに数学・理科系の追加バフ候補を与える。

50連勝時は専用Controllerへ切り替える。

バトル開発の推奨順

1. BattleTypes.cs
2. BattleActionType.cs
3. BattleConfig.cs
4. IBattleController.cs
5. SkillSelectionResolver.cs
6. HistoryJokeSkillRule.cs
7. InstantBattleController.cs
8. BattlePhase.cs
9. RewardPhase.cs
10. ResultPhase.cs
11. CharacterAnimationController.cs
12. NormalBattleController.cs
13. FiftyWinBattleController.cs

最初はアニメーションを作らず、Consoleログだけで「選択技・先後・ダメージ・勝敗」が確認できる状態を完成させる。

バトル着手前に残っている接続

CharacterSelectControllerの仮候補をGameDataRepositoryから取得する。

CaveEventState.ConsumeStamina()を実際のプレイヤースタミナ供給元へ接続する。

CaveEventConfig.MaximumWinStreakとStreakRewardIntervalをReward処理へ接続する。

ScienceBuffData、MathBuffData、HistoryBuffDataのマスター型を確定する。

バフIDがGameDataRepositoryに存在するか検証する。

現在の注意点

CaveEventState.csとEventSetTrigger.csは別途既存ファイルが必要。

Handler、CavePhase.cs、CaveEventIds.csは必ず同じ最新版を使用する。

同名の旧Handlerを同時に置くとクラス重複エラーになる。

UIのTextは現在UnityEngine.UI.Text。TextMeshProへ変更する場合は全Controllerをまとめて変更する。

BuffScreen、QuizScreenは初期状態で非表示にする。

ControllerがHandlerへ結果を返す前に、Stateを直接変更しない。

日本史バフは1個保持で、新しく取ると以前のものを上書きする。

Unityでの最小動作確認

CaveEventConfig Assetを作る。

CaveSystemsへHandler、Inspector、EventSetTrigger、各Controllerを追加する。

HandlerへConfig、Inspector、各Controller、Start Buttonを割り当てる。

各QuizControllerへ対応CSVとUIを割り当てる。

各BuffControllerへBuffScreenと確認Buttonを割り当てる。

PlayしてStartを押す。

理科→理科バフ→数学→数学バフ→日本史→日本史バフ→キャラ選択まで進む。

ConsoleにPhase -> Battleが出れば現在地点まで成功。

次回AIへそのまま渡す再開文

Unityの「中学生向けクイズ×バフバトル」の開発を再開します。
CAVE_EXPLORATION_HANDOFF.mdを基準にしてください。
現在はStart→理科→理科バフ→数学→数学バフ→日本史→日本史バフ→キャラクター選択→CavePhase.Battleまで接続済みです。

次はBattleTypes.cs、BattleActionType.cs、BattleConfig.cs、IBattleController.csから順に作ってください。
共通型の重複定義は禁止し、計算とアニメーションを分離してください。

関連資料

CAVE_EXPLORATION_PROGRESS.md: 全ファイルの作成状況

UNITY_SETUP.md: HierarchyとInspectorの設定手順
EventSetTrigger.cs は洞窟専用ではないため、Core/Events に置く。
おすすめ開発順

短くまとめると次の順番です。

重複している BuffData と RuntimeBuffState を統合
CavePhase.cs
CaveEventIds.cs
CaveEventConfig.cs
BattleTypes.cs
IBattleController.cs
CaveEventState.cs
EventSetTrigger.cs
CaveEventInspector.cs
CaveExplorationHandler.cs
EventEntryPhase.cs
理科問題・理科バフ
数学問題・数学バフ
日本史バフ
キャラクター選択
RewardPhase.cs
ResultPhase.cs
HistoryJokeSkillRule.cs
SkillSelectionResolver.cs
通常バトル計算
アニメーション接続
50連勝専用イベント
全体テスト