using CaveGame.CaveBattle;
using UnityEngine;

/// <summary>
/// ダンジョン内に配置する敵prefabへ付ける。プレイヤーと接触した時に、
/// このprefabに対応する敵（enemyCharacterId）との戦闘を開始する。
/// 2D/3Dどちらの物理も想定し、Trigger系のCollider/Collider2Dどちらでも動く。
/// </summary>
public sealed class CaveBattleEncounterTrigger : MonoBehaviour
{
    [Header("Dependencies")]
    [SerializeField] private CaveBattleEncounterService encounterService;

    [Header("対応する敵")]
    [Tooltip("japanese_history_chars_expanded.csvのid。このprefabに接触すると必ずこの敵と戦う。")]
    [SerializeField] private int enemyCharacterId;

    [Header("このエンカウント専用のルール（任意）")]
    [Tooltip(
        "未設定ならCaveBattleEncounterServiceの現在のアクティブルールを使う。" +
        "rulesetのAllowsRecruitmentで「このprefabは仲間にできる戦闘か」を管理する。")]
    [SerializeField] private CaveBattleRuleset rulesetOverride;

    [Header("会話イベント")]
    [Tooltip("trueの場合、常に会話（仲間勧誘）を挟まず直接戦闘へ進む。")]
    [SerializeField] private bool forceSkipConversation = false;

    [Header("接触判定")]
    [SerializeField] private string playerTag = "Player";
    [Tooltip("一度エンカウントしたら、このprefabは再度反応しないようにする（倒した敵に何度も遭遇しないため）。")]
    [SerializeField] private bool disableAfterEncounter = true;
    [Tooltip("戦闘終了後にこのGameObjectを消すか（敵を倒した後にダンジョンから消す演出用）。")]
    [SerializeField] private bool destroyOnCompletion = false;

    private CaveEventState state;
    private bool encounterTriggered;

    /// <summary>CaveExplorationHandler等、CaveEventStateを持つ側から呼んで紐付ける。</summary>
    public void Bind(CaveEventState eventState)
    {
        state = eventState;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        TryHandleContact(other.gameObject);
    }

    private void OnTriggerEnter(Collider other)
    {
        TryHandleContact(other.gameObject);
    }

    private void TryHandleContact(GameObject other)
    {
        if (encounterTriggered && disableAfterEncounter)
        {
            return;
        }

        if (other == null || !other.CompareTag(playerTag))
        {
            return;
        }

        if (encounterService == null)
        {
            Debug.LogError("[CaveBattleEncounterTrigger] CaveBattleEncounterServiceが未設定です。");
            return;
        }

        if (state == null)
        {
            Debug.LogError("[CaveBattleEncounterTrigger] Bind(CaveEventState)が呼ばれていません。");
            return;
        }

        if (encounterService.IsBusy)
        {
            return;
        }

        encounterTriggered = true;

        if (forceSkipConversation)
        {
            encounterService.TryStartEncounterSkippingConversation(
                state, enemyCharacterId, rulesetOverride, OnBattleCompleted);
        }
        else
        {
            encounterService.TryStartEncounter(state, enemyCharacterId, rulesetOverride, OnBattleCompleted);
        }
    }

    private void OnBattleCompleted(TwoTurnBattlePhaseResult result)
    {
        if (result == null || !result.Succeeded)
        {
            Debug.LogWarning($"[CaveBattleEncounterTrigger] 戦闘開始に失敗: {result?.ErrorMessage}");
            encounterTriggered = false; // 失敗時は再挑戦できるようにする。
            return;
        }

        if (destroyOnCompletion)
        {
            Destroy(gameObject);
        }
    }
}
