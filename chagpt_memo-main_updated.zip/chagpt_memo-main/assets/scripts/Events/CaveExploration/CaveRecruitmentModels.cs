using System;

namespace CaveGame.CaveBattle
{
    /// <summary>会話イベントで最終的にプレイヤーが選んだ行動。</summary>
    public enum CaveConversationChoice
    {
        /// <summary>強さ（ステータス）を調べただけで、まだ結論を出していない。</summary>
        InspectOnly = 0,

        /// <summary>仲間にすることを選んだ。</summary>
        AttemptRecruit = 1,

        /// <summary>勧誘を断った。</summary>
        Decline = 2,

        /// <summary>会話自体をスキップした（会話に関係なく戦闘へ進むルート）。</summary>
        SkippedConversation = 3
    }

    /// <summary>勧誘（仲間化）の成否。</summary>
    public enum CaveRecruitmentOutcome
    {
        /// <summary>この戦闘は仲間にできない戦闘（Ruleset.AllowsRecruitment=false）だった。</summary>
        NotOffered = 0,

        /// <summary>プレイヤーが断った、または勧誘を試みなかった。</summary>
        NotAttempted = 1,

        /// <summary>所持6体未満のため、無条件で仲間になった。</summary>
        RecruitedUnconditionally = 2,

        /// <summary>既に仲間だったキャラクターだった（重複）。</summary>
        AlreadyRecruited = 3,

        /// <summary>
        /// 所持6体以上での勧誘。現時点では成功条件が未確定のため常に失敗として扱う
        /// （CaveRecruitmentServiceのコメント参照。ここを拡張すれば確率化などに対応できる）。
        /// </summary>
        FailedNotEligible = 4
    }

    /// <summary>会話イベント→勧誘までの一連の結果。CaveBattleEncounterServiceが戦闘開始前に受け取る。</summary>
    [Serializable]
    public sealed class CaveConversationResult
    {
        public CaveConversationChoice Choice { get; }
        public CaveRecruitmentOutcome RecruitmentOutcome { get; }

        /// <summary>この結果を受けて戦闘へ進んでよいか。現仕様では常にtrue（会話後・スキップ問わず戦闘へ行ける）。</summary>
        public bool ProceedToBattle { get; }

        public CaveConversationResult(
            CaveConversationChoice choice,
            CaveRecruitmentOutcome recruitmentOutcome,
            bool proceedToBattle)
        {
            Choice = choice;
            RecruitmentOutcome = recruitmentOutcome;
            ProceedToBattle = proceedToBattle;
        }

        public static CaveConversationResult CreateSkipped()
        {
            return new CaveConversationResult(
                CaveConversationChoice.SkippedConversation,
                CaveRecruitmentOutcome.NotOffered,
                true);
        }
    }
}
